<?php
#SYSTEM
date_default_timezone_set('Asia/Manila');
define('MAIN_CLASS', 'bet');
define('USER_CLASS', 'user');
define('BART_CLASS', 'bart');
define('WEB_ADMIN', '["76561198082460090"]'); //76561198152650672 // 76561198156059942 // 76561198082460090  // 76561198112567043
define('WEB_TITLE', 'Dota2 Sport');
define('WEB_ALIAS', 'Dota2 Sport');
define('WEB_AUTHOR', 'Dota2 Sport');
define('WEB_DESCRIPTION', "Betting Site");
#DATABASE
define("DB_HOST", 'localhost');
define("DB_USER", 'bartgamer');
define("DB_PASS", 'bartgamer');
define("DB_NAME", 'dota2sport');
#PATHS,SESSIONS,IMAGES
define('CLASS_PATH', '/app/system_classes/');
define('MODEL_PATH', '/app/system_models/');
define('VIEWS_PATH', '/app/system_views/');
define('EXTRA_PATH', '/app/system_libraries/');
define('STEAMUSERS', 'BARTGAMER');
define('IMG_UPLOAD', 'bartgamer');
define('MAX_UPLOAD', 500);
define('IMG_SIZE_W', 225);
define('IMG_SIZE_H', 225);
define('STAKELIMIT', 4);
define('EXT', '.php');
#PAGES
define('PAGE_HOME', MAIN_CLASS . '/user/matches');
define('PAGE_HALT', MAIN_CLASS . '/user/signout');
#CLASSES,FUNCTIONS
include_once SITE_ROOT . '/app/system_classes_loader.php';
$folder = ['system_functions','system_classes','system_models'];
$loader = new LOADER;
$loader->load($folder);
#STYLESHEETS,JAVASCRIPTS
define('FREEURL', 1);
define('BASEURL', baseURL());
$stylesheets = [
	BASEURL.'css/bootstrap.css',
	BASEURL.'css/bootstrap-responsive.css',
	BASEURL.'css/bootstrap-formhelpers.css',
	BASEURL.'css/style.css',
	BASEURL.'css/prettify.css',
	BASEURL.'css/smoothness/jquery-ui-1.8.16.custom.css',
	BASEURL.'css/datatable/datatable_custom.css?'.random_string(10),
	BASEURL.'css/fullcalendar.css',
	BASEURL.'css/elfinder.css',
	BASEURL.'css/flot/jquery.flot_custom.css',
	BASEURL.'css/validationEngine.css',
	BASEURL.'js/jQuery-UI-FileInput/css/enhanced.css',
	BASEURL.'css/fancybox/jquery.fancybox.css',
	BASEURL.'css/kevin.css?'.random_string(10),
	BASEURL.'css/dota2.css?'.random_string(10)
];
$javascripts = [
	BASEURL.'js/jquery.nicescroll.min.js',
   	BASEURL.'js/jquery.autogrowtextarea.min.js',
	BASEURL.'js/jquery.dataTables.min.js',
	BASEURL.'js/dataTable_bootstrap.js',
	BASEURL.'js/fullcalendar.js',
	BASEURL.'js/elfinder.min.js',
	BASEURL.'js/jquery-ui-1.8.16.custom.min.js',
	BASEURL.'js/jquery.fancybox.pack.js',
	BASEURL.'js/jQuery-UI-FileInput/js/enhance.min.js',
	BASEURL.'js/jQuery-UI-FileInput/js/fileinput.jquery.js',
	BASEURL.'js/jQuery-validation/jquery.validationEngine.js',
	BASEURL.'js/jQuery-validation/languages/jquery.validationEngine-en.js',
	BASEURL.'js/inputmask.jquery.js',
	BASEURL.'js/uniform.jquery.js',
	BASEURL.'js/chosen.jquery.js',
	BASEURL.'js/bootstrap-timepicker.js',
	BASEURL.'js/jquery.tagsinput.js',
	BASEURL.'js/jquery.cleditor.min.js',
	BASEURL.'js/bootstrap.js',
	BASEURL.'js/prettify.js',
	BASEURL.'js/accordion.jquery.js',
	BASEURL.'js/ios-orientationchange-fix.js',
	BASEURL.'js/custom.js'
];
