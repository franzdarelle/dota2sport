<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
define('SITE_ROOT', getcwd());
require_once SITE_ROOT . '/web/settings.php';
if(isset($_GET['steam'])) {
	$openid = new LightOpenID(selfURL());
    if(!$openid->mode) {
        $openid->identity = 'http://steamcommunity.com/openid';
        header('Location: ' . $openid->authUrl());
    } else {
        if($openid->validate()) {
            preg_match("/^http:\/\/steamcommunity\.com\/openid\/id\/(7[0-9]{15,25}+)$/", $openid->identity, $matches);
            $data = new STEAM;
            $user = new SESSIONS;
            $user->setUser($matches[1])->setType()->setData(str_replace(".steam", "", $data->getCookieFile()));
            if(!$user->getType()) $data->handleUser($user->getUser(), $user->data->personaname);
        }
        header('Location: index.php');
        exit;
    }
} 
$page = page_handler();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<meta name="description" content="<?php echo WEB_DESCRIPTION ?>" />
	<meta name="author" content="<?php echo WEB_AUTHOR ?>" />
	<title><?php print $page['name'] ?></title>
	<?php generate_stylesheets($stylesheets) ?>
	<link rel="shortcut icon" href="<?php echo BASEURL ?>ico/favicon.ico">
	<?php generate_javascripts(array(BASEURL.'js/jquery.js', BASEURL.'js/kevin.js?'.random_string(10), BASEURL.'js/jsbn.js', BASEURL.'js/rsa.js')) ?>
	<?php print header_scripts() ?>
</head>
<body>
<?php print $page['menu'] ?>
<div id="main"><?php print $page['data'] ?></div>
<?php generate_javascripts($javascripts) ?>
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--[if lt IE 9]>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
</body>
</html>
