<?php
session_start();
header("Content-type: text/javascript");
define('SITE_ROOT', getcwd());
require_once SITE_ROOT . '/web/settings.php';
ajax_handler();