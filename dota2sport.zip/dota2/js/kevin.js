/*
	Script : Javascript - jQuery
	Author : Kevin D. Adlaon
	March 2013
*/
$("form.system").live("submit", function() {
	var filter   = $(this).attr("filter");
	var menuId 	 = $(this).attr("id");
	var formname = $(this).attr("name");
	var action	 = $(this).attr("action");
	var targetloc= $(this).attr("location");
	var method	 = $(this).attr("method") ? $(this).attr("method") : "GET";
	var formdata = $(this).serialize();
	submitKeys = $("form[name="+formname+"]").html();
	if(filterInput(filter)){
		$.ajax({
			url : BASEURL + "ajax.php?q=" + action,
			type: method,
			cache:true,
			data: { d:formdata },
			mimeType:"multipart/form-data",
			dataType:"html"
		}).done(function(e) {
			if(!isNaN(e)) {
				$(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + targetloc);
			} else {
				popup_box({content:e, class:"www"}, {close : "OK"});
				$("form[name="+formname+"]").html(submitKeys);
			}
		}).fail(function(jqXHR, textStatus){
			popup_box({content:"Request failed: "+textStatus});
		});
	}
	return false;
});

function SelectorCache() {
    var collection = {};
    function get_from_cache(selector) {
        if(undefined === collection[selector]) collection[selector] = $(selector);
        return collection[selector];
    }
    return { get: get_from_cache };
}
													  
function Redirect(location) {
	window.location = BASEURL+((FREEURL)? "":"?q=")+location;
}

function ucfirst(str) {
    var firstLetter = str.substr(0, 1);
    return firstLetter.toUpperCase() + str.substr(1);
}

function filterInput(className){
	var success = true;
	$('.'+className).css({'border-color':'rgba(82, 168, 236, 0.8)', 'box-shadow':'0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6)', 'outline':'0 none'});
	$('.'+className).each(function(){
		$(this).val($.trim($(this).val()));
		if($.trim($(this).val()) == '') {
			$(this).css('border', 'solid thin red');
			success = (success)? $(this).focus(): '';
			success = false;
		}
	});
	return success;
}

function randomstring(L){
    var s= '';
    var randomchar=function(){
    	var n= Math.floor(Math.random()*62);
    	if(n<10) return n; //1-10
    	if(n<36) return String.fromCharCode(n+55); //A-Z
    	return String.fromCharCode(n+61); //a-z
    }
    while(s.length< L) s+= randomchar();
    return s;
}

function refresh_session(url) {
	$.ajax({url:url+"ajax.php?q=dota/keepItAlive"}).done(function(r){});
	setTimeout(function(){refresh_session(url)}, 300000);
}

function popup_box( options, buttons ){
	var options_defaults = {
		title: "Message",
		content: "Please provide a text...",
		width: false,
		height:false,
		start: false,
		place: false,
		class: "xxx"
	}
	var	buttons_defaults = { submit:false, name:false, id:false, class:false, value:false, close:false, escape:true }
	var options = $.extend(options_defaults, options);
	var buttons = $.extend(buttons_defaults, buttons);
	var buts = '';
	if(buttons.submit){
		buts += "<input type='submit' name='"+buttons.name+"' id='"+buttons.id+"' value='"+buttons.value+"' class='btn "+buttons.class+"'>";
	}
	if(buttons.close!=false) buts += createButton(buttons.close);
	function createButton(value){
		return "<input type='button' value='"+value+"' class='btn btn-soft-gray esc"+options.class+"'>";
	}
	var popup_container	= $("<div></div>", { class : "uiBSpopupwin box dark"});
	var popup_header= $("<div></div>", { class : "header" });
	var popup_anchor= $("<a></a>", { class : "btn", "data-original-title" : "Close" }).append('<i class="icon-remove"></i>');
	var popup_close = $("<div></div>", { class : "box-control pull-right" }).append(popup_anchor);
	var popup_title	= $(popup_header).append($("<h4>"+options.title+"</h4>"));
	var popup_content = $("<div></div>", { class : "content" }).append(options.content);
	var popup_modal = $("<div></div>", { class : "uiBSgeneric_dialog_modal" , id:options.class});
	if(buttons.escape) $(popup_title).append(popup_close);
	if(options.width!=false) $(popup_container).css({"width":options.width + 'px',"max-width":options.width + 'px'});
	if(options.height!=false) $(popup_content).css({"max-height":options.height + 'px',"overflow":"auto"});
	if(options.start!=false) {
		var popup_form = $(options.start);
		$(popup_form).append(popup_title).append(popup_content).css({"margin":0});
		if(buts!=''){
			var popup_buttons = $("<div></div>", { class : "popup_buttons" }).html(buts);
			$(popup_form).append(popup_buttons);
		}
		$(popup_container).append(popup_form);
	} else {
		$(popup_container).append(popup_title).append(popup_content);
		if(buts!=''){
			var popup_buttons = $("<div></div>", { class : "popup_buttons" }).html(buts);
			$(popup_container).append(popup_buttons);
		}
	}
 
	$(popup_modal).append($(popup_container).hide());
	$("body").append(popup_modal);
	var top, left;
    top = Math.max($(window).height() - $(popup_container).outerHeight(), 0) / 2;
    left = Math.max($(window).width() - $(popup_container).outerWidth(), 0) / 2;
    $(popup_container).css({"top": top + $(window).scrollTop(), "left": left + $(window).scrollLeft()});
    var showpopup = setInterval(function(){
    	$(popup_container).fadeIn();
    }, 1000);
	$(popup_close).click(function(){
		$("#"+options.class).remove();
		clearInterval(showpopup);
		if(options.place) {
			$("#main").append(options.content);
			$(options.content).hide();
		}
	});
	$(".esc"+options.class).click(function(){$(popup_close).click()});
}
	
$(function() {   	
	$.fn.add = function(f, t, c, w, p, cf, s, n, i, cb, v, x) {
		if(c.length) c.hide();
		$(this).click(function(){
			if (typeof s == 'function') s();
			popup_box({start:f, title:t, content:c.show(), width:w, place:p, class:cf}, {submit:s, name:n, id:i, class:cb, value:v, close:x});
		});
	}
	$.fn.ups = function(f, t, c, w, p, cf, s, n, i, cb, v, x) {
		if(c.length) c.hide();
		$(this).click(function(){
			var items = new Array;
			$("input."+$(this).attr('ca')).each(function(){
				checked = $(this).attr("checked")? true : false;
				if(checked) {
				   items.push($(this).attr("value"));
				}
			});
			if(items.length==1) {
			 $.ajax({
			    url:BASEURL + "ajax.php?q=" + $(this).attr('ax'),
			    type:"POST",
			    data:{ d : items[0] },
			    dataType:"html"
			 }).done(function(e){
			    var obj = $.parseJSON(e);
			    c.find('input').each(function(){
			       $(this).attr('value', obj[$(this).attr('name')]);
			    });
			    if (typeof s == 'function') s(obj);
			    popup_box({start:f, title:t, content:c.show(), width:w, place:p, class:cf}, {submit:s, name:n, id:i, class:cb, value:v, close:x});
			 }).fail(function(jqXHR, textStatus) {
			    popup_box({content:"ups(): " + textStatus});
			 });
			} else if(items.length>1) {
				popup_box({ content:"This operation cannot be performed on more than one item. Select a single item and try again." }, {close:"OK"});
			} else popup_box({ content:"There is no selected item." }, {close:"OK"});
		});
	}
	$.fn.all = function(chkv){
		$(this).click(function(){
			var text = chkv.text();
			var href = $(this).find('a');
			if(text=='Check All'){
				chkv.text('Uncheck All');
				href.attr('data-original-title', 'Uncheck All');
			} else {
				chkv.text('Check All');
				href.attr('data-original-title', 'Check All');
			}
			$('input.'+$(this).attr('ca')).each(function(){
				var span = $('div.checker').find('span');
				if(text=='Check All'){
				    if(span.attr('class')==undefined || span.attr('class')=='') span.attr('class', 'checked');
				    this.checked = true;
				} else {
				    if(span.attr('class')=='checked') span.attr('class', '');
				    this.checked = false;
				}
			});
		});
	}
	$.fn.del = function(){
		$(this).click(function(){
			var items = new Array;
	    	$("input."+$(this).attr('ca')).each(function(){
	        	checked = $(this).attr("checked")? true : false;
	        	if(checked) {
	           		items.push($(this).attr("value"));
	        	}
	      	});
	      	if(items.length) {
	        	var ax = $(this).attr('ax');
	        	var hl = $(this).attr('hl');
	        	if(confirm("This action cannot be undone. Do you want to proceed?")) {
		            $.ajax({
		               url:BASEURL + "ajax.php?q=" + ax,
		               type:"POST",
		               data:{ d : items },
		               dataType:"html"
		            }).done(function(e){
		               if(isNaN(e)) popup_box({content:e}); 
		               else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
		            }).fail(function(jqXHR, textStatus) {
		               popup_box({content:"del(): " + textStatus});
		            });
	        	}
	      	} else popup_box({content:"There are no selected items." }, {close:"OK"});
		});
	}
	$.fn.act = function(){
		$(this).click(function(){
			var items = new Array;
	    	$("input."+$(this).attr('ca')).each(function(){
	        	checked = $(this).attr("checked")? true : false;
	        	if(checked) {
	           		items.push($(this).attr("value"));
	        	}
	      	});
	      	if(items.length) {
	        	var ax = $(this).attr('ax');
	        	var hl = $(this).attr('hl');
				var at = $(this).attr('at');
	        	if(confirm(ucfirst(at)+" selected "+(items.length>1? "items" : "item")+"?")) {
		            $.ajax({
		               url:BASEURL + "ajax.php?q=" + ax,
		               type:"POST",
		               data:{ d : items },
		               dataType:"html"
		            }).done(function(e){
		               if(isNaN(e)) popup_box({content:e}); 
		               else $(location).attr("href", BASEURL + ((FREEURL)? "":"?q=") + hl);
		            }).fail(function(jqXHR, textStatus) {
		               popup_box({content:"act(): " + textStatus});
		            });
	        	}
	      	} else popup_box({content:"There are no selected items." }, {close:"OK"});
		});
	}
	$.fn.img = function(){
		$(this).addClass("pointer").click(function(){
			var winh = $(window).height();
			var winw = $(window).width();
			var wint = $(window).scrollTop();
			var winl = $(window).scrollLeft();
			var path = $(this).attr('path');
			var text = $(this).html();
			var skin = $("<div></div>", { class : "uiBSgeneric_dialog_modal" });
			var data = $('<img src="'+path+'">').css({"width":"100%","height":"auto"});
			var hold = $("<div></div>", { class : "uiBSpopupwin box"});
			var head = $("<div></div>", { class : "header" });
			var list = $("<a></a>", { class : "btn", "data-original-title" : "Close" }).append('<i class="icon-remove"></i>');
			var exit = $("<div></div>", { class : "box-control pull-right" }).append(list);
			var name = $(head).append($("<h4>"+text+"</h4>")).append(exit);
			var html = $("<div></div>", { class : "content" }).append(data);
			$(hold).append(name).append(html).hide();
			$("body").append(skin.append(hold));
			var top, left;
		    top = Math.max(winh - $(hold).outerHeight(), 0) / 2;
		    left = Math.max(winw - $(hold).outerWidth(), 0) / 2;
		    $(hold).css({"top": top + wint, "left": left + winl});
		    var show = setInterval(function(){
		    	$(hold).fadeIn();
		    }, 1000);
		    $(list).click(function(){
		    	$(skin).remove();
		    	clearInterval(show);
		    });
		});
	}
});

/* filterinput.js */
(function($){  
  
    $.fn.extend({   

        filter_input: function(options) {  

          var defaults = {  
              regex:".*",
              live:false
          }  
                
          var options =  $.extend(defaults, options);  
          var regex = new RegExp(options.regex);
          
          function filter_input_function(event) {

            var key = event.charCode ? event.charCode : event.keyCode ? event.keyCode : 0;

            // 8 = backspace, 9 = tab, 13 = enter, 35 = end, 36 = home, 37 = left, 39 = right, 46 = delete
            if (key == 8 || key == 9 || key == 13 || key == 35 || key == 36|| key == 37 || key == 39 || key == 46) {

              if ($.browser.mozilla) {

                // if charCode = key & keyCode = 0
                // 35 = #, 36 = $, 37 = %, 39 = ', 46 = .
         
                if (event.charCode == 0 && event.keyCode == key) {
                  return true;                                             
                }
              }
            }


            var string = String.fromCharCode(key);
            if (regex.test(string)) {
              return true;
            } 
            return false;
          }
          
          if (options.live) {
            $(this).live('keypress', filter_input_function); 
          } else {
            return this.each(function() {  
              var input = $(this);
              input.unbind('keypress').keypress(filter_input_function);
            });  
          }
          
        }  
    });  
      
})(jQuery); 

jQuery(document).ready(function($) {

    (function() {

        var extend = {
                button      : '#backToTop',
                text        : 'Back to Top',
                min         : 200,
                fadeIn      : 400,
                fadeOut     : 400,
                speed       : 800,
                easing      : 'easeOutQuint'
            },
            oldiOS     = false,
            oldAndroid = false;
        
        // Detect if older iOS device, which doesn't support fixed position
        if( /(iPhone|iPod|iPad)\sOS\s[0-4][_\d]+/i.test(navigator.userAgent) ) oldiOS = true;

        // Detect if older Android device, which doesn't support fixed position
        if( /Android\s+([0-2][\.\d]+)/i.test(navigator.userAgent) ) oldAndroid = true;

        $('body').append('<a href="#" id="' + extend.button.substring(1) + '" title="' + extend.text + '">' + extend.text + '</a>');
        $(extend.button).hide();
        $(window).scroll(function() {

            var pos = $(window).scrollTop();
        
            if( oldiOS || oldAndroid ) {
                $( extend.button ).css({
                    'position' : 'absolute',
                    'top'      : position + $(window).height()
                });
            }
        
            if (pos > extend.min) {
                $(extend.button).fadeIn(extend.fadeIn);
            } else {
                $(extend.button).fadeOut(extend.fadeOut);
            }
            
        });

        $(extend.button).click(function(e){
            $('html, body').animate({scrollTop : 0}, extend.speed, extend.easing);
            e.preventDefault();
        });

    })();

});
