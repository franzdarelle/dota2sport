<?php
class userPage {

	public $user, $data, $menu, $form, $dota;

	function __construct($request=null) {
		$this->data = $request;
		$this->user = new SESSIONS;
		$this->form = new HTML_Form;
		$this->dota = new STEAM;
		$this->menu = getViewsContents('menu', ['user'=>$this->user]);
	}

	public function page_() {
		return $this->page_matches();
	}
	 
	public function page_signout() {
		if($this->user->getType()) {
			$teamsAJAX = new teamAJAX();
			$sportAJAX = new sportAJAX();
			$teamsAJAX->rem();
			$sportAJAX->rem();
		}
		session_destroy();
		clearstatcache();
		header('Location: ' . BASEURL);
		exit;
	}

	public function page_signin() {
		header('Location: ' . BASEURL . '?steam');
		exit;
	}

	public function page_matches() {
		if($this->user->isLogged() AND empty($_SESSION['cookieFile'])) {
			$steam = $this->user->getUser();
			if($this->user->getType()) $_SESSION['cookieFile'] = $this->dota->getCookieFile();
			else {				
				$botsTradedWith = $this->dota->getBotsTradedWith($steam);
				$botsCollection = array();

				if($botsTradedWith) {
					foreach ($botsTradedWith as $bot) {
						$botid = $bot['id'];
						$botsCollection[$botid] = $this->dota->getUserItemsCountInBot($steam, $botid);
					}
					$tradingBot = $this->dota->getBot(array_search(max($botsCollection), $botsCollection));
				} else {
					$activeBots = $this->dota->getActiveBots();
					if($activeBots) {
						foreach ($activeBots as $bot) {
							$botid = $bot['id'];
							$botsCollection[$botid] = $this->dota->getBotItemsCount($botid);
						}
						$tradingBot = $this->dota->getBot(array_search(min($botsCollection), $botsCollection));
					}
				}
				if($tradingBot) $_SESSION['cookieFile'] = implode(".", array($tradingBot['apikey'],'steam'));
			}
		}
		
		$sportID = arg(4);
		$aSports = $this->dota->getActiveSports();		
		if($sportID) $sid = $this->dota->validateSportID($sportID);
		else {
			$sportID = array();
			foreach ($aSports as $sport) {
				$sportID[] = $sport['id'];
			}
			$sid = implode(",", $sportID);
		}

		return [
			"menu" => $this->menu,
			"title" => "Matches | " . WEB_TITLE,
			"content" => getViewsContents('matches', [
				'STEAM' => $this->dota, 
				'USERS' => $this->user,
				'SPORT' => $aSports,
				'GAMES' => $this->dota->getLatestGames($sid)
			])
		];
	}

	public function page_match() {
		$gameID = arg(4);
		if($this->dota->isMatch($gameID)) {
			$match = $this->dota->getGame($gameID);
			$offer = $this->user->isLogged()? $this->dota->getTrade($this->user->getUser()) : false;
			return [
				"menu" => $this->menu,
				"title" => stripslashes($match['team1']['alias'] . ' vs ' . $match['team2']['alias'] . ' - ' . $match['event']['name'] . ' | ' . WEB_TITLE),
				"content" => getViewsContents('match', [
					'forms' => $this->form, 
					'USERS' => $this->user, 
					'STEAM' => $this->dota, 
					'FIGHT' => $match,
					'OFFER' => $offer,
					'links' => implode("/", array(MAIN_CLASS, USER_CLASS, "match", $gameID))
				])
			];
		} else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
	}

	public function page_bets() {
		$this->authenticate();
		return [
			"menu" => $this->menu,
			"title" => "Bets | " . WEB_TITLE,
			"content" => getViewsContents('bets', [
				'USERS' => $this->user, 
				'STEAM' => $this->dota, 
				'STAKE' => $this->dota->getUserStakes($this->user->getUser())
			])
		];
	}

	public function page_items() {
		$this->authenticate();
		return [
			"menu" => $this->menu,
			"title" => "Items | " . WEB_TITLE,
			"content" => getViewsContents('items', [
				'forms' => $this->form, 
				'USERS' => $this->user, 
				'STEAM' => $this->dota, 
				'OFFER' => $this->dota->getTrade($this->user->getUser()),
				'links' => implode("/", array(MAIN_CLASS, USER_CLASS, "items"))
			])
		];
	}

	public function authenticate($user=true) {
		if($user? $this->user->getUser() : $this->user->getType()) return $this;
		else {
			header('Location: ' . generateUrl(PAGE_HOME));
			exit;
		}
	}
}

class bartPage extends userPage {

	public function page_sport() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Sport | " . WEB_TITLE,
			"content" => getViewsContents('sport', [
				'data' => $this->dota,
				'user' => $this->user,
				'form' => $this->form,
				'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'sport'))
			])
		];
	}

	public function page_event() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Event | " . WEB_TITLE,
			"content" => getViewsContents('event', [
				'data' => $this->dota,
				'user' => $this->user,
				'form' => $this->form,
				'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'event'))
			])
		];
	}

	public function page_team() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Team | " . WEB_TITLE,
			"content" => getViewsContents('team', [
				'data' => $this->dota,
				'user' => $this->user,
				'form' => $this->form,
				'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'team'))
			])
		];
	}

	public function page_game() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Game | " . WEB_TITLE,
			"content" => getViewsContents('game', [
				'data' => $this->dota,
				'user' => $this->user,
				'form' => $this->form,
				'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'game'))
			])
		];
	}

	public function page_view() {
		$this->authenticate(false);
		$gameID = arg(4);
		if($this->dota->isMatch($gameID)) {
			$match = $this->dota->getGame($gameID);
			return [
				"menu" => $this->menu,
				"title" => stripslashes('Game: ' . $match['team1']['alias'] . ' vs ' . $match['team2']['alias'] . ' - ' . $match['event']['name'] . ' | ' . WEB_TITLE),
				"content" => getViewsContents('view', [
					'data' => $this->dota,
					'user' => $this->user,
					'form' => $this->form,
					'game' => $match,
					'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'view', $gameID))
				])
			];
		} else {
			header('Location: ' . generateUrl(implode('/', array(MAIN_CLASS, BART_CLASS, 'game'))));
			exit;
		}
	}

	public function page_item() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Item | " . WEB_TITLE,
			"content" => getViewsContents('item', [
				'forms' => $this->form, 
				'USERS' => $this->user, 
				'STEAM' => $this->dota, 
				'links' => implode("/", array(MAIN_CLASS, BART_CLASS, "trade/"))
			])
		];
	}

	public function page_trade() {
		$this->authenticate(false);
		$botid = arg(4);
		return [
			"menu" => $this->menu,
			"title" => "Trade | " . WEB_TITLE,
			"content" => getViewsContents('trade', [
				'bot' => $this->dota->getBot($botid),
				'forms' => $this->form, 
				'USERS' => $this->user, 
				'STEAM' => $this->dota, 
				'OFFER' => $this->dota->getTrade($this->user->getUser()),
				'links' => implode("/", array(MAIN_CLASS, BART_CLASS, "trade", $botid))
			])
		];
	}

	public function page_user() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "User | " . WEB_TITLE,
			"content" => getViewsContents('user', [
				'STEAM' => $this->dota,
				'USERS' => $this->user
			])
		];
	}

	public function page_bot() {
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Bot | " . WEB_TITLE,
			"content" => getViewsContents('bot', [
				'data' => $this->dota,
				'user' => $this->user,
				'form' => $this->form,
				'link' => implode('/', array(MAIN_CLASS, BART_CLASS, 'bot'))
			])
		];
	}

	public function page_log($args) {
		$this->authenticate(false);
		$STEAMBOT = $this->dota->getBot($args[0]);
		$steambot = $STEAMBOT['persona'];
		$username = $STEAMBOT['username'];
		$password = $STEAMBOT['password'];
		$mycookie = implode(".", array($STEAMBOT['apikey'],'steam'));
 		$BotSecret = json_decode($STEAMBOT['secret']); 		 
 		$SteamAuth = new SteamAuth;
 		$_SESSION['cookieFile'] = $mycookie;
		return [
			"menu" => $this->menu,
			"title" => implode(" | ", array($steambot, WEB_TITLE)),
			"content" => getViewsContents('log', [		 
				'STEAMWEB' => new STEAMWEB($mycookie),
				'steambot' => $steambot,
				'username' => $username,
				'password' => $password,
				'data' => $this->dota,
				'user' => $this->user,
				'code' => $SteamAuth->GenerateSteamGuardCode($BotSecret->shared_secret)			
			])
		];
	}

	public function page_chart() { 
		$this->authenticate(false);
		return [
			"menu" => $this->menu,
			"title" => "Chart | " . WEB_TITLE,
			"content" => getViewsContents('chart', [
				'STEAM' => $this->dota,
				'USERS' => $this->user,
				'JAVAS' => [
				   BASEURL.'js/charts/flot/jquery.flot.js',
				   BASEURL.'js/charts/flot/jquery.flot.pie.js',
				   BASEURL.'js/charts/flot/jquery.flot.symbol.js',
				   BASEURL.'js/charts/flot/jquery.flot.axislabels.js',
				   BASEURL.'js/charts/flot/jquery.flot.resize.js',
				   BASEURL.'js/charts/jquery.sparkline.min.js',
				   BASEURL.'js/charts-custom.js'
				],
				'YEAR' => arg(4)? arg(4) : date("Y")
			])
		];
	}
}