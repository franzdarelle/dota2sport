<?php
class gameAJAX {

	public $data, $post, $steam;

	public function __construct($data=null) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->steam= new STEAM;
	}

	public function getData() {
		return $this->data;
	}
	
	public function getPost() {
		return $this->post;
	}

	public function add() {
		$d = $this->getData();
		$r = $this->steam->addGame($d['sid'], $d['eid'], $d['team1'], $d['team2'], $d['games'], date("Y-m-d", strtotime($d['date'])).' '.$d['time'].':00', $d['stream']);
		if($r) {
			$_SESSION[$this->steam->string] = 'Game successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups() {
		$d = $this->getData();
		$r = $this->steam->editGame($d['sid'], $d['eid'], $d['team1'], $d['team2'], $d['games'], date("Y-m-d", strtotime($d['date'])).' '.$d['time'].':00', $d['stream'], $d['id']);
		if($r) {
			$_SESSION[$this->steam->string] = 'Game successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->deleteGame($d)) $c++;
		}
		if($c>0) {
			$e = ($c==1)? 'Game' : ($c .' Games');
			$_SESSION[$this->steam->string] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function get() {
		$d = $this->getPost();
		$g = $this->steam->getGame($d);
		$g['date'] = date("d-m-Y", strtotime($g['dates']));
		$g['time'] = date("H:i", strtotime($g['dates']));
		$g['hour'] = date("H", strtotime($g['dates']));
		$g['mins'] = date("i", strtotime($g['dates']));
		return json_encode($g);
	}

	public function spt() {
		$d = $this->getPost();
		if($d) {
			foreach ($this->steam->getSports() as $key => $value) {
	    		$data[] = array('id' => $value['id'], 'name' => $value['name']);
	    	}
			return json_encode($data);
		}
	}

	public function evt() {
		return json_encode($this->steam->getEventsBySid($this->getPost()));
	}

	public function tms() {
		return json_encode($this->steam->getTeamsBySid($this->getPost()));
	}

	public function gms() {
		if($this->getPost()) {
			for ($i=1; $i < 8; $i++) { 
				$data[] = array('id' => $i, 'name' => 'Best of ' . $i);
			}
			return json_encode($data);
		}
	}

	public function getGameTime() {
		$d = $this->getPost();
		if($d) {
			$g = $this->steam->getTime($d);			
			$m = $g['minute'];
			$h = $g['hour'];
			$d = $g['day'];
			if($d<0) {
				$d = abs($d);
				if($d<7) return implode(" ", array($d, (($d==1)? "day" : "days"), "ago"));
				return strtoupper(date("Y M d h:i A", strtotime($g['dates'])));
			} else {
				if($h<0) {
					$h = abs($h);
					return implode(" ", array($h, (($h==1)? "hour" : "hours"), "ago"));
				} else {
					if($h==0) {
						if($m==0) return "Just now";
						elseif($m<0) {
							$m = abs($m);
							return implode(" ", array($m, (($m==1)? "minute" : "minutes"), "ago"));
						} else
							return implode(" ", array($m, (($m==1)? "minute" : "minutes"), "from now"));
					} else
						return implode(" ", array($h, (($h==1)? "hour" : "hours"), "from now"));
				}
			} 
		}
	}

	public function setGameStatus() {
		$d = request_POST();
		if($d) {
			$gameid = $d['gameid'];
			$status = $d['status'];
			$odd1 = $d['odd1'];
			$odd2 = $d['odd2'];
			$val1 = $d['val1'];
			$val2 = $d['val2'];
			if($status) {
				$this->steam->setGameOdds($odd1, $odd2, $gameid);
				$this->steam->setGameVals($val1, $val2, $gameid);
				if($status==4) {
					$stakes = $this->steam->getGameStakes($gameid);
					if($stakes) {
						foreach ($stakes as $bet) {
							$this->steam->setItemsStake(0, $bet['items']);					
						}
					}
				}
			} else {
				$this->steam->setGameOdds(0, 0, $gameid);
				$this->steam->setGameVals(0, 0, $gameid);
			}
			if($this->steam->setGameStatus($status, $gameid)) return "Status successfully changed";
		}
	}

	public function setGameScores() {
		$d = request_POST();
		if($d) {
			$gameid = $d['gameid'];
			$scores = $d['scores'];
			$score1 = $score2 = 0;
			$games = $this->steam->getGame($gameid);
			$team1 = $games['team1']['id'];
			$team2 = $games['team2']['id'];
			$trace = array();
			foreach ($scores as $s) {
				if($s==$team1) {
					$trace[] = $team1;
					$score1++;
				} elseif($s==$team2) {
					$trace[] = $team2;
					$score2++;
				}
			}
			if($this->steam->setGameScores(implode(", ", $trace), $score1, $score2, $gameid)) return "Scores successfully changed";
		}
	}

	public function setGameWinner() {
		$d = request_POST();
		if($d) {
			$gameid = $d['gameid'];
			$winner = $d['winner'];
			$status = $d['status'];
			if($this->steam->setGameWinner($winner, $gameid)) {
				if(($status==3) AND ($winner==0)) {
					$stakes = $this->steam->getGameStakes($gameid);
					if($stakes) {
						foreach ($stakes as $bet) {
							$this->steam->setItemsStake(0, $bet['items']);					
						}
					}
				}				 
				return $winner? "Winner successfully changed" : "Game has been set as draw.";
			}
		}
	}
}