<?php
class SESSIONS {

	public $user, $data, $type;
	private $webSession = STEAMUSERS;

	public function __construct() {
		if($this->isLogged()) {
			$this->user = (empty($_SESSION[$this->webSession]['user'])) ? false : $_SESSION[$this->webSession]['user'];	
			$this->data = (empty($_SESSION[$this->webSession]['data'])) ? false : $_SESSION[$this->webSession]['data'];
			$this->type = (empty($_SESSION[$this->webSession]['type'])) ? false : $_SESSION[$this->webSession]['type'];
		}
	}	

	public function setUser($user=null) {
		if(!is_null($user)) {
			$this->user = $user;
			$_SESSION[$this->webSession]['user'] = $this->user;
		} else 
			$this->user = false;
		return $this;
	}
	
	public function getUser() {
		return $this->user;
	}
	
	public function setData($key) {
	    $http = 'http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=' . $key . '&steamids=' . $this->getUser();
	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_HEADER, 0);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
	    curl_setopt($curl, CURLOPT_URL, $http);
	    $json = curl_exec($curl);
	    curl_close($curl);
	    if(empty($json)) $json = @file_get_contents($http);
	    $code = json_decode($json);
	    $data = $code->response->players[0];
	    if($data) {
			$_SESSION[$this->webSession]['data'] = $this->data = $data;
		} else 
			$this->data = false;
		return $this;
	}

	public function getData() {
		return $this->data;
	}
	
	public function setType() {
		if(in_array($this->user, json_decode(WEB_ADMIN))) {
			$this->type = 1;
			$_SESSION[$this->webSession]['type'] = $this->type;
		} else
			$this->type = false;
		return $this;
	}
	
	public function getType(){
		return $this->type;
	}
		
	public function isLogged() {
		return isset($_SESSION[$this->webSession])? true : false;
	}
}
