<?php
class dotaAJAX {

	public $data, $file, $post, $user, $base, $curl, $auth, $cache, $appID = 570, $contextID = 2;
    
	public function __construct($data=null) {
        set_time_limit(0);
        $this->data = $data;        
        $this->post = @$_POST['d'];
        $this->file = isset($_REQUEST['cookieFile'])? $_REQUEST['cookieFile'] : @$_SESSION['cookieFile'];
        $this->user = new SESSIONS;        
        $this->curl = new STEAMWEB($this->file);
        $this->auth = new SteamAuth;
        $this->base = new STEAM;
        $this->cache = new Cache([
            'name' => 'caches',
            'path' => str_replace($this->file, "", $this->curl->cookies),
            'extension' => '.cache'
        ]);        
	}

	public function getPost() {
		return $this->post;
	}

	public function getData() {
		return $this->data;
	}

	public function steamID3($steamID64Bit) {
		return bcsub($steamID64Bit, '76561197960265728');
	}

	public function sendCookies() {
		return $this->curl->request("https://steamcommunity.com/", 'POST');
	}

    public function keepItAlive() {     
        if($this->user->isLogged() AND $this->file) {
            $bot = $this->base->getBot($this->base->getBotID(str_replace(".steam", "", $this->file)));            
            $username = $bot['username'];
            $password = $bot['password'];           
            if(strpos($this->sendCookies(), "'Logged In', 'false'")) {
                $secrets = json_decode($bot['secret']);
                $rsaJSON = $this->curl->SteamAuth("https://steamcommunity.com/login/getrsakey/", array('username'=>$username));
                $rsaDATA = json_decode($rsaJSON);
                if($rsaDATA->success AND $rsaDATA->publickey_mod AND $rsaDATA->publickey_exp AND $rsaDATA->timestamp) {
                    loadLibrary("phpseclib1.0.0/Crypt/RSA");
                    loadLibrary("phpseclib1.0.0/Math/BigInteger");
                    $RSA = new Crypt_RSA();
                    $RSA->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
                    $RSA->loadKey(array(
                        'modulus' => new Math_BigInteger($rsaDATA->publickey_mod, 16), 
                        'publicExponent' => new Math_BigInteger($rsaDATA->publickey_exp, 16)
                    ));              
                    $json = $this->curl->SteamAuth('https://steamcommunity.com/login/dologin/', array(
                        "password" => base64_encode($RSA->encrypt($password)),
                        "username" => $username,
                        "rsatimestamp" => $rsaDATA->timestamp,
                        "remember_login" => false,
                        "donotcache" => microtime(),
                        "loginfriendlyname" => strtoupper($username),                        
                        "twofactorcode" => $this->auth->GenerateSteamGuardCode($secrets->shared_secret),
                        "oauth_client_id" => "DE45CD61",
                        "oauth_scope" => "read_profile write_profile read_client write_client"
                    ));                    
                }
            }
        }
    }

	protected function getSessionID() {
		preg_match("/g_sessionID \= \"(.*)\"/i", $this->sendCookies(), $find);
		return $find[1];
	}

	protected function getSteamID() {
		preg_match("/g_steamID \= \"(.*)\"/i", $this->sendCookies(), $find);
		return $find[1];
	}

    public function FetchConfirmations() {
        if($this->user->isLogged() AND $this->file) {
            ignore_user_abort(true);
            $this->keepItAlive();
            $bot = $this->base->getBot($this->base->getBotID(str_replace(".steam", "", $this->file)));
            $BotSecret = json_decode($bot['secret']);         
            $localtime = time();
            $steamtime = time() + ($this->auth->getSteamTime(true) - $localtime);
            $page = $this->curl->request("https://steamcommunity.com/mobileconf/conf", "GET", array(
                "p" => $BotSecret->device_id,
                "a" => $bot['steam'],
                "k" => $this->auth->generateConfirmationHashForTime($BotSecret->identity_secret, $steamtime, "conf"),
                "t" => $steamtime,
                "m" => "android",
                "tag" => "conf"
            ));
            preg_match_all("'data-confid=\"(.*?)\"'si", $page, $dataConfids);
            preg_match_all("'data-key=\"(.*?)\"'si", $page, $dataKeys);            
            if(isset($dataConfids) AND isset($dataKeys)) {   
                for($i=0; $i < count($dataConfids[1]); $i++) {    
                    $localtime = time();
                    $steamtime = time() + ($this->auth->getSteamTime(true) - $localtime);       
                    $this->curl->request("https://steamcommunity.com/mobileconf/ajaxop", "GET", array(
                        "p" => $BotSecret->device_id,
                        "a" => $bot['steam'],
                        "k" => $this->auth->generateConfirmationHashForTime($BotSecret->identity_secret, $steamtime, "allow"),
                        "t" => $steamtime,
                        "m" => "android",
                        "tag" => "allow",
                        "cid" => $dataConfids[1][$i],
                        "ck" => $dataKeys[1][$i],
                        "op" => "allow"
                    ));
                }                      
            }
        }
    }

	protected function execCurlWithReferer($url, $params=array(), $referer='http://steamcommunity.com/trade/1') {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_REFERER, $referer);
        curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36");
        curl_setopt($curl, CURLOPT_HTTPHEADER, 
            array(
                'Accept: application/json, text/javascript;q=0.9, */*;q=0.5',
                'Content-type: application/x-www-form-urlencoded; charset=UTF-8'
            )
        );
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);        
        curl_setopt($curl, CURLOPT_COOKIEJAR, $this->curl->cookies);
        curl_setopt($curl, CURLOPT_COOKIEFILE, $this->curl->cookies);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params, '', '&'));
        $data = curl_exec($curl);
        if (curl_errno($curl)) {
            throw new ErrorException(curl_error($curl), curl_errno($curl));
        }
        curl_close($curl);
        return $data;
    }

    protected function execPostWithReferer($url, $params=array(), $referer='http://steamcommunity.com/trade/1') {
        $post = http_build_query($params, '', '&');
        $head = array(
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36',
            'Accept: application/json, text/javascript;q=0.9, */*;q=0.5',
            'Content-type: application/x-www-form-urlencoded; charset=UTF-8',
            'Content-Length: ' . strlen($post),
            'Cookie: ' . file_get_contents($this->curl->cookies),
            'Referer: ' . $referer
        );
        $opts = array(
            'http' => array(
                'method' => 'POST',
                'header'  => implode("\r\n", $head),
                'content' => $post,
                'ignore_errors' => true,
            ), 'ssl' => array(
                'CN_match' => parse_url($url, PHP_URL_HOST),
            ),
        );
        $context = stream_context_create($opts);
        $content = file_get_contents($url, false, $context);
        return $content;
    }

	protected function sendTradeOffer($assets, $message, $give=0) {
		$dougie = $this->user->getUser();
		$offers = $give? '{"newversion":true,"version":1,"me":{"assets":['.implode(",", $assets).'],"currency":[],"ready":true},"them":{"assets":[],"currency":[],"ready":false}}' : '{"newversion":true,"version":1,"me":{"assets":[],"currency":[],"ready":true},"them":{"assets":['.implode(",", $assets).'],"currency":[],"ready":false}}';
		$params = "{}";

		$url = "https://steamcommunity.com/tradeoffer/new/send";
        if($this->user->getType()) $ref = "https://steamcommunity.com/tradeoffer/new/?partner=" . $this->steamID3($dougie);
        else {
            $you = $this->base->getUser($dougie);
            $ref = $you['links'];
            parse_str(parse_url($ref, PHP_URL_QUERY), $str);
            $params = '{"trade_offer_access_token":"'.trim($str['token']).'"}';
        }
        $par = array(
            "sessionid" => $this->getSessionID(),
            "serverid" => "1",
            "partner" => $dougie,
            "tradeoffermessage" => $message,
            "json_tradeoffer" => $offers,
            "trade_offer_create_params" => $params
        );
        if (function_exists('curl_init') && (!in_array('https', stream_get_wrappers()) || !ini_get('safe_mode') && !ini_get('open_basedir'))) {
            return $this->execCurlWithReferer($url, $par, $ref);
        }
        return $this->execPostWithReferer($url, $par, $ref);
	}

    public function addUserTradeURL() {
        if($this->user->getUser() AND $this->getData()) {
            $url = trim($this->data['tradeURL']);
            parse_str(parse_url($url, PHP_URL_QUERY), $str);
            if(isset($str['partner']) AND isset($str['token'])) {
                $user = $this->base->getUser($this->user->getUser());
                $this->base->addUserLinks($user['id'], $url);
                return 1;
            }            
        } 
    }

	public function getUserInventory() {
		if($this->getPost()) {
            $galleries = $inventory = $dotaitems = array();
            foreach ($this->getInventory($this->user->getUser()) as $key => $val) {
                $item_categories = $this->getItemCategories($val['description']->tags);
                $item_set = $this->getItemSet($val['description']->descriptions);
                $classid = $val['classid'];
                $item = $this->base->getDota2($classid);

                if(empty($item)) continue;
                else {
                    $price = $item['price'];
                    $valid = $item['valid'];
                    if(($price==0) OR ($valid==0)) continue;
                }

                $assetid = $val['id'];
                $amount = $val['amount'];
                $name = $val['description']->name;
                $quality = $item_categories? $item_categories['quality'] : '';
                $rarity = $item_categories? $item_categories['rarity'] : '';
                $type = $item_categories? $item_categories['type'] : current(explode(' ', $val['description']->type));
                $slot = $item_categories? $item_categories['slot'] : '';
                $hero = $item_categories? $item_categories['hero'] : '';
                $icon = 'http://cdn.steamcommunity.com/economy/image/'.$val['description']->icon_url;
                $color = $item_categories? $item_categories['rarity_color'] : $val['description']->name_color;                
                $itemset = $item_set? $item_set['value'] : '';

                $galleries[$key] = $price;
                $inventory[$key] = [
                    'data' => implode('_', array($assetid, $amount)),
                    'name' => $name,
                    'quality' => $quality,
                    'rarity' => $rarity,
                    'type' => $type,
                    'slot' => $slot,
                    'hero' => $hero,
                    'icon' => $icon,
                    'color'=> '#' . $color,
                    'price'=> '$' . $price,
                    'itemset' => $itemset,
                    'classid' => $classid
                ];
            }
            arsort($galleries);
            foreach ($galleries as $key => $val) $dotaitems[] = $inventory[$key];
			return json_encode($dotaitems);
		}
	}

    public function getBotInventory() {
        $botid = $_POST['botid'];
        $botSteamID  = $this->base->getBotSteam($botid);
        $botBackpack = $this->base->getBotItems($botid);
        $myInventory = array();
        if($botBackpack AND $botSteamID) {
            foreach ($botBackpack as $item) {
                $myInventory[]  = array(
                    'data' => implode('_', array($item['assetid'], $item['amount'])),
                    'name' => $item['name'],
                    'quality' => $item['quality'],
                    'rarity' => $item['rarity'],
                    'type' => $item['type'],
                    'slot' => $item['slot'],
                    'hero' => $item['hero'],
                    'icon' => $item['icon'],
                    'color' => '#' . $item['color'],
                    'price' => '$' . $item['price'],
                    'itemset' => $item['itemset'],
                    'classid' => $item['classid'],
                    'botitem' => ($botSteamID==$item['steam'])? true : false,
                    'bettable' => $item['valid']? true : false
                );
            }
        }
        return json_encode($myInventory);
    }

    public function getBotInventorySummary() {
        $botid = $_POST['botid'];
        $botSteamID  = $this->base->getBotSteam($botid);
        $botBackpack = $this->base->getBotItems($botid);
        $count1 = $count2 = $value1 = $value2 = 0;
        $myInventory = array(
            'count1' => $count1,
            'count2' => $count2,
            'value1' => $value1,
            'value2' => $value2
        );
        if($botBackpack AND $botSteamID) {
            foreach ($botBackpack as $item) {
                if($botSteamID==$item['steam']) {                    
                    $value1 += $item['price'];
                    $count1 ++;
                } else {
                    $value2 += $item['price'];
                    $count2 ++;
                }
            }
            $myInventory['count1'] = $count1;
            $myInventory['count2'] = $count2;
            $myInventory['value1'] = $value1;
            $myInventory['value2'] = $value2;
        }
        return json_encode($myInventory);
    }

	protected function getItemCategories($tags) {
        $categories = array();
		foreach ($tags as $t) {
            switch ($t->category_name) {
                case 'Quality':
                    $categories['quality'] = $t->name;
                    $categories['quality_color'] = $t->color;
                    break;
                case 'Rarity':
                    $categories['rarity'] = $t->name;
                    $categories['rarity_color'] = $t->color;
                    break;
                case 'Type':
                    $categories['type'] = $t->name;
                    break;
                case 'Slot':
                    $categories['slot'] = $t->name;
                    break;
                case 'Hero':
                    $categories['hero'] = $t->name;
                break;
            }
		}
        return empty($categories)? null : $categories;
	}

	protected function getItemSet($descriptions) {
		if(is_array($descriptions)) {
            foreach ($descriptions as $d) {
    			if(isset($d->app_data->is_itemset_name) AND isset($d->app_data->def_index)) {
                    return [
                        'index' => $d->app_data->def_index, 
                        'value' => $d->value,
                        'color' => $d->color
                    ];
                }
    		}
        }
		return null;
	}

    protected function getContentsCurl($url) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
        curl_setopt($curl, CURLOPT_URL, $url);
        $data = curl_exec($curl);
        curl_close($curl);
        return $data;
    }

    protected function replaceTradeErrorCode($strError) {
        preg_match("/\([^)]+\)/", $strError, $found);
        if(empty($found)) return $strError;
        $errorCode = (int)str_replace(array('(',')'), array('',''), $found[0]);
        return str_replace($errorCode, $this->convertTradeErrorCode($errorCode), $strError);
    }

    protected function convertTradeErrorCode($errorCode) {
        $string = '';
        switch ($errorCode) {
            case 0:
                $string = 'Invalid';
            break; 
            case 1:
                $string = 'OK';
            break; 
            case 2:
                $string = 'Fail';
            break;            
            case 3:
                $string = 'NoConnection';
            break;
            case 4:
                $string = 'Error Code #4';//Need to update
            break;
            case 5:
                $string = 'InvalidPassword';
            break;
            case 6:
                $string = 'LoggedInElsewhere';
            break;
            case 7:
                $string = 'InvalidProtocolVer';
            break;
            case 8:
                $string = 'InvalidParam';
            break;
            case 9:
                $string = 'FileNotFound';
            break;
            case 10:
                $string = 'Busy';
            break;
            case 11:
                $string = 'InvalidState';
            break;
            case 12:
                $string = 'InvalidName';
            break;
            case 13:
                $string = 'InvalidEmail';
            break;
            case 14:
                $string = 'DuplicateName';
            break;
            case 15:
                $string = 'AccessDenied';
            break;
            case 16:
                $string = 'Timeout';
            break;
            case 17:
                $string = 'Banned';
            break;
            case 18:
                $string = 'AccountNotFound';
            break;
            case 19:
                $string = 'InvalidSteamID';
            break;
            case 20:
                $string = 'ServiceUnavailable';
            break;
            case 21:
                $string = 'NotLoggedOn';
            break;
            case 22:
                $string = 'Pending';
            break;
            case 23:
                $string = 'EncryptionFailure';
            break;
            case 24:
                $string = 'InsufficientPrivilege';
            break;
            case 25:
                $string = 'LimitExceeded';
            break;
            case 26:
                $string = 'Revoked';
            break;
            case 27:
                $string = 'Expired';
            break;
            case 28:
                $string = 'AlreadyRedeemed';
            break;
            case 29:
                $string = 'DuplicateRequest';
            break;
            case 30:
                $string = 'AlreadyOwned';
            break;
            case 31:
                $string = 'IPNotFound';
            break;
            case 32:
                $string = 'PersistFailed';
            break;
            case 33:
                $string = 'LockingFailed';
            break;
            case 34:
                $string = 'LogonSessionReplaced';
            break;
            case 35:
                $string = 'ConnectFailed';
            break;
            case 36:
                $string = 'HandshakeFailed';
            break;
            case 37:
                $string = 'IOFailure';
            break;
            case 38:
                $string = 'RemoteDisconnect';
            break;
            case 39:
                $string = 'ShoppingCartNotFound';
            break;
            case 40:
                $string = 'Blocked';
            break;
            case 41:
                $string = 'Ignored';
            break;
            case 42:
                $string = 'NoMatch';
            break;
            case 43:
                $string = 'AccountDisabled';
            break;
            case 44:
                $string = 'ServiceReadOnly';
            break;
            case 45:
                $string = 'AccountNotFeatured';
            break;
            case 46:
                $string = 'AdministratorOK';
            break;
            case 47:
                $string = 'ContentVersion';
            break;
            case 48:
                $string = 'TryAnotherCM';
            break;
            case 49:
                $string = 'PasswordRequiredToKickSession';
            break;
            case 50:
                $string = 'AlreadyLoggedInElsewhere';
            break;
            case 51:
                $string = 'Suspended';
            break;
            case 52:
                $string = 'Cancelled';
            break;
            case 53:
                $string = 'DataCorruption';
            break;
            case 54:
                $string = 'DiskFull';
            break;
            case 55:
                $string = 'RemoteCallFailed';
            break;
            case 56:
                $string = 'PasswordUnset';
            break;
            case 57:
                $string = 'ExternalAccountUnlinked';
            break;
            case 58:
                $string = 'PSNTicketInvalid';
            break;
            case 59:
                $string = 'ExternalAccountAlreadyLinked';
            break;
            case 60:
                $string = 'RemoteFileConflict';
            break;
            case 61:
                $string = 'IllegalPassword';
            break;
            case 62:
                $string = 'SameAsPreviousValue';
            break;
            case 63:
                $string = 'AccountLogonDenied';
            break;
            case 64:
                $string = 'CannotUseOldPassword';
            break;
            case 65:
                $string = 'InvalidLoginAuthCode';
            break;
            case 66:
                $string = 'AccountLogonDeniedNoMail';
            break;
            case 67:
                $string = 'HardwareNotCapableOfIPT';
            break;
            case 68:
                $string = 'IPTInitError';
            break;
            case 69:
                $string = 'ParentalControlRestricted';
            break;
            case 70:
                $string = 'FacebookQueryError';
            break;
            case 71:
                $string = 'ExpiredLoginAuthCode';
            break;
            case 72:
                $string = 'IPLoginRestrictionFailed';
            break;
            case 73:
                $string = 'AccountLockedDown';
            break;
            case 74:
                $string = 'AccountLogonDeniedVerifiedEmailRequired';
            break;
            case 75:
                $string = 'NoMatchingURL';
            break;
            case 76:
                $string = 'BadResponse';
            break;
            case 77:
                $string = 'RequirePasswordReEntry';
            break;
            case 78:
                $string = 'ValueOutOfRange';
            break;
            case 79:
                $string = 'UnexpectedError';
            break;
            case 80:
                $string = 'Disabled';
            break;
            case 81:
                $string = 'InvalidCEGSubmission';
            break;
            case 82:
                $string = 'RestrictedDevice';
            break;
            case 83:
                $string = 'RegionLocked';
            break;
            case 84:
                $string = 'RateLimitExceeded';
            break;
            case 85:
                $string = 'AccountLoginDeniedNeedTwoFactor';
            break;
            case 86:
                $string = 'ItemDeleted';
            break;
            case 87:
                $string = 'AccountLoginDeniedThrottle';
            break;
            case 88:
                $string = 'TwoFactorCodeMismatch';
            break;
            case 89:
                $string = 'TwoFactorActivationCodeMismatch';
            break;
            case 90:
                $string = 'AccountAssociatedToMultiplePartners';
            break;
            case 91:
                $string = 'NotModified';
            break;
            case 92:
                $string = 'NoMobileDevice';
            break;
            case 93:
                $string = 'TimeNotSynced';
            break;
            case 94:
                $string = 'SMSCodeFailed';
            break;
            case 95:
                $string = 'AccountLimitExceeded';
            break;
            case 96:
                $string = 'AccountActivityLimitExceeded';
            break;
            case 97:
                $string = 'PhoneActivityLimitExceeded';
            break;
            case 98:
                $string = 'RefundToWallet';
            break;
            case 99:
                $string = 'EmailSendFailure';
            break;
            case 100:
                $string = 'NotSettled';
            break;
        }
        return $string;
    }

    protected function getTradeOfferLink($tradeofferid, $tradecode=null, $botname=null, $seconds=null) {
        $link = '<a href="https://steamcommunity.com/tradeoffer/'.$tradeofferid.'/" target="_blank">Respond to Trade Offer</a>';
        if($tradecode) $link.= '<div><b>Protection Code</b>: '.$tradecode.'</div>';
        if($botname) $link.= '<div>'.$botname.'</div>';
        if($seconds) $link.= '<div>'.$seconds.'</div>';
        return $link;
    }

    public function computeRewards() {
        $gameid = $this->getPost();
        if($gameid) { 

            /* 
             * $game = game details, 
             * $stakes = bets/stakes, 
             * $winner = team id of winner 
             */

            $game = $this->base->getGame($gameid);
            $stakes = $this->base->getGameStakes($gameid);
            $winner = $game['winner'];

            if($stakes AND $winner) {

                ignore_user_abort(true);

                /*
                 * paghiwalayin yung winner at loser items 
                 * $key = stakeid_steam, eg. 1_76561198108003713
                 * $bet = item ids, eg. 1, 2, 3, 4
                 * $val = user's reward value, eg. 0.12
                 */

                $winnerItems = $losersItems = $userRewards = array();

                foreach ($stakes as $stake) {    
                    $key = implode("_", array($stake['stakeID'], $stake['steam']));
                    $bet = $stake['items'];
                    $val = $this->base->getItemsPrice($bet);                                    
                    if($stake['team']==$winner) {
                        $winnerItems[$key] = $bet;
                        $userRewards[$key] = $val;
                    } else {
                        $losersItems[$key] = $bet;
                    }
                }          

                /*
                 * higher bet amount is our first priority
                 * so we arsort it, and then array_merge
                 */

                arsort($userRewards);
                $winnerItems = array_merge($userRewards, $winnerItems);

                /*
                 * claim losers items, set item's steam to steamid of our bot whose holding it then,
                 * set item's stake to 0 (stake 1 is nakapusta, 0 hindi)
                 */

                foreach ($losersItems as $item) {
                    foreach (explode(", ", $item) as $itemid) {
                        $pack = $this->base->getPack($itemid);
                        if($this->base->setItemsSteam($this->base->getBotSteam($pack['botid']), $itemid)) {
                            $this->base->setItemsStake(0, $itemid);
                        }
                    }
                }

                /*
                 * we go now to the winners, computation of rewards
                 * $val1 = total bet amount in team1
                 * $val2 = total bet amount in team2
                 */

                $val1 = $game['val1'];
                $val2 = $game['val2'];                

                foreach ($winnerItems as $key => $item) {

                    /*
                     * we get, stakeid and steamid from $key
                     * $stakedValue = value ng pinusta ni user
                     * $rewardValue = value na makukuha nya, less na yung 5% natin
                     * $itemsreturned = html to nung items na makukuha nya (stake na table: itemsreturned field, just like itemsplaced)
                     * $needtobeexact = if $rewardValue less than $1, we should return exact value as posible as we can
                     * else if $rewardValue > $1, item(s) whose value is less than $0.05 is good enough to return
                     */

                    $id = explode("_", $key);
                    $stakeid = $id[0];
                    $steamid = $id[1];                    
                    $stakedValue = $this->base->getItemsPrice($item);
                    if($winner==$game['team1']['id']) {
                        $rewardValue = round(($val2*$stakedValue/$val1) * 95) / 100;                       
                    } else {
                        $rewardValue = round(($val1*$stakedValue/$val2) * 95) / 100;
                    }
                    $needtobeexact = ($rewardValue < 1)? 1 : 0;
                    $itemsreturned = '';

                    /* return user items (bet) */

                    $this->base->setItemsStake(0, $item);

                    $botsSteamIDs = array();
                    $botsInvolved = $this->base->getBotsInvolved($item);

                    foreach ($botsInvolved as $bot) {   

                        $botsteam = $bot['steam'];
                        array_push($botsSteamIDs, $botsteam);

                        $found = $this->base->getUserItemsWhosePriceIs($botsteam, $rewardValue, '=');
                        if($found) {
                            $reward = $found[0];
                            if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                    'name' => $reward['name'],
                                    'icon' => $reward['icon'],
                                    'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                    'price' => '$' . $reward['price'],
                                    'color' => '#' . $reward['color'],
                                    'rarity' => $reward['rarity']
                                )));
                                if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                            }
                        } else {
                            $found = $this->base->getUserItemsWhosePriceIs($botsteam, $rewardValue, '<');
                            if($found) {

                                $closest = $found[0];
                                $deficit = $rewardValue - $closest['price'];
                                $ceiling = $rewardValue - 0.05;

                                if(!$needtobeexact) {
                                    if($deficit <= 0.05) {
                                        if($this->base->setItemsSteam($steamid, $closest['itemid'])) {
                                            $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                'name' => $closest['name'],
                                                'icon' => $closest['icon'],
                                                'data' => implode("_", array($closest['assetid'], $closest['classid'])),
                                                'price' => '$' . $closest['price'],
                                                'color' => '#' . $closest['color'],
                                                'rarity' => $closest['rarity']
                                            ))); 
                                            if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;                                               
                                        }
                                    }
                                }

                                $botItems = array();
                                foreach ($found as $botitem) $botItems[] = $botitem['price'];

                                if($rewardValue > array_sum($botItems)) continue;

                                asort($botItems);

                                for ($i=2; $i < count($botItems); $i++) { 
                                    $n = sizeof($botItems)/sizeof($botItems[0]);
                                    $d = array();
                                    $c = array();
                                    $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);
                                    $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                    if ($keyOfSet) {
                                        $rewards = $c[$keyOfSet];
                                        foreach ($rewards as $price) {
                                            $search = $this->base->getUserItemsWhosePriceIs($botsteam, $price, '=');
                                            $reward = $search[0]; 
                                            if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                    'name' => $reward['name'],
                                                    'icon' => $reward['icon'],
                                                    'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                    'price' => '$' . $reward['price'],
                                                    'color' => '#' . $reward['color'],
                                                    'rarity' => $reward['rarity']
                                                )));                                            
                                            }                    
                                        }
                                        if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                    } else {
                                        if(!$needtobeexact) {                          
                                            foreach ($c as $set) {
                                                $setValue = array_sum($set);                                          
                                                if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                    foreach ($set as $price) {
                                                        $search = $this->base->getUserItemsWhosePriceIs($botsteam, $price, '=');
                                                        $reward = $search[0]; 
                                                        if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                            $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                'name' => $reward['name'],
                                                                'icon' => $reward['icon'],
                                                                'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                'price' => '$' . $reward['price'],
                                                                'color' => '#' . $reward['color'],
                                                                'rarity' => $reward['rarity']
                                                            )));                                            
                                                        }                    
                                                    }
                                                    if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                }                                           
                                            }                                            
                                        }
                                    }
                                    if($itemsreturned) break;
                                }
                            }
                        }

                        if($itemsreturned) break;
                    }

                    /* try in bots involved combined */

                    if($itemsreturned) continue;
                    else {
                        $botsteams = implode(",", $botsSteamIDs);

                        $found = $this->base->getUserItemsWhosePriceIs($botsteams, $rewardValue, '<');
                        if($found) {

                            $botItems = array();
                            foreach ($found as $botitem) $botItems[] = $botitem['price'];

                            if($rewardValue > array_sum($botItems)) continue;

                            asort($botItems);

                            for ($i=2; $i < count($botItems); $i++) { 
                                $n = sizeof($botItems)/sizeof($botItems[0]);
                                $d = array();
                                $c = array();
                                $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);                                
                                $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                if ($keyOfSet) {
                                    $rewards = $c[$keyOfSet];
                                    foreach ($rewards as $price) {
                                        $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                        $reward = $search[0]; 
                                        if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                            $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                'name' => $reward['name'],
                                                'icon' => $reward['icon'],
                                                'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                'price' => '$' . $reward['price'],
                                                'color' => '#' . $reward['color'],
                                                'rarity' => $reward['rarity']
                                            )));                                            
                                        }                    
                                    }
                                    if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                } else {
                                    if(!$needtobeexact) {                          
                                        foreach ($c as $set) {
                                            $setValue = array_sum($set);                                          
                                            if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                foreach ($set as $price) {
                                                    $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                    $reward = $search[0]; 
                                                    if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                        $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                            'name' => $reward['name'],
                                                            'icon' => $reward['icon'],
                                                            'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                            'price' => '$' . $reward['price'],
                                                            'color' => '#' . $reward['color'],
                                                            'rarity' => $reward['rarity']
                                                        )));                                            
                                                    }                    
                                                }
                                                if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                            }                                           
                                        }
                                    }
                                }
                                if($itemsreturned) break;
                            }
                        }
                    }

                    if($itemsreturned) continue;
                    else {
                        $steamOther = array();
                        $activeBots = $this->base->getActiveBots();                        

                        if(count($activeBots) > count($botsSteamIDs)) {

                            /* try in each other active bots */

                            foreach ($activeBots as $bot) {   

                                $botsteam = $bot['steam'];
                                if(in_array($botsteam, $botsSteamIDs)) continue;
                                array_push($steamOther, $botsteam);

                                $found = $this->base->getUserItemsWhosePriceIs($botsteam, $rewardValue, '=');
                                if($found) {
                                    $reward = $found[0];
                                    if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                        $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                            'name' => $reward['name'],
                                            'icon' => $reward['icon'],
                                            'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                            'price' => '$' . $reward['price'],
                                            'color' => '#' . $reward['color'],
                                            'rarity' => $reward['rarity']
                                        )));
                                        if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                    }
                                } else {
                                    $found = $this->base->getUserItemsWhosePriceIs($botsteam, $rewardValue, '<');
                                    if($found) {

                                        $closest = $found[0];
                                        $deficit = $rewardValue - $closest['price'];
                                        $ceiling = $rewardValue - 0.05;

                                        if(!$needtobeexact) {
                                            if($deficit <= 0.05) {
                                                if($this->base->setItemsSteam($steamid, $closest['itemid'])) {
                                                    $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                        'name' => $closest['name'],
                                                        'icon' => $closest['icon'],
                                                        'data' => implode("_", array($closest['assetid'], $closest['classid'])),
                                                        'price' => '$' . $closest['price'],
                                                        'color' => '#' . $closest['color'],
                                                        'rarity' => $closest['rarity']
                                                    ))); 
                                                    if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;                                               
                                                }
                                            }
                                        }

                                        $botItems = array();
                                        foreach ($found as $botitem) $botItems[] = $botitem['price'];

                                        if($rewardValue > array_sum($botItems)) continue;

                                        asort($botItems);

                                        for ($i=2; $i < count($botItems); $i++) { 
                                            $n = sizeof($botItems)/sizeof($botItems[0]);
                                            $d = array();
                                            $c = array();
                                            $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);
                                            $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                            if ($keyOfSet) {
                                                $rewards = $c[$keyOfSet];
                                                foreach ($rewards as $price) {
                                                    $search = $this->base->getUserItemsWhosePriceIs($botsteam, $price, '=');
                                                    $reward = $search[0]; 
                                                    if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                        $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                            'name' => $reward['name'],
                                                            'icon' => $reward['icon'],
                                                            'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                            'price' => '$' . $reward['price'],
                                                            'color' => '#' . $reward['color'],
                                                            'rarity' => $reward['rarity']
                                                        )));                                            
                                                    }                    
                                                }
                                                if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                            } else {
                                                if(!$needtobeexact) {                          
                                                    foreach ($c as $set) {
                                                        $setValue = array_sum($set);                                          
                                                        if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                            foreach ($set as $price) {
                                                                $search = $this->base->getUserItemsWhosePriceIs($botsteam, $price, '=');
                                                                $reward = $search[0]; 
                                                                if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                                    $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                        'name' => $reward['name'],
                                                                        'icon' => $reward['icon'],
                                                                        'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                        'price' => '$' . $reward['price'],
                                                                        'color' => '#' . $reward['color'],
                                                                        'rarity' => $reward['rarity']
                                                                    )));                                            
                                                                }                    
                                                            }
                                                            if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                        }                                           
                                                    }                                            
                                                }
                                            }
                                            if($itemsreturned) break;
                                        }
                                    }
                                }

                                if($itemsreturned) break;
                            }

                            /* try in each other active bots and bots involved combined */

                            if($itemsreturned) continue;
                            else {                            
                                foreach ($steamOther as $bot) {

                                    $botsteams = implode(",", array_merge($botsSteamIDs, array($bot)));

                                    $found = $this->base->getUserItemsWhosePriceIs($botsteams, $rewardValue, '=');
                                    if($found) {
                                        $reward = $found[0];
                                        if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                            $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                'name' => $reward['name'],
                                                'icon' => $reward['icon'],
                                                'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                'price' => '$' . $reward['price'],
                                                'color' => '#' . $reward['color'],
                                                'rarity' => $reward['rarity']
                                            )));
                                            if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                        }
                                    } else {
                                        $found = $this->base->getUserItemsWhosePriceIs($botsteams, $rewardValue, '<');
                                        if($found) {

                                            $closest = $found[0];
                                            $deficit = $rewardValue - $closest['price'];
                                            $ceiling = $rewardValue - 0.05;

                                            if(!$needtobeexact) {
                                                if($deficit <= 0.05) {
                                                    if($this->base->setItemsSteam($steamid, $closest['itemid'])) {
                                                        $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                            'name' => $closest['name'],
                                                            'icon' => $closest['icon'],
                                                            'data' => implode("_", array($closest['assetid'], $closest['classid'])),
                                                            'price' => '$' . $closest['price'],
                                                            'color' => '#' . $closest['color'],
                                                            'rarity' => $closest['rarity']
                                                        ))); 
                                                        if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;                                               
                                                    }
                                                }
                                            }

                                            $botItems = array();
                                            foreach ($found as $botitem) $botItems[] = $botitem['price'];

                                            if($rewardValue > array_sum($botItems)) continue;

                                            asort($botItems);

                                            for ($i=2; $i < count($botItems); $i++) { 
                                                $n = sizeof($botItems)/sizeof($botItems[0]);
                                                $d = array();
                                                $c = array();
                                                $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);
                                                $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                                if ($keyOfSet) {
                                                    $rewards = $c[$keyOfSet];
                                                    foreach ($rewards as $price) {
                                                        $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                        $reward = $search[0]; 
                                                        if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                            $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                'name' => $reward['name'],
                                                                'icon' => $reward['icon'],
                                                                'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                'price' => '$' . $reward['price'],
                                                                'color' => '#' . $reward['color'],
                                                                'rarity' => $reward['rarity']
                                                            )));                                            
                                                        }                    
                                                    }
                                                    if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                } else {
                                                    if(!$needtobeexact) {                          
                                                        foreach ($c as $set) {
                                                            $setValue = array_sum($set);                                          
                                                            if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                                foreach ($set as $price) {
                                                                    $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                                    $reward = $search[0]; 
                                                                    if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                                        $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                            'name' => $reward['name'],
                                                                            'icon' => $reward['icon'],
                                                                            'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                            'price' => '$' . $reward['price'],
                                                                            'color' => '#' . $reward['color'],
                                                                            'rarity' => $reward['rarity']
                                                                        )));                                            
                                                                    }                    
                                                                }
                                                                if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                            }                                           
                                                        }                                            
                                                    }
                                                }
                                                if($itemsreturned) break;
                                            }
                                        }
                                    }

                                    if($itemsreturned) break;
                                }
                            }

                            /* try in all other active bots combined */

                            if($itemsreturned) continue;
                            else {                                
                                $botsteams = implode(",", $steamOther);

                                $found = $this->base->getUserItemsWhosePriceIs($botsteams, $rewardValue, '<');
                                if($found) {

                                    $botItems = array();
                                    foreach ($found as $botitem) $botItems[] = $botitem['price'];

                                    if($rewardValue > array_sum($botItems)) continue;

                                    asort($botItems);

                                    for ($i=2; $i < count($botItems); $i++) { 
                                        $n = sizeof($botItems)/sizeof($botItems[0]);
                                        $d = array();
                                        $c = array();
                                        $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);                                
                                        $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                        if ($keyOfSet) {
                                            $rewards = $c[$keyOfSet];
                                            foreach ($rewards as $price) {
                                                $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                $reward = $search[0]; 
                                                if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                    $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                        'name' => $reward['name'],
                                                        'icon' => $reward['icon'],
                                                        'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                        'price' => '$' . $reward['price'],
                                                        'color' => '#' . $reward['color'],
                                                        'rarity' => $reward['rarity']
                                                    )));                                            
                                                }                    
                                            }
                                            if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                        } else {
                                            if(!$needtobeexact) {                          
                                                foreach ($c as $set) {
                                                    $setValue = array_sum($set);                                          
                                                    if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                        foreach ($set as $price) {
                                                            $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                            $reward = $search[0]; 
                                                            if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                                $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                    'name' => $reward['name'],
                                                                    'icon' => $reward['icon'],
                                                                    'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                    'price' => '$' . $reward['price'],
                                                                    'color' => '#' . $reward['color'],
                                                                    'rarity' => $reward['rarity']
                                                                )));                                            
                                                            }                    
                                                        }
                                                        if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                    }                                           
                                                }
                                            }
                                        }
                                        if($itemsreturned) break;
                                    }
                                }
                            }

                            /* try in all active bots combined */

                            if($itemsreturned) continue;
                            else {
                                $botsteams = implode(",", array_merge($botsSteamIDs, $steamOther));

                                $found = $this->base->getUserItemsWhosePriceIs($botsteams, $rewardValue, '<');
                                if($found) {

                                    $botItems = array();
                                    foreach ($found as $botitem) $botItems[] = $botitem['price'];

                                    if($rewardValue > array_sum($botItems)) continue;

                                    asort($botItems);

                                    for ($i=2; $i < count($botItems); $i++) { 
                                        $n = sizeof($botItems)/sizeof($botItems[0]);
                                        $d = array();
                                        $c = array();
                                        $this->getItemCombinations($botItems, $n, $i, 0, $d, 0, $c);                                
                                        $keyOfSet = array_search($rewardValue, array_map("array_sum", $c));
                                        if ($keyOfSet) {
                                            $rewards = $c[$keyOfSet];
                                            foreach ($rewards as $price) {
                                                $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                $reward = $search[0]; 
                                                if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                    $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                        'name' => $reward['name'],
                                                        'icon' => $reward['icon'],
                                                        'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                        'price' => '$' . $reward['price'],
                                                        'color' => '#' . $reward['color'],
                                                        'rarity' => $reward['rarity']
                                                    )));                                            
                                                }                    
                                            }
                                            if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                        } else {
                                            if(!$needtobeexact) {                          
                                                foreach ($c as $set) {
                                                    $setValue = array_sum($set);                                          
                                                    if(($setValue >= $ceiling) AND $setValue < $rewardValue) {
                                                        foreach ($set as $price) {
                                                            $search = $this->base->getUserItemsWhosePriceIs($botsteams, $price, '=');
                                                            $reward = $search[0]; 
                                                            if($this->base->setItemsSteam($steamid, $reward['itemid'])) {
                                                                $itemsreturned .= $this->base->getItem(arrayToObject(array(
                                                                    'name' => $reward['name'],
                                                                    'icon' => $reward['icon'],
                                                                    'data' => implode("_", array($reward['assetid'], $reward['classid'])),
                                                                    'price' => '$' . $reward['price'],
                                                                    'color' => '#' . $reward['color'],
                                                                    'rarity' => $reward['rarity']
                                                                )));                                            
                                                            }                    
                                                        }
                                                        if($this->base->setItemsReturned($itemsreturned, $stakeid)) break;
                                                    }                                           
                                                }
                                            }
                                        }
                                        if($itemsreturned) break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return "Rewards successfully computed";
        }
    }

    private function getItemCombinations($arr, $n, $r, $index, $data, $i, &$c) {
        if ($index == $r) {
            $set = array();
            for ($j=0; $j<$r; $j++) array_push($set, $data[$j]);
            return $c[] = $set;
        }

        if ($i >= $n) return;

        $data[$index] = $arr[$i];
        $this->getItemCombinations($arr, $n, $r, $index+1, $data, $i+1, $c);

        while(isset($arr[$i+1]) AND ($arr[$i] == $arr[$i+1])) $i++;

        $this->getItemCombinations($arr, $n, $r, $index, $data, $i+1, $c);
    }

    public function placeBet() {
        ignore_user_abort(true);
        $post = request_POST();
        if($post) {
            
            $armoryItems = &$post['armoryItems'];
            $returnItems = &$post['returnItems'];
            $teamID = $post['teamID'];
            $gameID = $post['gameID']; 
            $botID = $this->base->getBotID(str_replace(".steam", "", $this->file));
            $steam = $this->user->getUser();

            if(empty($returnItems) AND empty($armoryItems)) {
                if($this->base->setTeamStake($steam, $gameID, $teamID)) return 1;
            }

            if($returnItems) {
                $stake = $this->base->getUserStake($steam, $gameID);
                if($stake) {
                    $items = explode(", ", $stake['items']);
                    $itemsplaced = $stake['itemsplaced'];
                } else {
                    $items = array();
                    $itemsplaced = '';
                }
                
                foreach($returnItems as $key => $val) {
                    $item = $this->base->getPack($val);
                    $items[] = $val;
                    $classid = $item['classid'];
                    $itemsplaced .= $this->base->getItem(arrayToObject(array(
                        'name' => $item['name'],
                        'icon' => $item['icon'],
                        'data' => implode("_", array($item['assetid'],$classid)),
                        'price' => '$' . $this->base->getDota2($classid, "price"),
                        'color' => '#' . $item['color'],
                        'rarity' => $item['rarity']
                    )));
                }

                $itemids = implode(", ", $items);
                $stake? $this->base->setStake($teamID, $itemids, $itemsplaced, $stake['id']) : 
                        $this->base->addStake($steam, $teamID, $itemids, $itemsplaced, $gameID);
                $this->base->setItemsStake(1, $itemids);
            }

            if($armoryItems) {
                foreach($armoryItems as $key => $val) {                    
                    $itempack = explode(", ", $val);
                    $itemdata = explode("_", $itempack[0]); 
                    $assetid = $itemdata[0];
                    $amount = $itemdata[1];
                    $assets[] = json_encode([
                        'appid' => $this->appID,
                        'contextid' => $this->contextID,
                        'assetid' => $assetid,
                        'amount' => $amount                
                    ]);
                    $values[] = json_encode([
                        'assetid' => $assetid,
                        'amount' => $amount,
                        'name' => $itempack[1],
                        'quality' => $itempack[2],
                        'rarity' => $itempack[3],
                        'type' => $itempack[4],
                        'slot' => $itempack[5],
                        'hero' => $itempack[6],
                        'icon' => $itempack[7],
                        'color' => str_replace('#', '', $itempack[8]),
                        'price' => str_replace('$', '', $itempack[9]),
                        'itemset' => $itempack[10],
                        'classid' => $itempack[11]
                    ]);
                }

                $code = strtoupper(random_string(4));
                $json = $this->sendTradeOffer($assets, 'Protection Code: ' . $code);
                $data = json_decode($json);
                if(isset($data->tradeofferid)) {
                    $this->FetchConfirmations();
                    return $this->base->addTrade($steam, $botID, $teamID, $gameID, $data->tradeofferid, implode("-=-", $values), $code);                    
                } else
                    return $this->replaceTradeErrorCode($data->strError); 
            }
        }
    }

    public function addItemsToBot() {
        ignore_user_abort(true);
        $data = $this->getData();
        if(isset($data['items'])) {
            foreach ($data['items'] as $item) {
                $itempack = explode(", ", $item);
                $itemdata = explode("_", $itempack[0]);
                $assetid = $itemdata[0];
                $amount = $itemdata[1];
                $assets[] = json_encode([
                    'appid' => $this->appID,
                    'contextid' => $this->contextID,
                    'assetid' => $assetid,
                    'amount' => $amount                
                ]);
                $values[] = json_encode([
                    'assetid' => $assetid,
                    'amount' => $amount,
                    'name' => $itempack[1],
                    'quality' => $itempack[2],
                    'rarity' => $itempack[3],
                    'type' => $itempack[4],
                    'slot' => $itempack[5],
                    'hero' => $itempack[6],
                    'icon' => $itempack[7],
                    'color' => str_replace('#', '', $itempack[8]),
                    'price' => str_replace('$', '', $itempack[9]),
                    'itemset' => $itempack[10],
                    'classid' => $itempack[11]
                ]);
            }

            $code = strtoupper(random_string(4));
            $json = $this->sendTradeOffer($assets, 'Protection Code: ' . $code);
            $data = json_decode($json);
            if(isset($data->tradeofferid)) {
                $this->FetchConfirmations();
                return $this->base->addTrade($this->user->getUser(), $this->base->getBotID(str_replace(".steam", "", $this->file)), 0, 0, $data->tradeofferid, implode("-=-", $values), $code);
            } else
                return $this->replaceTradeErrorCode($data->strError);             
        } else
            return "Please put some items";
    }

    public function getItemsInBot() {
        ignore_user_abort(true);
        $data = $this->getData();
        if(isset($data['items'])) {
            foreach ($data['items'] as $item) {
                $itempack = explode(", ", $item);
                $itemdata = explode("_", $itempack[0]);
                $assetid = $itemdata[0];
                $amount = $itemdata[1];
                $assets[] = json_encode([
                    'appid' => $this->appID,
                    'contextid' => $this->contextID,
                    'assetid' => $assetid,
                    'amount' => $amount                
                ]);
                $values[] = json_encode([
                    'assetid' => $assetid,
                    'amount' => $amount,
                    'name' => $itempack[1],
                    'quality' => $itempack[2],
                    'rarity' => $itempack[3],
                    'type' => $itempack[4],
                    'slot' => $itempack[5],
                    'hero' => $itempack[6],
                    'icon' => $itempack[7],
                    'color' => str_replace('#', '', $itempack[8]),
                    'price' => str_replace('$', '', $itempack[9]),
                    'itemset' => $itempack[10],
                    'classid' => $itempack[11]
                ]);
            }

            $code = strtoupper(random_string(4));
            $json = $this->sendTradeOffer($assets, 'Protection Code: ' . $code, 1);
            $data = json_decode($json);
            if(isset($data->tradeofferid)) {
                $this->FetchConfirmations();
                return $this->base->addTrade($this->user->getUser(), $this->base->getBotID(str_replace(".steam", "", $this->file)), 0, 0, $data->tradeofferid, implode("-=-", $values), $code, 1);
            } else
                return $this->replaceTradeErrorCode($data->strError);
        } else
            return "Please put some items";
    }

    public function getUserBotsTradedWith() {
        $steam = $this->user->getUser();
        if($this->getPost() AND $steam) {            
            $botsTradedWith = $this->base->getBotsTradedWith($steam);
            $botsCollection = array();
            foreach ($botsTradedWith as $bot) {
                $botid = $bot['id'];
                $items = array();
                foreach ($this->base->getUserReturnItems($steam, $botid) as $item) {
                    $items[] = $item['itemid'];
                }
                $botsCollection[] = array(
                    'persona' => $bot['persona'],
                    'apikey' => implode(".", array($bot['apikey'],'steam')),                    
                    'items' => implode(", ", $items),
                    'count' => count($items)
                );
            }            
            return json_encode($botsCollection);
        }
    }

    public function getUserReturns() {
        if($this->getPost()) {
            $items = array();
            foreach ($this->base->getItems($this->getPost()) as $item) {
                $items[] = array(
                    'data' => implode('_', array($item['assetid'], $item['amount'])),
                    'name' => $item['name'],
                    'quality' => $item['quality'],
                    'rarity' => $item['rarity'],
                    'type' => $item['type'],
                    'slot' => $item['slot'],
                    'hero' => $item['hero'],
                    'icon' => $item['icon'],
                    'color' => '#' . $item['color'],
                    'price' => '$' . $item['price'],
                    'itemset' => $item['itemset'],
                    'classid' => $item['classid']
                );
            }
            return json_encode($items);
        }
    }

    public function getUserBackPack() {
        $items = array();
        $steam = $this->user->getUser();
        if($this->getPost() AND $steam) {
            $returns = $this->base->getUserItems($steam);
            if($returns) {
                foreach ($returns as $item) {
                    if($item['stake']) continue;
                    $items[] = array(
                        'data' => $item['itemid'],
                        'name' => $item['name'],
                        'quality' => $item['quality'],
                        'rarity' => $item['rarity'],
                        'type' => $item['type'],
                        'slot' => $item['slot'],
                        'hero' => $item['hero'],
                        'icon' => $item['icon'],
                        'color' => '#' . $item['color'],
                        'price' => '$' . $item['price'],
                        'itemset' => $item['itemset'],
                        'bettable' => $item['valid']? true : false
                    );
                }
            }
        }
        return json_encode($items);
    }

    public function getUserItems() {
        if($this->getPost()) {
            $items = $this->base->getUserItems($this->getPost());
            if($items) {
                $html = '';
                foreach ($items as $item) {    
                    $classid = $item['classid'];             
                    $html .= $this->base->getItem(arrayToObject(array(
                        'name' => $item['name'],
                        'icon' => $item['icon'],
                        'data' => implode("_", array($item['assetid'],$classid)),
                        'price' => '$' . $item['price'],
                        'color' => '#' . $item['color'],
                        'rarity' => $item['rarity']
                    )));
                }
                return $html;
            }
        }
    }

    public function getUserStakes() {
        $gameid = $this->getPost();
        if($gameid) {
            $steam = $this->user->getUser();
            $stake = $steam? $this->base->getUserStake($steam, $gameid) : $steam;
            if($stake) {
                return json_encode(array('team'=>$stake['team'],'items'=>$stake['itemsplaced']));
            } 
        }
    }

    public function getUserRewards() {
        $gameid = $this->getPost();
        if($gameid) {
            $steam = $this->user->getUser();
            $stake = $steam? $this->base->getUserStake($steam, $gameid) : $steam;
            if($stake) {
                return json_encode(array('team'=>$stake['team'],'items'=>$stake['itemsreturned']));
            } 
        }
    }

    public function changeUserTeam() {
        $data = $this->getPost();
        if($data) {
            $gameid = $data[0];
            $teamid = $data[1];
            $team = $this->base->getTeam($teamid);
            $name = stripslashes($team['alias']);
            if($this->base->setTeamStake($this->user->getUser(), $gameid, $teamid)) return "Team successfully changed to <strong>" . $name . "</strong>";
        }
    }

    public function getGameOdds() {
        $gameid = $this->getPost();
        if($gameid) {   
            $bets = array();
            $user = $item = 0;
            $val1 = $val2 = 1;
            $odd1 = $odd2 = 50;
            $game = $this->base->getGame($gameid);
            $stakes = $this->base->getGameStakes($gameid);
            $status = $game['status'];
            if($status) {
                $betor = $price = array();
                foreach ($stakes as $stake) {
                    $stakedItems = explode(", ", $stake['items']);
                    $stakedCount = count($stakedItems);
                    $itemsplaced = $stake['itemsplaced'];                    
                    $stakedValue = 0;

                    preg_match_all("'<div class=\"itemPrice\">(.*?)</div>'si", $itemsplaced, $matches);
                    foreach($matches[0] as $itemprice) {
                        $itemsplaced = str_replace($itemprice, "", $itemsplaced);
                    }
                    foreach($matches[1] as $itemprice) {
                        $stakedValue += (double) str_replace("$", "", $itemprice);
                    }                    
                    unset($matches);

                    $price[$stake['steam']] = $stakedValue;
                    $betor[$stake['steam']] = $itemsplaced;
                    $item += $stakedCount;
                    $user ++;
                }
                arsort($price);
                $count = 0;
                $limit = 10;
                foreach ($price as $key => $val) {
                    if($count==$limit) break;
                    $count++;
                    $bets[$this->base->getUserPersona($key)] = $betor[$key];
                }
                return json_encode([
                    'odd1' => $game['odd1'],
                    'odd2' => $game['odd2'],
                    'val1' => $game['val1'],
                    'val2' => $game['val2'],
                    'user' => $user,
                    'item' => $item,
                    'bets' => $bets
                ]);
            }

            if($stakes) {
                $teamA = $teamB = 0;
                $betor = $price = array();
                foreach ($stakes as $stake) {
                    $stakedItems = explode(", ", $stake['items']);
                    $stakedCount = count($stakedItems);
                    $itemsplaced = $stake['itemsplaced'];                    
                    $stakedValue = 0;

                    preg_match_all("'<div class=\"itemPrice\">(.*?)</div>'si", $itemsplaced, $matches);
                    foreach($matches[0] as $itemprice) {
                        $itemsplaced = str_replace($itemprice, "", $itemsplaced);
                    }
                    foreach($matches[1] as $itemprice) {
                        $stakedValue += (double) str_replace("$", "", $itemprice);
                    }                    
                    unset($matches);
                    
                    if($stake['team']==$stake['team1']) {
                        $teamA += $stakedValue;
                    } else {
                        $teamB += $stakedValue;
                    }
                    $price[$stake['steam']] = $stakedValue;
                    $betor[$stake['steam']] = $itemsplaced;
                    $item += $stakedCount;
                    $user ++;
                }
                if(!$teamA OR !$teamB) {
                    $teamA++;
                    $teamB++;
                }
                $suma = $teamA + $teamB;
                $odd1 = round(($teamA / $suma) * 100);
                $odd2 = round(($teamB / $suma) * 100);
                $val1 = number_format($teamA,2);
                $val2 = number_format($teamB,2); 
                arsort($price);
                $count = 0;
                $limit = 10;
                foreach ($price as $key => $val) {
                    if($count==$limit) break;
                    $count++;
                    $bets[$this->base->getUserPersona($key)] = $betor[$key];
                }
            }
            return json_encode([
                'odd1' => $odd1,
                'odd2' => $odd2,
                'val1' => $val1,
                'val2' => $val2,
                'user' => $user,
                'item' => $item,
                'bets' => $bets
            ]);
        }
    }

    public function checkAdminOffer() {
        $tradeID = $this->getPost();
        $offered = $this->getTradeOffer($tradeID);
        if(@$offered->offer->is_our_offer) {

            $trade = $this->base->getTrade($this->user->getUser());
            $botid = $trade['botid'];

            switch (@$offered->offer->trade_offer_state) {
                case 1: #Invalid 
                case 4: #The recipient made a counter offer 
                case 5: #The trade offer was not accepted before the expiration date  
                case 6: #The sender cancelled the offer 
                case 7: #The recipient declined the offer 
                case 8: #Some of the items in the offer are no longer available (indicated by the missing flag in the output) 
                case 10: #The receiver cancelled the offer via email 
                    if($this->base->cancelTrade($tradeID)) return 1;
                break;
                case 3: #The trade offer was accepted by the recipient and items were exchanged.
                    ignore_user_abort(true);
                    $tradetype = $trade['tradetype'];
                    $tradeofferitems = explode("-=-", $trade['tradeofferitems']);

                    if($tradetype) {
                        foreach ($tradeofferitems as $offeritem) {
                            $item = json_decode($offeritem);
                            $this->base->deleteItem($item->assetid);
                        }
                        if($this->base->cancelTrade($tradeID)) return 1;
                    } else {                        
                        preg_match_all("/oItem \= (.*);/", $this->curl->request("https://steamcommunity.com/trade/".$offered->offer->tradeid."/receipt", 'POST'), $oItem);
                        $steamid = $this->base->getBotSteam($botid);

                        foreach ($tradeofferitems as $offeritem) {
                            $item = json_decode($offeritem);
                            $assetid = $item->assetid;
                            $amount = $item->amount;
                            $name = $item->name;
                            $quality = $item->quality;
                            $rarity = $item->rarity;
                            $type = $item->type;
                            $slot = $item->slot;
                            $hero = $item->hero;
                            $icon = $item->icon; 
                            $color = $item->color;
                            $price = $item->price;
                            $itemset = $item->itemset;
                            $classid = $item->classid;

                            foreach ($oItem[1] as $received) {
                                $asset = json_decode($received);
                                if($asset->classid==$classid) {
                                    $assetid = $asset->id;
                                    break;
                                }
                            }

                            $this->base->addPack($assetid, $classid, $amount, $name, $quality, $rarity, $type, $slot, $hero, $icon, $color, $itemset, $botid);
                            $this->base->addItem($assetid, $steamid, 0);
                        }

                        if($this->base->cancelTrade($tradeID)) return 1;
                    }
                break;
            }
            $time_created = @$offered->offer->time_created;
            $time_updated = @$offered->offer->time_updated;
            $seconds = 500 - (time() - $time_created);
            if($seconds > 0) {
                $remaining = $seconds . (($seconds>1)? " seconds" : " second");
                return $this->getTradeOfferLink($tradeID, $trade['tradecode'], $this->base->getBotPersona($botid), $remaining);
            } else {
                $this->cancelTradeOffer($tradeID);
                if($this->base->cancelTrade($tradeID)) return 1;
            }
        } else {
            $this->declineTradeOffer($tradeID);
            if($this->base->cancelTrade($tradeID)) return 1;
        }
    }

    public function checkTradeOffer() {
        $tradeID = $this->getPost();
        $offered = $this->getTradeOffer($tradeID);
        if(@$offered->offer->is_our_offer) {

            $steam = $this->user->getUser();
            $trade = $this->base->getTrade($steam);
            $botid = $trade['botid'];

            switch (@$offered->offer->trade_offer_state) {
                case 1: #Invalid 
                case 4: #The recipient made a counter offer 
                case 5: #The trade offer was not accepted before the expiration date  
                case 6: #The sender cancelled the offer 
                case 7: #The recipient declined the offer 
                case 8: #Some of the items in the offer are no longer available (indicated by the missing flag in the output) 
                case 10: #The receiver cancelled the offer via email 
                    if($this->base->cancelTrade($tradeID)) return 1;
                break;
                case 3: #The trade offer was accepted by the recipient and items were exchanged.
                    ignore_user_abort(true);
                    $teamid = $trade['teamid'];
                    $gameid = $trade['gameid'];
                    $tradetype = $trade['tradetype'];
                    $tradeofferitems = explode("-=-", $trade['tradeofferitems']);

                    if($tradetype) {
                        foreach ($tradeofferitems as $offeritem) {
                            $item = json_decode($offeritem);
                            $this->base->deleteItem($item->assetid);
                        }
                        if($this->base->cancelTrade($tradeID)) return 1;
                    } else {

                        preg_match_all("/oItem \= (.*);/", $this->curl->request("https://steamcommunity.com/trade/".$offered->offer->tradeid."/receipt", 'POST'), $oItem);
                        $stake = $this->base->getUserStake($steam, $gameid);
                        if($stake) {
                            $items = explode(", ", $stake['items']);
                            $itemsplaced = $stake['itemsplaced'];
                        } else {
                            $items = array();
                            $itemsplaced = '';
                        }       

                        foreach ($tradeofferitems as $offeritem) {
                            $item = json_decode($offeritem);
                            $assetid = $item->assetid;
                            $amount = $item->amount;
                            $name = $item->name;
                            $quality = $item->quality;
                            $rarity = $item->rarity;
                            $type = $item->type;
                            $slot = $item->slot;
                            $hero = $item->hero;
                            $icon = $item->icon; 
                            $color = $item->color;
                            $price = $item->price;
                            $itemset = $item->itemset;
                            $classid = $item->classid;

                            foreach ($oItem[1] as $received) {
                                $asset = json_decode($received);
                                if($asset->classid==$classid) {
                                    $assetid = $asset->id;
                                    break;
                                }
                            }

                            $this->base->addPack($assetid, $classid, $amount, $name, $quality, $rarity, $type, $slot, $hero, $icon, $color, $itemset, $botid);
                            $items[] = $this->base->addItem($assetid, $steam);
                            
                            $itemsplaced .= $this->base->getItem(arrayToObject(array(
                                'name' => $name,
                                'icon' => $icon,
                                'data' => implode("_", array($assetid,$classid)),
                                'price' => '$' . $price,
                                'color' => '#' . $color,
                                'rarity' => $rarity
                            )));
                        }
                        
                        $itemids = implode(", ", $items);
                        $stake? $this->base->setStake($teamid, $itemids, $itemsplaced, $stake['id']) : 
                                $this->base->addStake($steam, $teamid, $itemids, $itemsplaced, $gameid);
                        if($this->base->cancelTrade($tradeID)) return 1;
                    }
                break;
            }
            $time_created = @$offered->offer->time_created;
            $time_updated = @$offered->offer->time_updated;
            $seconds = 500 - (time() - $time_created);
            if($seconds > 0) {
                $remaining = $seconds . (($seconds>1)? " seconds" : " second");
                return $this->getTradeOfferLink($tradeID, $trade['tradecode'], $this->base->getBotPersona($botid), $remaining);
            } else {
                $this->cancelTradeOffer($tradeID);
                if($this->base->cancelTrade($tradeID)) return 1;
            }
        } else {
            $this->declineTradeOffer($tradeID);
            if($this->base->cancelTrade($tradeID)) return 1;
        }
    }

    private function cancelTradeOffer($tradeofferid) {
        $url = "https://steamcommunity.com/tradeoffer/".$tradeofferid."/cancel";
        $ref = "https://steamcommunity.com/tradeoffer/".$tradeofferid."/";
        $par = array(
            "sessionid" => $this->getSessionID(),
            "serverid" => "1"
        );;
        if (function_exists('curl_init') && (!in_array('https', stream_get_wrappers()) || !ini_get('safe_mode') && !ini_get('open_basedir'))) {
            return $this->execCurlWithReferer($url, $par, $ref);
        }
        return $this->execPostWithReferer($url, $par, $ref);
    }

    private function declineTradeOffer($tradeofferid) {
        $url = "https://steamcommunity.com/tradeoffer/".$tradeofferid."/decline";
        $ref = "https://steamcommunity.com/tradeoffer/".$tradeofferid."/";
        $par = array(
            "tradeofferid" => $tradeofferid,
            "sessionid" => $this->getSessionID(),
            "serverid" => "1"
        );;
        if (function_exists('curl_init') && (!in_array('https', stream_get_wrappers()) || !ini_get('safe_mode') && !ini_get('open_basedir'))) {
            return $this->execCurlWithReferer($url, $par, $ref);
        }
        return $this->execPostWithReferer($url, $par, $ref);
    }

    protected function getTradeOffer($tradeofferid) {
        /*
        tradeofferid - a unique identifier for the trade offer
        accountid_other - your partner in the trade offer
        message - a message included by the creator of the trade offer
        expiration_time - unix time when the offer will expire (or expired, if it is in the past)
        trade_offer_state - see ETradeOfferState above
        items_to_give - array of CEcon_Asset, items you will give up in the trade (regardless of who created the offer)
        items_to_receive - array of CEcon_Asset, items you will receive in the trade (regardless of who created the offer)
        is_our_offer - boolean to indicate this is an offer you created.
        time_created - unix timestamp of the time the offer was sent
        time_updated - unix timestamp of the time the trade_offer_state last changed.
        */
        $params = [
            "key" => str_replace(".steam", "", $this->file),
            "tradeofferid" => $tradeofferid,
            "language" => 'en_us'
        ];
        $json = $this->getContentsCurl("http://api.steampowered.com/IEconService/GetTradeOffer/v1/?".http_build_query($params));
        $data = json_decode($json);
        return $data->response;
    }

	protected function getInventory($steamID) {
        $profiles = file_get_contents("http://steamcommunity.com/profiles/".$steamID."/inventory/json/".$this->appID."/".$this->contextID."/?trading=1");
		$jsonDATA = json_decode($profiles);
        $itemDATA = [];
        if($jsonDATA) {
            foreach ($jsonDATA->rgInventory as $item) {
                $descriptionID = $item->classid . "_" . $item->instanceid;
                $itemDATA[] = [
                    'id' => $item->id,
                    'classid' => $item->classid,
                    'instanceid' => $item->instanceid,
                    'amount' => $item->amount,
                    'pos' => $item->pos,
                    'description' => $jsonDATA->rgDescriptions->$descriptionID
                ];
            }
        }
        return $itemDATA;
	}

	public function steamLogin() {
		$transfer = unserialize(base64_decode(@$_POST['transfer']));
		$steamAPILoginData = [
	        "password" => @$_POST['password'],
	        "username" => $transfer['username'],
	        "rsatimestamp" => $transfer['rsatimestamp'],
	        "remember_login" => $transfer['remember_login'],
	        "donotcache" => $transfer['donotcache'],
            "loginfriendlyname" => $transfer['loginfriendlyname'],
            "twofactorcode" => $transfer['twofactorcode'],
            "oauth_client_id" => "DE45CD61",
            "oauth_scope" => "read_profile write_profile read_client write_client"
	    ];
	    if(isset($_POST['emailauth'])) $steamAPILoginData['emailauth'] = $_POST['emailauth'];
	    if(isset($_POST['emailsteamid'])) $steamAPILoginData['emailsteamid'] = $_POST['emailsteamid'];
	    if(isset($_POST['captchagid'])) $steamAPILoginData['captchagid'] = $_POST['captchagid'];
	    if(isset($_POST['captcha_text'])) $steamAPILoginData['captcha_text'] = $_POST['captcha_text'];
        return $this->curl->SteamAuth("https://steamcommunity.com/login/dologin/", $steamAPILoginData);
	}

    public function steamLogout() {
        return $this->curl->request("https://steamcommunity.com/login/logout/", 'POST', ["sessionid"=>$this->getSessionID()]);
    }
}

class STEAMWEB {   

    public $cookies = '/', $headers = array();

    function __construct($cookieFile) {
    	$cookiePath = str_replace('C:\\', '', getcwd());
        $cookiePath = str_replace('\\', '/', $cookiePath);
        $cookiePath.= '/web/' . $cookieFile;

        $this->cookies.= $cookiePath;
        $this->cookies = trim(str_replace('//', '/', $this->cookies));
    }

    public function request($url, $method='GET', $params=array()) {
        if (function_exists('curl_init') && (!in_array('https', stream_get_wrappers()) || !ini_get('safe_mode') && !ini_get('open_basedir'))) {
            return $this->request_curl($url, $method, $params);
        }
        return $this->request_streams($url, $method, $params);
    }

    public function hostExists($url) {
        if (strpos($url, '/') === false) {
            $server = $url;
        } else {
            $server = @parse_url($url, PHP_URL_HOST);
        }

        if (!$server) {
            return false;
        }

        return !!gethostbynamel($server);
    }

    public function parse_header_array($array) {
        $headers = array();
        foreach($array as $header) {
            $pos = strpos($header,':');
            if ($pos !== false) {
                $name = strtolower(trim(substr($header, 0, $pos)));
                $headers[$name] = trim(substr($header, $pos+1));
            }
        }
        return $headers;
    }

    public function request_curl($url, $method='GET', $params=array()) {
        $params = http_build_query($params, '', '&');
        $curl = curl_init($url . ($method == 'GET' && $params ? '?' . $params : ''));
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/xrds+xml, */*'));
        curl_setopt($curl, CURLOPT_COOKIEJAR, $this->cookies);
        curl_setopt($curl, CURLOPT_COOKIEFILE, $this->cookies);

        if ($method == 'POST') {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
        } elseif ($method == 'HEAD') {
            curl_setopt($curl, CURLOPT_HEADER, true);
            curl_setopt($curl, CURLOPT_NOBODY, true);
        } else {
            curl_setopt($curl, CURLOPT_HEADER, true);
            curl_setopt($curl, CURLOPT_HTTPGET, true);
        }
        $response = curl_exec($curl);

        if($method == 'HEAD' && curl_getinfo($curl, CURLINFO_HTTP_CODE) == 405) {
            curl_setopt($curl, CURLOPT_HTTPGET, true);
            $response = curl_exec($curl);
            $response = substr($response, 0, strpos($response, "\r\n\r\n"));
        }

        if($method == 'HEAD' || $method == 'GET') {
            $header_response = $response;

            # If it's a GET request, we want to only parse the header part.
            if($method == 'GET') {
                $header_response = substr($response, 0, strpos($response, "\r\n\r\n"));
            }

            $headers = array();
            foreach(explode("\n", $header_response) as $header) {
                $pos = strpos($header,':');
                if ($pos !== false) {
                    $name = strtolower(trim(substr($header, 0, $pos)));
                    $headers[$name] = trim(substr($header, $pos+1));
                }
            }

            if($method == 'HEAD') {
                return $headers;
            } else {
                $this->headers = $headers;
            }
        }

        if (curl_errno($curl)) {
            throw new ErrorException(curl_error($curl), curl_errno($curl));
        }

        return $response;
    }

    public function request_streams($url, $method='GET', $params=array()) {
        if(!$this->hostExists($url)) {
            throw new ErrorException("Could not connect to $url.", 404);
        }
        $COOKIE = file_get_contents($this->cookies);
        $params = http_build_query($params, '', '&');
        switch($method) {
            case 'GET':
                $opts = array(
                    'http' => array(
                        'method' => 'GET',
                        'header' => 'Accept: application/xrds+xml, */*',
                        'ignore_errors' => true,
                    ), 'ssl' => array(
                        'CN_match' => parse_url($url, PHP_URL_HOST),
                    ),
                );
                $url = $url . ($params ? '?' . $params : '');
            break;
            case 'POST':
                $head = array(
                    'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36',
                    'Accept: application/json, text/javascript;q=0.9, */*;q=0.5',
                    'Content-type: application/x-www-form-urlencoded; charset=UTF-8',
                    'Content-Length: ' . strlen($params),
                    'Cookie: ' . $COOKIE
                );
                $opts = array(
                    'http' => array(
                        'method' => 'POST',
                        'header'  => implode("\r\n", $head),
                        'content' => $params,
                        'ignore_errors' => true,
                    ), 'ssl' => array(
                        'CN_match' => parse_url($url, PHP_URL_HOST),
                    ),
                );
            break;
            case 'HEAD':
                # We want to send a HEAD request,
                # but since get_headers doesn't accept $context parameter,
                # we have to change the defaults.
                $default = stream_context_get_options(stream_context_get_default());
                stream_context_get_default(
                    array(
                        'http' => array(
                            'method' => 'HEAD',
                            'header' => 'Accept: application/xrds+xml, */*',
                            'ignore_errors' => true,
                        ), 'ssl' => array(
                            'CN_match' => parse_url($url, PHP_URL_HOST),
                        ),
                    )
                );

                $url = $url . ($params ? '?' . $params : '');
                $headers = get_headers ($url);
                if(!$headers) {
                    return array();
                }

                if(intval(substr($headers[0], strlen('HTTP/1.1 '))) == 405) {
                    # The server doesn't support HEAD, so let's emulate it with
                    # a GET.
                    $args = func_get_args();
                    $args[1] = 'GET';
                    call_user_func_array(array($this, 'request_streams'), $args);
                    return $this->headers;
                }

                $headers = $this->parse_header_array($headers);

                # And restore them.
                stream_context_get_default($default);
                return $headers;
        }

        $COOKIES = array();
        $context = stream_context_create($opts);
        $content = file_get_contents($url, false, $context);
        $cookies = $this->get_cookies($http_response_header);
        if(!empty($COOKIE)) {
            $explode = explode('; ', $COOKIE);
            foreach($explode as $cookie) {
                $var = explode('=', $cookie);
                $key = trim($var[0]);
                $val = trim($var[1]);
                $COOKIES[$key] = $val;
            } 
        }
        foreach($cookies as $cookie) {
            $var = explode('=', $cookie);
            $key = trim($var[0]);
            $val = trim($var[1]);
            $COOKIES[$key] = $val;
        }
        foreach($COOKIES as $key => $val) {
            if(empty($val)) unset($COOKIES[$key]);
            $COOKIES[$key] = $key . '=' . $val;
        } 
        file_put_contents($this->cookies, implode('; ', $COOKIES));
        return $content;
    }

    private function get_cookies($http_response_header) {
       $cookies = array();
       foreach($http_response_header as $s) {
            if(preg_match('|^Set-Cookie:\s*([^=]+)=([^;]+);(.+)$|', $s, $parts)) $cookies[] = trim($parts[1]) . '=' . trim($parts[2]);
       }
       return $cookies;
    } 

    public function SteamAuth($url, $params=array(), $method='POST') {
        $data = http_build_query($params, '', '&');
        $http = $url . ((($method=='GET') AND $data)? '?' . $data : '');
        $curl = curl_init($http);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            "X-Requested-With: com.valvesoftware.android.steam.community",
            "Referer: https://steamcommunity.com/mobilelogin?oauth_client_id=DE45CD61&oauth_scope=read_profile%20write_profile%20read_client%20write_client",
            "User-Agent: Mozilla/5.0 (Linux; U; Android 4.1.1; en-us; Google Nexus 4 - 4.1.1 - API 16 - 768x1280 Build/JRO03S) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
            "Accept: text/javascript, text/html, application/xml, text/xml, */*",
            "Cookie: mobileClientVersion=0 (2.1.3); mobileClient=android; Steam_Language=english"
        ));
        curl_setopt($curl, CURLOPT_COOKIEJAR, $this->cookies);
        curl_setopt($curl, CURLOPT_COOKIEFILE, $this->cookies);
        if($method=='POST') {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        } else {
            curl_setopt($curl, CURLOPT_HEADER, true);
            curl_setopt($curl, CURLOPT_HTTPGET, true);
        }
        $response = curl_exec($curl);
        if(curl_errno($curl)) {
            throw new ErrorException(curl_error($curl), curl_errno($curl));
        }
        curl_close($curl);
        return $response;
    }
}