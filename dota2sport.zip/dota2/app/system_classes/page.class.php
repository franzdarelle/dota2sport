<?php
class Page {
	
	public $title;
	public $menu;
	public $content;
	private $request;
	private $className;
	
	public function __construct($request=array()){
	
		$page = array();
		$page['menu'] = $page['title'] = $page['content'] = null;
		$this->request = $request; 
	 
		if(count($request)>1) {
			$this->setClassName( strtolower($request[1]) ); 
			$className = $this->getClassName(); 
			$view = "page_" . @$request[2];
			
			$otherRequests = array();
			for($i=3;$i<count($request);$i++) {
				$otherRequests[] = $request[$i];
			}
			
			if(class_exists($className)) {
				$model = new $className($otherRequests);
 				if((int)method_exists($model, $view) AND is_callable(array($model, $view))) {
					$page = $model->$view($otherRequests);
					if(is_array($page)) {
						$page['menu'] = isset($page['menu'])? $page['menu'] : null;
						$page['title'] = isset($page['title'])? $page['title'] : null;
						$page['content']= isset($page['content'])? $page['content'] : null;
					} else {
						$content = $page;
						$page = array();
						$page['menu'] = $page['title'] = null;
						$page['content']= $content;
					}
				}
			}
		}
		$this->setTitle($page['title']);
		$this->setMenu($page['menu']);
		$this->setContent($page['content']);
	}
	
	public function setClassName($className) {
		$this->className = $className . 'Page';
		return $this;
	}
	
	public function getClassName() {
		return $this->className;
	}
	
	public function setContent($content=null) {
		$error404 = function_exists("error404") ? error404() : "Page not found!";
		$this->content = is_null($content)? $error404 : $content;
		return $this;
	}
	
	public function getContent() {
		return $this->content;
	}
	
	public function setTitle($title=null) {
		$this->title = is_null($title)? "Page not found!" : $title;
		return $this;
	}
	
	public function getTitle() {
		return $this->title;
	}
	
	public function setMenu($menu=null) {
		$this->menu = $menu;
		return $this;
	}

	public function getMenu() {
		return $this->menu;
	}
}

class PageAjax {

	public 	$title;
	public 	$content;
	public 	$request_q; # classname and function 	q=message/insert
	public 	$request_o; # other request variables 	&name=kevin&email=adlaon_kevin@yahoo.com
	private $className;

	public function __construct($q, $request=array()){
	
		$content = null;
		$this->setRequest_q($q);
		$this->setRequest_o($request);
		
		$exp_req = explode("/", $this->getRequest_q());
		
		if(count($exp_req)==2) {
			$this->setClassName(ucfirst(strtolower($exp_req[0])));
			$className 	= $this->getClassName();
			$function 	= $exp_req[1];

			if(class_exists($className)) {
				$model = new $className($this->getRequest_o());
				if((int)method_exists($model, $function) AND is_callable(array($model, $function))) {
					$content = $model->$function($this->getRequest_o());
				}
			}
		}
		$this->setContent($content);
	}

	public function setRequest_q($request) {
		$this->request_q = $request;
		return $this;
	}
	
	public function getRequest_q() {
		return $this->request_q;
	}
	
	public function setRequest_o($request) {
		$this->request_o = $request;
		return $this;
	}
	
	public function getRequest_o() {
		return $this->request_o;
	}

	public function setClassName($className) {
		$this->className = $className . 'AJAX';
		return $this;
	}

	public function getClassName() {
		return $this->className;
	}

	public function setContent($content=null) {
		$this->content = is_null($content)? '0' : $content;
		return $this;
	}

	public function getContent() {
		return $this->content;
	}

	public function getAction() {
		$action = count($this->request) ? $this->request[0] : null;
		if(is_null($action)) {
			print "You performed an invalid action.";
			exit;
		} else
			return $action;
	}
}