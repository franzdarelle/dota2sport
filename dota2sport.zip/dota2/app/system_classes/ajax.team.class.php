<?php
class teamAJAX {
	public $data, $post, $exts, $path, $file, $steam;
	public function __construct($data=null) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->exts = array("jpg", "png", "gif", "jpeg");
		$this->path = 'upl/team/';
		$this->file = IMG_UPLOAD;
		$this->steam= new STEAM;
	}

	public function getData() {
		return $this->data;
	}
	
	public function getPost() {
		return $this->post;
	}

	public function upl() {
		$out = $tmp = $ext = null;
		foreach ($_FILES['photos']['name'] as $name => $value){
			$tmp = $_FILES['photos']['tmp_name'][$name];
	        $ext = strtolower(pathinfo($_FILES['photos']['name'][$name], PATHINFO_EXTENSION));
	        if(in_array($ext, $this->exts)) {
		       	if(filesize($tmp) < (MAX_UPLOAD*1024)) {
		       		$image = random_string(20) . '.' . $ext;
		       		$perms = substr(sprintf('%o', fileperms($this->path)), -4);
		       		if($perms != "0777") chmod($this->path, 0777);
	                if(move_uploaded_file($tmp, $this->path.$image)) {
	            		$_SESSION[$this->file] = $image;
	            		$out .= "<img src='" . BASEURL . $this->path . $image . "' class='img'>";
	        	    } else 
	        	    	$out .= 'Unable to move file to <i>' . $this->path . '</i> (' . $perms . ')';
	            } else 
	            	$out .= 'You have exceeded the size limit!';
	        } else 
	        	$out .= 'Unknown extension!';
	    }
	    return $out;
	}

	public function add() {
		$d = $this->getData();
		$r = $this->steam->addTeam(((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : ''), $d['name'], $d['alias'], $d['description'], $d['sport']);
		if($r){
			if(isset($_SESSION[$this->file])) { 
				Image::resizeImage($this->path.$_SESSION[$this->file], 60, 50, $this->path.$_SESSION[$this->file]);
				unset($_SESSION[$this->file]);
			}
			$_SESSION[$this->steam->string] = 'Team successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups() {
		$d = $this->getData();
		$p = $this->steam->getTeam($d['id']);
		$r = $this->steam->editTeam(((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : $p['logo']), $d['name'], $d['alias'], $d['description'], $d['sid'], $d['id']);
		if($r){
			if(isset($_SESSION[$this->file])){
				Image::resizeImage($this->path.$_SESSION[$this->file], 60, 50, $this->path.$_SESSION[$this->file]); 
				unset($_SESSION[$this->file]);
			}
			$_SESSION[$this->steam->string] = 'Team successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->deleteTeam($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Team' : ($c .' Teams');
			$_SESSION[$this->steam->string] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function get() {
		$d = $this->getPost();
		return json_encode($this->steam->getTeam($d));
	}

	public function set() {
		if(isset($_SESSION[$this->file])) unset($_SESSION[$this->file]);
		return true;
	}

	public function rem() {
		$files = array();
		if($handle = opendir($this->path)){
			$i = array();
			$c = $this->steam->getTeams();
			foreach ($c as $d) $i[] = $d['logo'];
			while (false !== ($file = readdir($handle))) {
				if (!in_array($file, array(".", ".."))) {
					if(!in_array($file, $i)) {
						$files[] = $file;
						unlink($this->path.$file);
					}  
				}
			}
			closedir($handle);
		}
		return array('files'=>$files, 'count'=>count($files));
	}
}


