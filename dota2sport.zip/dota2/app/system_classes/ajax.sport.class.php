<?php
class sportAJAX {
	public $data, $post, $exts, $path, $file, $steam;
	public function __construct($data=null) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->exts = array("jpg", "png", "gif", "jpeg");
		$this->path = 'upl/sport/';
		$this->file = IMG_UPLOAD;
		$this->steam= new STEAM;
	}

	public function getData() {
		return $this->data;
	}
	
	public function getPost() {
		return $this->post;
	}

	public function upl() {
		$out = $tmp = $ext = null;
		foreach ($_FILES['photos']['name'] as $name => $value){
			$tmp = $_FILES['photos']['tmp_name'][$name];
	        $ext = strtolower(pathinfo($_FILES['photos']['name'][$name], PATHINFO_EXTENSION));
	        if(in_array($ext, $this->exts)) {
		       	if(filesize($tmp) < (MAX_UPLOAD*1024)) {
	    			$image = random_string(20) . '.' . $ext;
	    			$perms = substr(sprintf('%o', fileperms($this->path)), -4);
		       		if($perms != "0777") chmod($this->path, 0777);
	                if(move_uploaded_file($tmp, $this->path.$image)) {
	            		$_SESSION[$this->file] = $image;
	            		$out .= "<img src='" . BASEURL . $this->path . $image . "' class='img'>";
	        	    } else 
	        	    	$out .= 'Unable to move file to <i>' . $this->path . '</i> (' . $perms . ')';
	            } else 
	            	$out .= 'You have exceeded the size limit!';
	        } else 
	        	$out .= 'Unknown extension!';
	    }
	    return $out;
	}

	public function add() {
		$d = $this->getData();
		$r = $this->steam->addSport(((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : ''), $d['name'], $d['sort'], 1);
		if($r){
			if(isset($_SESSION[$this->file])) { 
				Image::resizeImage($this->path.$_SESSION[$this->file], 50, 50, $this->path.$_SESSION[$this->file]);
				unset($_SESSION[$this->file]);
			}
			$_SESSION[$this->steam->string] = 'Sport successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups() {
		$d = $this->getData();
		$p = $this->steam->getSport($d['id']);
		$r = $this->steam->editSport(((isset($_SESSION[$this->file]))? $_SESSION[$this->file] : $p['logo']), $d['name'], $d['sort'], $d['id']);
		if($r){
			if(isset($_SESSION[$this->file])){
				Image::resizeImage($this->path.$_SESSION[$this->file], 50, 50, $this->path.$_SESSION[$this->file]); 
				unset($_SESSION[$this->file]);
			}
			$_SESSION[$this->steam->string] = 'Sport successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function get() {
		$d = $this->getPost();
		return json_encode($this->steam->getSport($d));
	}

	public function set() {
		if(isset($_SESSION[$this->file])) unset($_SESSION[$this->file]);
		return true;
	}

	public function act() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->editSportStatus($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Sport' : ($c .' Sports');
			$_SESSION[$this->steam->string] = $e . ' successfully activated.';
			return 1;
		} else
			return 'Error activating...';
	}

	public function dea() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->editSportStatus($d,0)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Sport' : ($c .' Sports');
			$_SESSION[$this->steam->string] = $e . ' successfully deactivated.';
			return 1;
		} else
			return 'Error deactivating...';
	}

	public function del() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->deleteSport($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Sport' : ($c .' Sports');
			$_SESSION[$this->steam->string] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function rem() {
		$files = array();
		if($handle = opendir($this->path)){
			$i = array();
			$c = $this->steam->getSports();
			foreach ($c as $d) $i[] = $d['logo'];
			while (false !== ($file = readdir($handle))) {
				if (!in_array($file, array(".", ".."))) {
					if(!in_array($file, $i)) {
						$files[] = $file;
						unlink($this->path.$file);
					}  
				}
			}
			closedir($handle);
		}
		return array('files'=>$files, 'count'=>count($files));
	}
}


