<?php
class eventAJAX {
	public $data, $post, $steam;
	public function __construct($data=null) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->steam= new STEAM;
	}

	public function getData() {
		return $this->data;
	}
	
	public function getPost() {
		return $this->post;
	}

	public function get() {
		$d = $this->getPost();
		return json_encode($this->steam->getEvent($d));
	}

	public function add() {
		$d = $this->getData();
		$r = $this->steam->addEvent($d['sport'], $d['event']);
		if($r){
			$_SESSION[$this->steam->string] = 'Event successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups() {
		$d = $this->getData();
		$r = $this->steam->editEvent($d['sid'], $d['name'], $d['id']);
		if($r){
			$_SESSION[$this->steam->string] = 'Event successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->deleteEvent($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Event' : ($c .' Events');
			$_SESSION[$this->steam->string] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}
}


