<?php
class botAJAX {
	public $data, $post, $steam;
	public function __construct($data=null) {
		$this->data = $data;
		$this->post = @$_POST['d'];
		$this->steam= new STEAM;
	}

	public function getData() {
		return $this->data;
	}
	
	public function getPost() {
		return $this->post;
	}

	public function get() {
		$d = $this->getPost();
		return json_encode($this->steam->getBot($d));
	}
	
	public function add() {
		$d = $this->getData();
		$r = $this->steam->addBot($d['username'], $d['password'], $d['persona'], $d['apikey']);
		if($r){
			$_SESSION[$this->steam->string] = 'Bot successfully added.';
			return 1;
		} else 
			return 'Error adding...';
	}

	public function ups() {
		$d = $this->getData();
		$r = $this->steam->editBot($d['username'], $d['password'], $d['persona'], $d['apikey'], $d['id']);
		if($r){
			$_SESSION[$this->steam->string] = 'Bot successfully edited.';
			return 1;
		} else 
			return 'Error editing...';
	}

	public function del() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->deleteBot($d)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Bot' : ($c .' Bots');
			$_SESSION[$this->steam->string] = $e . ' successfully deleted.';
			return 1;
		} else
			return 'Error deleting...';
	}

	public function act() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->setBotStatus($d,1)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Bot' : ($c .' Bots');
			$_SESSION[$this->steam->string] = $e . ' successfully activated.';
			return 1;
		} else
			return 'Error activating...';
	}

	public function dea() {
		$c = 0;
		foreach ($this->getPost() as $d) {
			if($this->steam->setBotStatus($d,0)) $c++;
		}
		if($c>0){
			$e = ($c==1)? 'Bot' : ($c .' Bots');
			$_SESSION[$this->steam->string] = $e . ' successfully deactivated.';
			return 1;
		} else
			return 'Error deactivating...';
	}

	public function setSteam() {
		$d = $this->getPost();
		if($d) {
			$steamid = $d['steamid'];
			if($this->steam->setBotSteam($steamid, $d['oauth_token'], $d['username'], $d['password'])) {
				return json_encode(array('steamid' => $steamid, 'oauth_token' => $d['oauth_token']));
			}
		}
	}
}