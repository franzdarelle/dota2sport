<div class="container bg">
	<div class="row">
		<div class="span3">
			<?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		</div>
		<div class="span9">
			<div class="pagetitle">
				<h2>ITEMS</h2>
				<p>BACKPACK ITEMS</p>
			</div>
			<div id="main-content">
				<div class="row-fluid grid-set">
				<?php 
					$BOTS = $STEAM->getActiveBots(); 
					if($BOTS):
						foreach ($BOTS as $bot):
				?>
					<div class="row-fluid grid-set backpack" botid="<?php print $bot['id'] ?>">
						<div class="span12">
							<div class="box dark">
								<div class="header">
									<h4><?php print $bot['persona'] ?></h4>
									<div class="tradeBot pointer">
										<a href="<?php print generateUrl($links . $bot['id']) ?>" target="_blank"><span class="label label-info">Trade Offer</span></a>
									</div>
								</div>
								<div class="content">
									<table class="table normal margin-reset">
										<thead>
											<tr>
												<th>OWNER OF ITEM</th>
												<th>NUMBER OF ITEM</th>
												<th>AMOUNT OF ITEM</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td><?php print strtoupper(WEB_TITLE) ?></td>
												<td class="text-align-right count1"></td>
												<td class="text-align-right value1"></td>
											</tr>
											<tr>
												<td>USER</td>
												<td class="text-align-right count2"></td>
												<td class="text-align-right value2"></td>
											</tr>
											<tr>
												<td class="text-align-center">TOTAL</td>
												<td class="text-align-right counts"></td>
												<td class="text-align-right values"></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<div class="clear"></div>
					</div>
				<?php endforeach; endif ?>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	$("div.tradeBot").hide();
	$("div.backpack").each(function(){
		loadBotInventory($(this).attr("botid"));
	});

	function loadBotInventory(botid) {
		var datatable = $("div[botid='"+botid+"']");
		datatable.find(".count1, .count2, .counts, .value1, .value2, .values").html($("<img>", {"src":BASEURL+"img/loading.gif"}));
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getBotInventorySummary", 
            type:"POST", 
            data:{botid:botid}, 
            cache:true,
            dataType:"html"
        }).done(function(response){
        	var inventory = $.parseJSON(response);
        	var counts = inventory.count1+inventory.count2;
        	var values = inventory.value1+inventory.value2;
        	datatable.find(".count1").html(inventory.count1);
        	datatable.find(".count2").html(inventory.count2);        	
        	datatable.find(".value1").html(inventory.value1);
        	datatable.find(".value2").html(inventory.value2);
        	datatable.find(".counts").html((counts==parseInt(counts))? counts : counts.toFixed(2));
        	datatable.find(".values").html((values==parseInt(values))? values : values.toFixed(2));
        	datatable.find("div.tradeBot").fadeIn();
        });
    }
});
</script>