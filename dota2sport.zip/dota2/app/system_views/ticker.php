<?php 
$GAMES = $var->getRecentGames();
if($GAMES): 
?>
<div class="sidebar tb mt20">
 	<div class="sidebar-wrap padding-reset transparent">
 		<div class="ticker-holder">
 			<div class="ticker-header">RECENT MATCHES</div>
 			<?php foreach($GAMES as $game): ?>
 			<div class="ticker-content">
 				<div class="ticker-date">
 					<div class="sport"><?php echo strtoupper($game['sport']['name']) ?></div>
 					<div class="date">
					<?php 
						$g = $var->getTime($game['id']);
						$m = $g['minute'];
						$h = $g['hour'];
						$d = $g['day'];
						if($d<0) {
							$d = abs($d);
							print implode(" ", array($d, (($d==1)? "day" : "days")));
						} else {
							if($h<0) {
								$h = abs($h);
								print implode(" ", array($h, (($h==1)? "hour" : "hours")));
							} else {
								$m = abs($m);
								print implode(" ", array($m, (($m==1)? "minute" : "minutes")));
							}
						}
					?>
 					</div> 					
 				</div>
 				<div class="ticker-event">
 					<div class="name"><?php echo $game['event']['name'] ?></div>
 					<div class="game"><?php echo "BO" . $game['games'] ?></div>
 				</div>
 				<div class="ticker-match">
 					<div class="team">
 						<img src="<?php echo BASEURL . 'upl/team/' . $game['team1']['logo'] ?>">
 						<span class="alias"><?php echo $game['team1']['name'] ?></span>
 						<span class="score"><?php echo $game['score1'] ?></span>
 					</div>
 					<div class="team">
 						<img src="<?php echo BASEURL . 'upl/team/' . $game['team2']['logo'] ?>">
 						<span class="alias"><?php echo $game['team2']['name'] ?></span>
 						<span class="score"><?php echo $game['score2'] ?></span>
 					</div>
 				</div>
 			</div>
 			<?php endforeach ?>
 		</div>
 	</div>
</div>
<?php endif ?>