<div class="container bg">
   <div class="row">
    	<div class="span3">
	    	<?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		  	<?php print getViewsContents('ticker', $STEAM) ?>
		</div>
		<div class="span9">
         <div class="pagetitle">
            <h2>MATCHES</h2>
            <p>MATCHES TODAY</p>
         </div>
         <div id="main-content">
         <div class="row-fluid grid-set">
         <?php if($SPORT): foreach($SPORT as $s): ?>
         	<div class="span3">
         		<a class="btn btn-block sports" href="<?php echo generateUrl(implode("/", array(MAIN_CLASS, USER_CLASS, 'matches', $s['id']))) ?>">
         			<img src="<?php echo BASEURL . 'upl/sport/' . $s['logo'] ?>" class="pix">
         			<span class="dasboard-icons-title"><?php echo $s['name'] ?></span>
         		</a>
         	</div>
         <?php endforeach; endif ?>
         </div>
         <?php
         	$games = count($GAMES);
         	$grids = ($games>2)? ceil($games/2) : 1;
         	for($count = 1; $count <= $grids; $count++):
         		$x = $count * 2;
         		$y = ($x - 1) - 1;
         		$z = ($x - 1);
         ?>
            <div class="row-fluid grid-set">
            	<?php if(isset($GAMES[$y])): $game = $GAMES[$y] ?>
				<div class="span6">
					<div class="box dark games" game="<?php echo $game['id'] ?>">
						<div class="header">
							<h4><?php echo stripslashes($game['event']['name']) ?></h4>
							<div class="matchTime">
								<span class="state"></span>
								<span class="stamp"></span>
							</div>
						</div>
						<div class="content pad">
							<div class="span4 team1">
								<div class="content pad center">
									<img src="<?php echo BASEURL . 'upl/team/' . $game['team1']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($game['team1']['alias']) ?></h4>
								</div>
							</div>
							<div class="span4">
								<div class="header center">
									<h4 class="nobottomborder scores">
										<span class="score1"><?php echo $game['score1'] ?></span>
										<span class="score2"><?php echo $game['score2'] ?></span>
										<span>vs</span>
									</h4>
								</div>
								<div class="content pad center">
									<span class="label label-info">Best of <?php echo $game['games'] ?></span>
								</div>
								<div class="header center">
									<h4 class="nobottomborder odds">
										<span class="odds1"></span>
										<span class="odds2"></span>
									</h4>
								</div>
							</div>
							<div class="span4 team2">
								<div class="content pad center">
									<img src="<?php echo BASEURL . 'upl/team/' . $game['team2']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($game['team2']['alias']) ?></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endif; if(isset($GAMES[$z])): $game = $GAMES[$z] ?>
				<div class="span6">
					<div class="box dark games" game="<?php echo $game['id'] ?>">
						<div class="header">
							<h4><?php echo stripslashes($game['event']['name']) ?></h4>
							<div class="matchTime">
								<span class="state"></span>
								<span class="stamp"></span>
							</div>
						</div>
						<div class="content pad">
							<div class="span4 team1">
								<div class="content pad center">
									<img src="<?php echo BASEURL . 'upl/team/' . $game['team1']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($game['team1']['alias']) ?></h4>
								</div>
							</div>
							<div class="span4">
								<div class="header center">
									<h4 class="nobottomborder scores">
										<span class="score1"><?php echo $game['score1'] ?></span>
										<span class="score2"><?php echo $game['score2'] ?></span>
										<span>vs</span>
									</h4>
								</div>
								<div class="content pad center">
									<span class="label label-info">Best of <?php echo $game['games'] ?></span>
								</div>
								<div class="header center">
									<h4 class="nobottomborder odds">
										<span class="odds1"></span>
										<span class="odds2"></span>
									</h4>
								</div>
							</div>
							<div class="span4 team2">
								<div class="content pad center">									
									<img src="<?php echo BASEURL . 'upl/team/' . $game['team2']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($game['team2']['alias']) ?></h4>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endif ?>
            	<div class="clear"></div>
            </div>
        <?php endfor ?>
    	</div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){ 
	$(".center").find("h4").css({"padding-left":0});
	var Games = $(".games").addClass("pointer").click(function(){Redirect('<?php echo implode("/", array(MAIN_CLASS, USER_CLASS, "match/")) ?>' + $(this).attr("game"))}).each(function(){setGameTime($(this))});
	updateGames();
	function updateGames() {
		Games.each(function(){setGameTime($(this))});
		setTimeout(updateGames, 30000);
	}
	function setGameTime(game) {
		$.ajax({
            url:BASEURL + "ajax.php?q=game/getGameTime", 
            type:"POST", 
            data:{d:game.attr("game")}, 
            cache:true,
            dataType:"html"
        }).done(function(e){
        	game.find("span.stamp").html(e);
        }).always(setGameOdd(game));
	}
	function setGameOdd(game) {
		$.ajax({
			url:BASEURL + "ajax.php?q=dota/getGameOdds",
			type:"POST",
			data:{d:game.attr("game")},
			cache:true,
			dataType:"html"
       	}).done(function(e){
       		var odds = $.parseJSON(e);
       		game.find(".odds1").text(odds.odd1+"%");
       		game.find(".odds2").text(odds.odd2+"%");
    	}).always(setGameScore(game));		
	}
	function setGameScore(game) {
		$.ajax({
			url:BASEURL + "ajax.php?q=game/get",
			type:"POST",
			data:{d:game.attr("game")},
			cache:true,
			dataType:"html"
       	}).done(function(e){
        	var d = $.parseJSON(e);
        	var w = $('<img></img>', {class:"winner"}).attr('src', BASEURL + 'img/check.png');
        	game.find("img.winner").remove();
        	game.find("span.score1").text(d.score1);
        	game.find("span.score2").text(d.score2);        	
        	game.find("div.highlightedTeam").removeClass("highlightedTeam");
        	span = game.find("span.state")
        		.removeClass("label label-warning label-important")
        		.addClass("label");
			switch (parseInt(d.status)) {
				case 1:
					span.html("ONGOING").addClass("label-warning").show();
				break;
    			case 2:
    			case 4:
    				game.find(".span4").css({"opacity":0.7});
					span.html((d.status==2)? "POSTPONED" : "CANCELLED").addClass("label-important").show();
    			break;
    			case 3:
    				game.find(".span4").css({"opacity":0.7});
    				switch (d.winner) {
						case d.team1.id:
		        			game.find("div.team1").addClass("highlightedTeam").find("div.content").append(w);
		        			span.hide();
						break;
						case d.team2.id:
							game.find("div.team2").addClass("highlightedTeam").find("div.content").append(w);
		        			span.hide();
						break;
						default:
							span.html("DRAW").addClass("label-important").show();
						break;
					}
    			break;
    			default:
    				span.hide();
    			break;
        	}
       	});
	}
});
</script>
