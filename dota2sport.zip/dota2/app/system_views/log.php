<?php
$rsaJSON = $STEAMWEB->SteamAuth("https://steamcommunity.com/login/getrsakey/", array('username'=>$username));
$rsaDATA = json_decode($rsaJSON); 
if($rsaDATA->success AND $rsaDATA->publickey_mod AND $rsaDATA->publickey_exp AND $rsaDATA->timestamp AND $rsaDATA->token_gid) :
    $publickey_mod = $rsaDATA->publickey_mod;
    $publickey_exp = $rsaDATA->publickey_exp;
    $transfer = [
        "username" => $username,
        "rsatimestamp" => $rsaDATA->timestamp,
        "remember_login" => false,
        "donotcache" => microtime(),
        "loginfriendlyname" => strtoupper($username),
        "twofactorcode" => $code
    ];
?>
    <script type="text/javascript">
        var server = BASEURL + "ajax.php?q=dota/steamLogin";
        var encPar = "<?php echo base64_encode(serialize($transfer)) ?>";
        var pubKey = RSA.getPublicKey("<?php echo $publickey_mod ?>","<?php echo $publickey_exp ?>");
        var encPwd = RSA.encrypt("<?php echo $password ?>", pubKey);
        $.ajax({
            url:server, 
            type:"POST", 
            data:{ password:encPwd, transfer:encPar }, 
            dataType:"html"
        }).done(function(e){
            var r = $.parseJSON(e);
            if(r.emailauth_needed) {
                steamGuard(encPwd, encPar, r.emailsteamid);
            } else if(r.captcha_needed) {
                captchaNeeded(encPwd, encPar, r.captcha_gid);
            } else if(r.success) {
                setSteam($.parseJSON(r.oauth));
            }
        });

        function steamGuard(password, parameter, emailsteamid) {
            var code = prompt("Code: ", "");
            if(code) {
                $.ajax({
                    url:server, 
                    type:"POST", 
                    data:{ password:password, transfer:parameter, emailauth:code, emailsteamid:emailsteamid }, 
                    dataType:"html"
                }).done(function(e){
                    var r = $.parseJSON(e);
                    if(r.success) {
                        setSteam($.parseJSON(r.oauth));
                    } else {
                        if(r.emailauth_needed) {
                            steamGuard(password, parameter, r.emailsteamid);
                        } else if(r.captcha_needed) {
                            captchaNeeded(password, parameter, r.captcha_gid);
                        }
                    }
                });
            }
        }

        function captchaNeeded(password, parameter, captcha_gid) {
            var view = window.open("https://steamcommunity.com/public/captcha.php?gid=" + captcha_gid);
            var text = prompt("Text: ", "");
            if(text) {
                $.ajax({
                    url:server, 
                    type:"POST", 
                    data:{ password:password, transfer:parameter, captchagid:captcha_gid, captcha_text:text }, 
                    dataType:"html"
                }).done(function(e){
                    var r = $.parseJSON(e);
                    if(r.success) {
                        view.close();
                        setSteam($.parseJSON(r.oauth));
                    } else {
                        if(r.emailauth_needed) {
                            steamGuard(password, parameter, r.emailsteamid);
                        } else if(r.captcha_needed) {
                            captchaNeeded(password, parameter, r.captcha_gid);
                        }
                    }
                });
            }
        } 

        function setSteam(oauth) {
            $.ajax({
                url:BASEURL + "ajax.php?q=bot/setSteam", 
                type:"POST", 
                data: {d:{username: "<?php print $username ?>", password: "<?php print $password ?>", steamid: oauth.steamid, oauth_token: oauth.oauth_token}},
                dataType:"html"
            }).done(function(response){
                $("code").html(response);
            });
        }        
    </script>
<?php endif ?>
<div class="container bg">
    <div class="row">
        <div class="span3">
            <?php print getViewsContents('side', ['data'=>$data,'user'=>$user,'page'=>arg(3)]) ?>
        </div>
        <div class="span9">
            <div class="pagetitle">
                <h2><?php print $steambot ?></h2>
                <p><?php print $username ?></p>
            </div>
            <div id="main-content">
                <div class="row-fluid grid-set">
            		<div class="span12"><code>This page is to log bot into steam.</code></div>
                	<div class="clear"></div>
                </div>
            </div>
       </div>
    </div>
</div>