<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side', ['data'=>$data,'user'=>$user,'page'=>arg(3)]) ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>TEAM</h2>
            <p>TEAM MANAGEMENT</p>
         </div>
         <div id="main-content">
            <?php if(isset($_SESSION[$data->string])) { print messageBox($_SESSION[$data->string]); unset($_SESSION[$data->string]); } ?>
            <div class="box dark">
               <div class="header">
                  <h4>Teams</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Team"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="team/get"><a href="#" data-original-title="Edit Team"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="team/del" hl="<?php echo $link; ?>"><a href="#" data-original-title="Delete Team"><i class="icon-remove"></i>Delete</a></li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="table normal bt-dataTable dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>
                           <th>NAME</th>
                           <th>ALIAS</th>
                           <th>DESCRIPTION</th>
                           <th>SPORT</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php 
                        $TEAMS = $data->getTeams();
                        if($TEAMS):
                           foreach ($TEAMS as $d): 
                              $s = $data->getSport($d['sid']);
                     ?>
                        <tr class="gradeX">
                           <td class="tal"><label class="checkbox inline"><input type="checkbox" class="checkbox-uniform" value="<?php print $d['id'] ?>"></label></td>
                           <td><span class="logo" path="<?php echo BASEURL ?>upl/team/<?php print $d['logo'] ?>"><?php print stripslashes($d['name']) ?></span></td>
                           <td><?php print stripslashes($d['alias']) ?></td>
                           <td><?php print stripslashes($d['description']) ?></td>
                           <td><?php print stripslashes($s['name']) ?></td>
                        </tr>
                     <?php endforeach; endif ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="clear"></div>
      </div>
   </div>
</div>
<div class="uplAdd">
   <div id='imageFileAddLoader' style='display:none'><img src="<?php echo BASEURL; ?>img/loader.gif" alt="Uploading...."/></div>
   <div id='imageFileAddOutput'><input type="file" name="photos[]" id="inputFileAdd" multiple="true" class="input-medium" accept="image/*"/></div>
</div>
<div class="uplUps">
   <div id='imageFileUpsLoader' style='display:none'><img src="<?php echo BASEURL; ?>img/loader.gif" alt="Uploading...."/></div>
   <div id='imageFileUpsOutput'><input type="file" name="photos[]" id="inputFileUps" multiple="true" class="input-medium" accept="image/*"/></div>
</div>
<?php 
   $randAdd = random_string(5);
   $randUps = random_string(5);
   $attrAdd = array(
      'name' => 'add_team',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randAdd
   );
   $attrUps = array(
      'name' => 'ups_team',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randUps
   );
   $addform = $form->startForm("team/add", "post", "add_team", $attrAdd).$form->endForm(); 
   $upsform = $form->startForm("team/ups", "post", "ups_team", $attrUps).$form->endForm(); 
   $uplform = $form->startForm(BASEURL."ajax.php?q=team/upl", "post", "uplFormAdd", array('enctype' => 'multipart/form-data')).$form->endForm();
   $upeform = $form->startForm(BASEURL."ajax.php?q=team/upl", "post", "uplFormUps", array('enctype' => 'multipart/form-data')).$form->endForm();
?>
<div class="add">
   <div class="rowelement pop">
      <div class="span3"><strong>SPORT</strong></div>
      <div class="span3">
         <select class="input-large <?php echo $randAdd ?>" name="sport"/>
         <?php foreach ($data->getSports() as $d): ?><option value="<?php echo $d['id'] ?>"><?php echo stripslashes($d['name']) ?></option><?php endforeach ?>
         </select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>NAME</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>ALIAS</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="alias"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>DESCRIPTION</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="description"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>LOGO</strong></div>
      <div class="span3" id="addLogo"><input type="button" class="btn" id="addLogoTrigger" value="Upload"></div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
   <input class="input-large <?php echo $randUps ?>" type="hidden" name="id"/>
   <div class="rowelement pop">
      <div class="span3"><strong>SPORT</strong></div>
      <div class="span3">
         <select class="input-large <?php echo $randUps ?>" name="sid"/>
         <?php foreach ($data->getSports() as $d): ?><option value="<?php echo $d['id'] ?>"><?php echo stripslashes($d['name']) ?></option><?php endforeach ?>
         </select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>NAME</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="name"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>ALIAS</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="alias"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>DESCRIPTION</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="description"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>LOGO</strong></div>
      <div class="span3" id="upsLogo"><input type="button" class="btn" id="upsLogoTrigger" value="Change"></div>
      <div class="clear"></div>
   </div>
</div>
<?php generate_javascripts(array(BASEURL.'js/jquery.wallform.js')) ?>
<script type="text/javascript">
$(document).ready(function(){
   $("div.checker").css({"margin-left":0,"margin-right":0,"padding":0});
   $(".add, .ups, .uplAdd, .uplUps").css({"overflow":"hidden"});
   $("#ref").click(function(){Redirect('<?php echo $link ?>')});
   $('.pop').css({"padding":0});
   $('.num').filter_input({regex:'[0-9]'});
   $("#add").add('<?php print $addform ?>', 'Add Team', $("div.add"), 300, true, 'bart', 
      function(){
         var reset = setInterval(function(){
            var div = $("div#bart");
            if(div.length==0){
               $.ajax({
                  url:BASEURL + "ajax.php?q=team/set",
                  type:"POST",
                  data:{d:0},
                  dataType:"html"
               }).done(function(e){
                  if(e) clearInterval(reset);
               });
            }
         }, 1000);
      }
   , 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#ups').ups('<?php print $upsform ?>', 'Edit Team', $("div.ups"), 300, true, 'dogz', 
      function(obj){
         var div = $("div.ups");
         div.find('select').each(function(){
            $(this).find('option').each(function(){
               if($(this).attr('value')==obj['sid']) $(this).attr('selected', 'selected');
            });
         });
         $('.img').remove();
         $('#upsLogo').prepend('<img src="'+BASEURL+'upl/team/'+obj['logo']+'" class="img">');
         var reset = setInterval(function(){
            var div = $("div#dogz");
            if(div.length==0){
               $.ajax({
                  url:BASEURL + "ajax.php?q=team/set",
                  type:"POST",
                  data:{d:0},
                  dataType:"html"
               }).done(function(e){
                  if(e) clearInterval(reset);
               });
            }
         }, 1000);
      }
   , 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $('#all').all($('span.all'));
   $('#del').del();
   $('.act').act();
   $("#addLogoTrigger").add('<?php print $uplform ?>', 'Upload Photo', $("div.uplAdd"), 300, true, 'papz', false, false, false, false, false, false);
   $("#upsLogoTrigger").css({"margin-left":5}).add('<?php print $upeform ?>', 'Change Photo', $("div.uplUps"), 300, true, 'papz', false, false, false, false, false, false);
   $('#inputFileAdd').die('click').live('change', function() { 
      $("#uplFormAdd").ajaxForm({target: '#addLogo', 
          beforeSubmit:function(){ 
            console.log('ttest');
            $("#imageFileAddLoader").show();
            $("#imageFileAddOutput").hide();
            $("#addLogo").html('');
         }, 
         success:function(){ 
            console.log('test');
            $("#imageFileAddLoader").hide();
            $("#imageFileAddOutput").show();
         }, 
         error:function(){ 
            console.log('xtest');
            $("#imageFileAddLoader").hide();
            $("#imageFileAddOutput").show();
         } 
      }).submit();
   });
   $('#inputFileUps').die('click').live('change', function() { 
      $("#uplFormUps").ajaxForm({target: '#upsLogo', 
          beforeSubmit:function(){ 
            console.log('ttest');
            $("#imageFileUpsLoader").show();
            $("#imageFileUpsOutput").hide();
            $("#upsLogo").html('');
         }, 
         success:function(){ 
            console.log('test');
            $("#imageFileUpsLoader").hide();
            $("#imageFileUpsOutput").show();
         }, 
         error:function(){ 
            console.log('xtest');
            $("#imageFileUpsLoader").hide();
            $("#imageFileUpsOutput").show();
         } 
      }).submit();
   });
   $(".logo").img();
});
</script>
