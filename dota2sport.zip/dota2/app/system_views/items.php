<div class="container bg">
	<div class="row">
    	<div class="span3">
	    	<?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		  	<?php print getViewsContents('ticker', $STEAM) ?>
		</div>
		<div class="span9">
         <div class="pagetitle">
            <h2>ITEMS</h2>
            <p>MY ITEMS</p>
         </div>
         <div id="main-content">
         <div class="row-fluid grid-set">
            <div class="row-fluid grid-set">
				<div class="span6">
					<div class="box dark">
						<div class="header"><h4>Armory</h4></div>
						<div class="content pad">
							<div class="inventoryItemBoxHolder"></div>
						</div>
					</div>
				</div>
				<div class="span6">
					<div class="box dark">
						<div class="header">
                            <h4>Returns</h4>
                            <div class="tradeBot pointer">
                                <span class="label label-info">Trade Offer</span>
                            </div>
                        </div>
						<div class="content pad">
							<div class="backpackItemBoxHolder"></div>
						</div>
					</div>
				</div>
            	<div class="clear"></div>
            </div>
    	</div>
	</div>
</div>
<div class="getItem">
    <div class="getItemBoxHolder">
        <div class="getInventoryItemsPopUpBox"></div>
        <div class="getBackpackItemsPopUpBox"></div>
    </div>
</div>
<?php
    $getItemForm = $forms->startForm("dota/getItemsInBot&cookieFile={}", "post", "getItems", array(
        'name' => 'getItems',
        'class' => 'form-horizontal system',
        'location' => $links,
        'filter' => random_string(5)
    )).$forms->endForm();
?>
<script type="text/javascript">
$(document).ready(function(){
	var BARTGAMING = new SelectorCache(), 
        ITEMLOADER = BASEURL + "images/elements/file_manager/spinner.gif",
        TRADEOFFER = <?php echo $OFFER? "true" : "false" ?>;

	BARTGAMING.get("div.inventoryItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
	BARTGAMING.get("div.backpackItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
    BARTGAMING.get("div.getItem").hide();
    BARTGAMING.get(".label").hide();

    if(TRADEOFFER) {
        var content = $("<div></div>",{id:"<?php print $OFFER['tradeofferid'] ?>"}).html($("<img>", {"src":ITEMLOADER}));
        popup_box({title:"TRADE OFFER",content:content},{close:false,escape:false});
        checkTradeOffer(content, "<?php if($OFFER) print implode(".", array($STEAM->getBotApikey($OFFER['botid']), 'steam')) ?>");
    }

	loadArmoryItems();
 
	function loadArmoryItems() {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserInventory", 
            type:"POST", 
            data:{d:1}, 
            cache:true,
            dataType:"html"
        }).done(function(e){
        	BARTGAMING.get("div.inventoryItemBoxHolder").empty();
            var inventory = $.parseJSON(e);
            $.each(inventory, function(i,v) {
            	var price= $("<div></div>", {class:"itemPrice"}).append(v['price']);
            	var span = $("<span></span>").append(v['rarity']);
            	var type = $("<div></div>", {class:"itemRarity"}).css({"color":v['color']}).append(span);
            	var item = $("<div></div>", {"id":v['data'],"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
            	.css({
            		"background-image":"url("+v['icon']+")",
            		"background-size":"100% 100%",
            		"background-repeat":"no-repeat"
            	})
            	.append(price)
            	.append(type)
            	.attr('itemfromsteam', 1)
            	.attr('data-placement','top')
            	.attr('data-original-title',v['name'])
            	.tooltip();
	            BARTGAMING.get("div.inventoryItemBoxHolder").append(item);
	        });
        }).always(loadReturnItems);
    }

    function loadReturnItems() {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserBackPack", 
            type:"POST", 
            data:{d:1},
            cache:true, 
            dataType:"html"
        }).done(function(e){
        	BARTGAMING.get("div.backpackItemBoxHolder").empty();
        	var inventory = $.parseJSON(e);
        	$.each(inventory, function(i,v) {
        		var price= $("<div></div>", {class:"itemPrice"}).append(v['price']);
            	var span = $("<span></span>").append(v['rarity']);
            	var type = $("<div></div>", {class:"itemRarity"}).css({"color":v['color']}).append(span);
            	var item = $("<div></div>", {id:v['data'],"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
            	.css({
            		"background-image":"url("+v['icon']+")",
            		"background-size":"100% 100%",
            		"background-repeat":"no-repeat"
            	})
            	.append(price)
            	.append(type)
            	.attr('itemfromsteam', 0)
            	.attr('data-placement','top')
            	.attr('data-original-title',v['name'])
            	.tooltip();
                if(v.bettable) {} else item.css({"opacity":0.8});
        		BARTGAMING.get("div.backpackItemBoxHolder").append(item);
        	});
            if(inventory.length) {
                BARTGAMING.get(".label").fadeIn().click(function(){  
                    $.ajax({
                        url:BASEURL + "ajax.php?q=dota/getUserBotsTradedWith", 
                        type:"POST", 
                        data:{d:1},
                        dataType:"html"
                    }).done(function(response){
                        var bots = $.parseJSON(response);
                        var data = $("<ul></ul>",{class:"tradedBots"});
                        $.each(bots, function(i,v) {
                            var bot = $("<li></li>",{id:v.apikey,class:"pointer","items":v.items}).html(v.persona + " - " + Math.round((v.count / inventory.length) * 100) + "%").
                            click(function(){                                
                                $(".icon-remove").click();
                                var cookieFile = $(this).attr("id");
                                var items = $(this).attr("items");
                                $.ajax({
                                    url:BASEURL + "ajax.php?q=dota/getUserReturns", 
                                    type:"POST", 
                                    data:{d:items},
                                    dataType:"html"
                                }).done(function(response){
                                    BARTGAMING.get("div.getInventoryItemsPopUpBox").empty();
                                    BARTGAMING.get("div.getBackpackItemsPopUpBox").empty();
                                    var items = $.parseJSON(response);
                                    $.each(items, function(i,v) {
                                        var price= $("<div></div>", {class:"itemPrice"}).append(v['price']);
                                        var span = $("<span></span>").append(v['rarity']);
                                        var type = $("<div></div>", {class:"itemRarity"}).css({"color":v['color']}).append(span);
                                        var item = $("<div></div>", {id:v['data'],"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
                                        .css({
                                            "background-image":"url("+v['icon']+")",
                                            "background-size":"100% 100%",
                                            "background-repeat":"no-repeat"
                                        })
                                        .append(price)
                                        .append(type)
                                        .attr('data-placement','top')
                                        .attr('data-original-title',v['name'])
                                        .click(function(){$(".tooltip").hide()})
                                        .dblclick(function(){
                                            var me = $(this).attr("me");
                                            if($(this).attr("moved")==1) {
                                                $(this).find("input").remove();
                                                $(this).attr("moved", 0).prependTo(BARTGAMING.get("div.getInventoryItemsPopUpBox"));
                                            } else {
                                                var item = $("<input></input>", {"type":"hidden","name":"items[]","value":me});
                                                $(this).attr("moved", 1).prependTo(BARTGAMING.get("div.getBackpackItemsPopUpBox")).append(item);
                                            }
                                        })
                                        .tooltip();                                        
                                        BARTGAMING.get("div.getInventoryItemsPopUpBox").append(item);
                                    });
                                    var form = '<?php print $getItemForm ?>';
                                    popup_box(
                                        {start:form.replace("{}", cookieFile), title:"GET YOUR ITEMS", width:600, content:BARTGAMING.get("div.getItem").show()},
                                        {submit:true, name:"send", id:"send", class:"btn btn-primary", value:"Trade", close:"Close"}
                                    );
                                });
                            });
                            data.append(bot);
                        });
                        popup_box({title:"BOTS",content:data});
                    });                    
                });
            }
        });	
    }

    function checkTradeOffer(container, cookiefile) {
        var url = BASEURL + "ajax.php?q=dota/checkTradeOffer&cookieFile={}";
        $.ajax({
            url: url.replace("{}", cookiefile),
            type:"POST",
            data:{d:container.attr("id")},
            cache:false,
            dataType:"html"
        }).done(function(response) {
            if(isNaN(response)) {
                container.html(response);
                checkTradeOffer(container, cookiefile);
            } else
                $(location).attr("href", window.location);
        });
    }
});
</script>