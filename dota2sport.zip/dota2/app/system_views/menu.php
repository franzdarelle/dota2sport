<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container">
		   <div id="header">
				<span id="gamingMode" onclick="Redirect('<?php print PAGE_HOME ?>')" title="<?php print WEB_TITLE ?>" class="pointer"><?php print WEB_TITLE ?></span>
				<div id="info">
					<?php if($user->isLogged()): ?>
					<ul id="userBox">
						<li class="dropdown">
					       <a class="dropdown-toggle" data-toggle="dropdown" href="#"><img src="<?php echo $user->data->avatar ?>" class="avatar"><span id="personaname"><?php echo $user->data->personaname ?></span><span class="fit"><b class="caret"></b></span></a>
					       <ul class="dropdown-menu linkOptions">
					       		<li><a href="<?php echo $user->data->profileurl ?>" target="_blank"><span class="icon-acc"></span>Steam Profile</a></li>
					        	<li><a href="<?php echo generateUrl(PAGE_HALT) ?>"><span class="icon-off"></span>Sign Out</a></li>
					       </ul>
					    </li>
					</ul>
					<?php else: ?>
					<a href="<?php echo BASEURL ?>?steam"><img id="steamSignIn" src="http://cdn.steamcommunity.com/public/images/signinthroughsteam/sits_small.png?<?php echo random_string(10) ?>"/></a>
					<?php endif ?>
				</div>
				<div class="clear"></div>
		   </div>
		</div>
	</div>
</div>
