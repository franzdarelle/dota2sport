<div class="container bg">
   <div class="row">
      <div class="span3">
	    <?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		<?php print getViewsContents('ticker', $STEAM) ?>
	  </div>
      <div class="span9">
         <div class="pagetitle">
            <h2>BETS</h2>
            <p>MY BETS</p>
            <span class="pull-right" id="statistic">
	            <p id="winrate"></p>
	            <p id="records"></p>
            </span>
         </div>
         <div id="main-content">
            <div class="row-fluid grid-set">
            <?php 
            	$bets = $won = $lost = 0;
            	if($STAKE): 
            		foreach($STAKE as $stake):		
            			$itemsplaced = $stake['itemsplaced'];
            			$itemsreturned = $stake['itemsreturned'];
            			$team = $stake['team'];
            			$gameid = $stake['game']['id'];
            			$status = $stake['game']['status'];
            			$winner = $stake['game']['winner'];             			           
	            		if(($status==3) AND $winner) {
	            			if($winner==$team) $won++; else $lost++;
	            			$bets++;
	            		} elseif($status==4) continue;
            ?>
            	<div class="matches" id="<?php print $gameid ?>" team="<?php print $team ?>" status="<?php print $status ?>" winner="<?php print $winner ?>">
    				<div class="accordion-group">
    					<div class="accordion-heading">
    						<span class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#<?php print $gameid ?>" href="#collapse<?php print $gameid ?>">
    							<span class="teamA" teamid="<?php print $stake['game']['team1']['id'] ?>"><?php print $stake['game']['team1']['alias'] ?></span>
    							<span>vs</span>
    							<span class="teamB" teamid="<?php print $stake['game']['team2']['id'] ?>"><?php print $stake['game']['team2']['alias'] ?></span>
    							<span class="gamedetails" game="<?php print $gameid ?>"><?php print implode(" &#183; ", array($stake['game']['event']['name'], strtoupper($stake['game']['sport']['name']), strtoupper(date("Y M d h:i A", strtotime($stake['game']['dates']))))) ?></span>
    						</span>
    					</div>
    					<div class="accordion-body collapse" id="collapse<?php print $gameid ?>">
    						<div class="accordion-inner"> 
    							<div class="span6">
									<div class="box dark">
										<div class="header"><h4>Placed</h4></div>
										<div class="content pad">
											<div class="backpackItemBoxHolder"><?php echo $itemsplaced ?></div>
										</div>
									</div>
								</div>
								<div class="span6 itemsReturned">
									<div class="box dark">
										<div class="header"><h4>Won</h4></div>
										<div class="content pad">
											<div class="backpackItemBoxHolder"><?php echo $itemsreturned ?></div>
										</div>
									</div>
								</div>
    						</div>
    					</div>
    				</div>
    			</div>
    		<?php endforeach; endif ?>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
	loadUserBets();
	function loadUserBets() {
		$(".matches").each(function(){
			var obj = $(this);
			var gameid = obj.attr("id");
			var team = obj.attr("team");
			var status = obj.attr("status");
			var winner = obj.attr("winner");		
			var returns = obj.find("div.itemsReturned").hide();
			var accordion  = obj.find(".accordion-toggle");

			if(status==3) {
				obj.find("span[teamid='"+winner+"']").addClass("gamewinners");
				var span = $("<span></span>",{class:"label"});
				if(winner==0) span.addClass("label").html("Draw").prependTo(accordion);
				else {
					if(winner==team) {
						span.addClass("label-success").html("Won").prependTo(accordion);
						returns.show();
					} else
						span.addClass("label-important").html("Lost").prependTo(accordion);
				}
			} else {
				obj.find("span[teamid='"+team+"']").addClass("userTeam");
				$(accordion.removeClass("collapsed").removeAttr("data-toggle").attr("href")).removeClass("collapse");
				if(status==0) {					
					if(!obj.find("span.label-deep-blue").length) {						
						var teamSwitcher = $("<span></span>",{class:"label label-deep-blue"})
							.attr('gameid', gameid)
							.html("Switch Team")
							.prependTo(accordion);
						teamSwitcher.click(function(){
							var gameid = $(this).attr('gameid');
							$.ajax({
								url:BASEURL + "ajax.php?q=dota/getUserStakes",
								type:"POST",
								data:{d:gameid},
								cache:true,
								dataType:"html"
					       	}).done(function(e){
					        	var d = $.parseJSON(e);
					        	var teamA = $("div#"+gameid+" span.teamA").attr("teamid");
								var teamB = $("div#"+gameid+" span.teamB").attr("teamid");
								var team = (d.team==teamA)? teamB : teamA; 
								$.ajax({
									url:BASEURL + "ajax.php?q=dota/changeUserTeam",
									type:"POST",
									data:{d:[gameid, team]},
									cache:true,
									dataType:"html"
						       	}).done(function(e){
						       		$("div#"+gameid+" span.userTeam").removeClass("userTeam");
									$("div#"+gameid+" span[teamid='"+team+"']").addClass("userTeam");
						       		popup_box({content:e});
						    	});
					        });
						});
						observeMatch(teamSwitcher);
					}
				} else if(status==1) { 
					$("<span></span>",{class:"label label-warning"}).html("Live").prependTo(accordion);
				} else if(status==2) {
					$("<span></span>",{class:"label label-info"}).html("Hold").prependTo(accordion);
				}
			}
		});
	}

	function observeMatch(button) { 
		$.ajax({
			url:BASEURL + "ajax.php?q=game/get",
			type:"POST",
			data:{d:$(button).attr('gameid')},
			cache:true,
			dataType:"html"
       	}).done(function(e){
        	var d = $.parseJSON(e);
        	if(parseInt(d.status)>0) {
        		$(location).attr("href", window.location);
        	} else
        		observeMatch(button);
        });
	}

	$(".inventoryItems").tooltip();
	$(".label").css({"margin-left":-7,"margin-right":5,"min-width":"40px","text-align":"center"});
	$(".accordion-inner").css({"padding":20,"overflow":"hidden"});
	$("div.pagetitle p#winrate").text(<?php print $won? number_format((($won / $bets) * 100), 2) : 0 ?>+"% WIN RATE")
	$("div.pagetitle p#records").text(<?php print $won ?>+" - "+<?php print $lost ?>+" RECORD");
	$(".gamedetails").click(function() { Redirect('<?php print implode("/", array(MAIN_CLASS, USER_CLASS, "match/")) ?>' + $(this).attr("game")) });
});
</script>