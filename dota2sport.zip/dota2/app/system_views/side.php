<div class="sidebar">
    <ul class="side-nav sliding_menu collapsible">
    <?php 
    	if($user->getType()): 
    		$http = implode("/", array(MAIN_CLASS,BART_CLASS,''));
    		$menu = array(
    			$data->setMenu($page, $http, 'sport'),
    			$data->setMenu($page, $http, 'event'),
    			$data->setMenu($page, $http, 'team'),
    			$data->setMenu($page, $http, array('game','view')),
                $data->setMenu($page, $http, array('item','trade')),
                $data->setMenu($page, $http, array('bot','log')),
                $data->setMenu($page, $http, 'user'),
                $data->setMenu($page, $http, 'chart')
    		);
    ?>
    	<li><a class="nobordertop <?php echo $menu[0]['class'] ?>" href="<?php echo $menu[0]['links'] ?>"><span class="icon_dash"></span>Sport</a></li>
    	<li><a class="<?php echo $menu[1]['class'] ?>" href="<?php echo $menu[1]['links'] ?>"><span class="icon_agenda"></span>Event</a></li>
    	<li><a class="<?php echo $menu[2]['class'] ?>" href="<?php echo $menu[2]['links'] ?>"><span class="icon_users"></span>Team</a></li>
    	<li><a class="<?php echo $menu[3]['class'] ?>" href="<?php echo $menu[3]['links'] ?>"><span class="icon_stats"></span>Game</a></li>
        <li><a class="<?php echo $menu[4]['class'] ?>" href="<?php echo $menu[4]['links'] ?>"><span class="icon_projects"></span>Item</a></li>
        <li><a class="<?php echo $menu[5]['class'] ?>" href="<?php echo $menu[5]['links'] ?>"><span class="icon_users"></span>Bot</a></li>
        <li><a class="<?php echo $menu[6]['class'] ?>" href="<?php echo $menu[6]['links'] ?>"><span class="icon_users"></span>User</a></li>
        <li><a class="<?php echo $menu[7]['class'] ?>" href="<?php echo $menu[7]['links'] ?>"><span class="icon_charts"></span>Chart</a></li>
    <?php 
        else: 
            $http = implode("/", array(MAIN_CLASS,USER_CLASS,''));
            $menu = array(
                $data->setMenu($page, $http, array('matches','match')),
                $data->setMenu($page, $http, 'bets'),
                $data->setMenu($page, $http, 'items')
            );
    ?>
        <li><a class="nobordertop <?php echo $menu[0]['class'] ?>" href="<?php echo $menu[0]['links'] ?>"><span class="icon_dash"></span>Matches</a></li>
        <?php if($user->isLogged()): ?>
        <li><a class="<?php echo $menu[1]['class'] ?>" href="<?php echo $menu[1]['links'] ?>"><span class="icon_stats"></span>Bets</a></li>
        <li><a class="<?php echo $menu[2]['class'] ?>" href="<?php echo $menu[2]['links'] ?>"><span class="icon_projects"></span>Items</a></li>
        <?php endif ?>
    <?php endif ?>
    </ul>
</div>