<div class="container bg">
	<div class="row">
    	<div class="span3">
	    	<?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		</div>
		<div class="span9">
         <div class="pagetitle">
            <h2><?php print $bot['persona'] ?></h2>
            <p><?php print $bot['username'] ?></p>
         </div>
         <div id="main-content">
         <div class="row-fluid grid-set">
            <div class="row-fluid grid-set">
				<div class="span6">
					<div class="box dark">
						<div class="header">
                            <h4><?php print strtoupper(WEB_TITLE) ?></h4>
                            <div class="tradeBot pointer">
                                <span id="addItem" class="label label-info">Add Item</span>
                                <span id="getItem" class="label label-important">Get Item</span>
                            </div>
                        </div>
						<div class="content pad">
							<div class="inventoryItemBoxHolder"></div>
						</div>
					</div>
				</div>
				<div class="span6">
					<div class="box dark">
						<div class="header"><h4>USER</h4></div>
						<div class="content pad">
							<div class="backpackItemBoxHolder"></div>
						</div>
					</div>
				</div>
            	<div class="clear"></div>
            </div>
    	</div>
	</div>
</div>
<div class="addItem">
    <div class="addItemBoxHolder">
        <div class="addInventoryItemsPopUpBox"></div>
        <div class="addBackpackItemsPopUpBox"></div>
    </div>
</div>
<div class="getItem">
    <div class="getItemBoxHolder">
        <div class="getInventoryItemsPopUpBox"></div>
        <div class="getBackpackItemsPopUpBox"></div>
    </div>
</div>
<div class="dota2ItemBoxHolder"></div>
<?php
    $cookieFile = implode(".", array($bot['apikey'],'steam'));
    $addItemForm = $forms->startForm("dota/addItemsToBot&cookieFile=".$cookieFile, "post", "addItems", array(
        'name' => 'addItems',
        'class' => 'form-horizontal system',
        'location' => $links,
        'filter' => random_string(5)
    )).$forms->endForm();
    $getItemForm = $forms->startForm("dota/getItemsInBot&cookieFile=".$cookieFile, "post", "getItems", array(
        'name' => 'getItems',
        'class' => 'form-horizontal system',
        'location' => $links,
        'filter' => random_string(5)
    )).$forms->endForm();
?>
<script type="text/javascript">
$(document).ready(function(){
	var BARTGAMING = new SelectorCache(), 
        ITEMLOADER = BASEURL + "images/elements/file_manager/spinner.gif",
        TRADEOFFER = <?php echo $OFFER? "true" : "false" ?>; 
        
	BARTGAMING.get("div.inventoryItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
	BARTGAMING.get("div.backpackItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
    BARTGAMING.get("div.dota2ItemBoxHolder").hide();

    if(TRADEOFFER) {
        var content = $("<div></div>",{id:"<?php print $OFFER['tradeofferid'] ?>"}).html($("<img>", {"src":ITEMLOADER}));
        popup_box({title:"TRADE OFFER",content:content},{close:false,escape:false});
        checkAdminOffer(content);
    }

    $.ajax({
        url:BASEURL + "ajax.php?q=dota/getBotInventory", 
        type:"POST", 
        data:{botid:<?php print $bot['id'] ?>}, 
        cache:true,
        dataType:"html"
    }).done(function(e){
        BARTGAMING.get("div.inventoryItemBoxHolder").empty();
        BARTGAMING.get("div.backpackItemBoxHolder").empty();
        var inventory = $.parseJSON(e);
        $.when(
            $.each(inventory, function(i,v) {
                var price= $("<div></div>", {class:"itemPrice"}).append(v.price);
                var span = $("<span></span>").append(v.rarity);
                var type = $("<div></div>", {class:"itemRarity"}).css({"color":v.color}).append(span);
                var item = $("<div></div>", {"id":v.data,"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
                .css({
                    "background-image":"url("+v.icon+")",
                    "background-size":"100% 100%",
                    "background-repeat":"no-repeat"
                })
                .append(price)
                .append(type)
                .attr('data-placement', 'top')
                .attr('data-original-title', v.name)
                .tooltip();
                if(v.bettable) {} else item.css({"opacity":0.8});
                v.botitem? BARTGAMING.get("div.inventoryItemBoxHolder").append(item) : BARTGAMING.get("div.backpackItemBoxHolder").append(item);
            })
        ).then(function(){
            BARTGAMING.get("#getItem").add('<?php print $getItemForm ?>', 'Get Items', BARTGAMING.get("div.getItem"), 600, true, 'dogz', function(){
            BARTGAMING.get("div.getInventoryItemsPopUpBox").empty();
            BARTGAMING.get("div.getBackpackItemsPopUpBox").empty();
            BARTGAMING.get("div.inventoryItemBoxHolder").find('div.inventoryItems').each(function(){
                $(this)
                    .clone()
                    .tooltip()
                    .appendTo(BARTGAMING.get("div.getInventoryItemsPopUpBox"))
                    .click(function(){$(".tooltip").hide()})
                    .dblclick(function(){
                        var me = $(this).attr("me");
                        if($(this).attr("moved")==1) {
                            $(this).find("input").remove();
                            $(this).attr("moved", 0).prependTo(BARTGAMING.get("div.getInventoryItemsPopUpBox"));
                        } else {
                            var item = $("<input></input>", {"type":"hidden","name":"items[]","value":me});
                            $(this).attr("moved", 1).prependTo(BARTGAMING.get("div.getBackpackItemsPopUpBox")).append(item);
                        }
                    });
            });
        }, 'save', 'save', 'btn btn-primary', 'Trade', 'Close');
        });
    });

    $.ajax({
        url:BASEURL + "ajax.php?q=dota/getUserInventory", 
        type:"POST", 
        data:{d:1}, 
        cache:true,
        dataType:"html"
    }).done(function(e){
        var inventory = $.parseJSON(e);
        $.when(
            $.each(inventory, function(i,v) {
                var price= $("<div></div>", {class:"itemPrice"}).append(v.price);
                var span = $("<span></span>").append(v.rarity);
                var type = $("<div></div>", {class:"itemRarity"}).css({"color":v.color}).append(span);
                var item = $("<div></div>", {"id":v.data,"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
                .css({
                    "background-image":"url("+v.icon+")",
                    "background-size":"100% 100%",
                    "background-repeat":"no-repeat"
                })
                .append(price)
                .append(type)
                .attr('data-placement', 'top')
                .attr('data-original-title', v.name)
                .tooltip();
                BARTGAMING.get("div.dota2ItemBoxHolder").append(item);
            })
        ).then(function(){
            BARTGAMING.get("#addItem").add('<?php print $addItemForm ?>', 'Add Items', BARTGAMING.get("div.addItem"), 600, true, 'bart', function(){
                BARTGAMING.get("div.addInventoryItemsPopUpBox").empty();
                BARTGAMING.get("div.addBackpackItemsPopUpBox").empty();
                BARTGAMING.get("div.dota2ItemBoxHolder").find('div.inventoryItems').each(function(){
                    $(this)
                        .clone()
                        .tooltip()
                        .appendTo(BARTGAMING.get("div.addInventoryItemsPopUpBox"))
                        .click(function(){$(".tooltip").hide()})
                        .dblclick(function(){
                            var me = $(this).attr("me");
                            if($(this).attr("moved")==1) {
                                $(this).find("input").remove();
                                $(this).attr("moved", 0).prependTo(BARTGAMING.get("div.addInventoryItemsPopUpBox"));
                            } else {
                                var item = $("<input></input>", {"type":"hidden","name":"items[]","value":me});
                                $(this).attr("moved", 1).prependTo(BARTGAMING.get("div.addBackpackItemsPopUpBox")).append(item);
                            }
                        });
                });
            }, 'save', 'save', 'btn btn-primary', 'Trade', 'Close');
        });
    });

    function checkAdminOffer(container) {
        $.ajax({
            url:BASEURL + "ajax.php?q=dota/checkAdminOffer&cookieFile=<?php print $cookieFile ?>",
            type:"POST",
            data:{d:container.attr("id")},
            cache:false,
            dataType:"html"
        }).done(function(response) {
            if(isNaN(response)) {
                container.html(response);
                checkAdminOffer(container);
            } else
                $(location).attr("href", window.location);
        });
    }
});
</script>