<div class="container bg">
   <div class="row">
      <div class="span3">
      	<?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?>
		<?php print getViewsContents('ticker', $STEAM) ?>
	  </div>
      <div class="span9">
         <div class="pagetitle">
            <h2>MATCH</h2>
            <p><?php print stripslashes(strtoupper($FIGHT['team1']['name']) . ' vs ' . strtoupper($FIGHT['team2']['name']) . ' &#183; ' . $FIGHT['event']['name']) ?></p>
         </div>
         <div id="main-content">
         	<div class="row-fluid grid-set" id="liveStreams"><?php print $FIGHT['stream'] ?></div>
            <div class="row-fluid grid-set">
				<div class="span6">
					<div class="box dark">
						<div class="header">
							<h4><?php echo stripslashes($FIGHT['event']['name']) ?></h4>
							<div class="matchTime">
								<span class="state"></span>
								<span class="stamp"></span>
							</div>
						</div>
						<div class="content pad">
							<div class="span4 teams" teamID="<?php echo $FIGHT['team1']['id'] ?>" gameID="<?php echo $FIGHT['id'] ?>">
								<div class="content pad center">
									<img src="<?php echo BASEURL . 'upl/team/' . $FIGHT['team1']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($FIGHT['team1']['alias']) ?></h4>
								</div>
							</div>
							<div class="span4">
								<div class="header center">
									<h4 class="nobottomborder scores">
										<span class="score1"><?php echo $FIGHT['score1'] ?></span>
										<span class="score2"><?php echo $FIGHT['score2'] ?></span>
										<span>vs</span>
									</h4>
								</div>
								<div class="content pad center">
									<span class="label label-info">Best of <?php echo $FIGHT['games'] ?></span>
								</div>
								<div class="header center">
									<h4 class="nobottomborder odds">
										<span class="odds1"></span>
										<span class="odds2"></span>
									</h4>
								</div>
							</div>
							<div class="span4 teams" teamID="<?php echo $FIGHT['team2']['id'] ?>" gameID="<?php echo $FIGHT['id'] ?>">
								<div class="content pad center">
									<img src="<?php echo BASEURL . 'upl/team/' . $FIGHT['team2']['logo'] ?>" class="pix">
								</div>
								<div class="header center">
									<h4 class="nobottomborder"><?php echo stripslashes($FIGHT['team2']['alias']) ?></h4>
								</div>
							</div>
						</div>
						<div class="box dark under">
							<div class="header"><h4>Potential Reward</h4></div>
							<div class="content">
								<div class="content potentialReward">
									<div class="span6 label teamAValue" teamID="<?php echo $FIGHT['team1']['id'] ?>">1 for 1</div>
									<div class="span6 label teamBValue" teamID="<?php echo $FIGHT['team2']['id'] ?>">1 for 1</div>
								</div>
								<div class="content potentialReward">
									<div class="span6 label label-info" id="yourAValue">0 for 0</div>
									<div class="span6 label label-info" id="yourBValue">0 for 0</div>
								</div>
							</div>
						</div>
						<div class="content box dark stakedItems">
							<div class="header">
								<h4 class="nobottomborder"></h4>
								<div class="placeBet">
									<span class="label label-info pointer" id="placeBet">Place Bet</span>
								</div>
							</div>
							<div class="content pad">
								<div class="stakedItemBoxHolder"></div>
							</div>
						</div>
						<div class="content box dark rewardItems">
							<div class="header">
								<h4 class="nobottomborder">Returns</h4>
							</div>
							<div class="content pad">
								<div class="rewardItemBoxHolder"></div>
							</div>
						</div>
					</div>
				</div>
				<div id="placedItems" class="span6 label"></div>
				<div id="stakedItems" class="span6">
					<div class="box dark">
						<div class="header"><h4>Bets Placed</h4></div>
						<div class="content"></div>
					</div>
				</div>
            	<div class="clear"></div>
            </div>
            <div class="row-fluid grid-set" id="itemsHolder">
            	<div class="span6">
            		<div class="box dark">
            			<div class="tabbed tabs2 padding-reset">
            				<div class="header">
            					<ul>
            						<li><a href="#armory">Armory</a></li>
            						<li><a href="#returns">Returns</a></li>
            					</ul>
            				</div>
	            			<div class="content">
	            				 <div class="tabs2">
	            				 	<div id="armory">
	            				 		<div class="inventoryItemBoxHolder"></div>
	            				 	</div>
	            				 	<div id="returns">
	            				 		<div class="backpackItemBoxHolder"></div>
	            				 	</div>
	            				 </div>
	            			</div>
            			</div>
            		</div>
				</div>
            </div>
    	</div>
   </div>
</div>
<?php
	$userUrl = false;
	if($USERS->isLogged()) {
		$getUser = $STEAM->getUser($USERS->getUser());
		$userUrl = $getUser['links'];
	}
	$randUrl = random_string(5);
	$attrUrl = array(
		'name' => 'addLinks',
		'class' => 'form-horizontal system',
		'location' => $links,
		'filter' => $randUrl
	);
	$addLinkForm = $forms->startForm("dota/addUserTradeURL", "post", "addLinks", $attrUrl).$forms->endForm();
	$steamTradeURL = '<a id="steamTradeURL" href="http://steamcommunity.com/id/me/tradeoffers/privacy" target="_blank">Steam Trade URL</a>';
?>
<div class="addLink">
	<input class="input-block-level <?php echo $randUrl ?>" type="text" name="tradeURL" value="<?php echo $userUrl ?>">
</div>
<script type="text/javascript">
var BARTGAMING = new SelectorCache(),
	ITEMLOADER = BASEURL + "images/elements/file_manager/spinner.gif",
	LIVESTREAM = $("#liveStreams").hide(),
	STEAMTRADE = $("<li></li>"),
	UPDATETIME = 10000,
	STAKELIMIT = <?php echo STAKELIMIT ?>, 
	CURRENTGID = <?php echo $FIGHT['id'] ?>,
	USERLOGGED = <?php echo $USERS->isLogged()? "true" : "false" ?>, 
	USERBETTOR = <?php echo ($USERS->isLogged() AND $USERS->getType())? "false" : "true" ?>,
	ISTRADABLE = <?php echo $userUrl? "true" : "false" ?>,
	TRADEOFFER = <?php echo $OFFER? "true" : "false" ?>;

$(document).ready(function(){
	$(".center").find("h4").css({"padding-left":0});
	BARTGAMING.get("div.stakedItems").hide();
	BARTGAMING.get("div.rewardItems").hide();
	BARTGAMING.get("#placedItems").hide();
    BARTGAMING.get("#stakedItems").hide();
	BARTGAMING.get("#placeBet").click(function(){
		var $placed = $(this);
		var $picked = $(".picked");
		if($picked.length) {
			$placed.unbind("click").removeClass("label-info");
			var teamID = $picked.attr("teamID");
			var gameID = $picked.attr("gameID");
			var armoryItems = new Array;
			var returnItems = new Array;
 
			BARTGAMING.get("div.stakedItemBoxHolder").find("div.inventoryItems").each(function(){
				var item = $(this);
				if(item.hasClass("staked")) {}
				else {
					if(item.attr("itemfromsteam")==1) {
						armoryItems.push(item.attr("me"));
					} else {
						returnItems.push(item.attr("id"));
					}
				}				
	    	});

			$.ajax({
				url:BASEURL + "ajax.php?q=dota/placeBet",
				type:"POST",
				data:{armoryItems:armoryItems, returnItems:returnItems, teamID:teamID, gameID:gameID},
				cache:false,
				dataType:"html"
	       	}).done(function(response){
	       		if(isNaN(response)) {
	       			popup_box({content:response});
	       			$placed.bind("click").addClass("label-info");
	       		} else 
	       			$(location).attr("href", window.location);
	       	});
		} else popup_box({content:"Please select your team"});
	});

	var updateOdds = true, updateScores = true, updateReward = true;
	setTime();
	setOdds();
	setScores();
	
    if(USERLOGGED) {
    	if(TRADEOFFER) {
    		var content = $("<div></div>",{id:"<?php print $OFFER['tradeofferid'] ?>"}).html($("<img>", {"src":ITEMLOADER}));
    		popup_box({title:"TRADE OFFER",content:content},{close:false,escape:false});
    		checkTradeOffer(content);
    	}
    	if(ISTRADABLE) {
			BARTGAMING.get(".teams").addClass("pointer").each(function(){
				$(this).click(function(e){
					var team = $(this);
					$(".highlightedTeam").removeClass("highlightedTeam").removeClass("picked");
					team.addClass("highlightedTeam").addClass("picked");
					calculate();
				}); 
			});
			STEAMTRADE.append('<a href="#"><i class="icon-modify"></i>Trade URL</a>');
			STEAMTRADE.add('<?php print $addLinkForm ?>', '<?php print $steamTradeURL ?>', BARTGAMING.get("div.addLink"), 600, true, 'kriz', true, 'save', 'save', 'btn btn-primary', 'Save URL', 'Cancel');
			STEAMTRADE.insertBefore($(".dropdown-menu.linkOptions").find('li').last()); 
		} else {
			if(USERBETTOR) {
				popup_box(
					{start: '<?php print $addLinkForm ?>', title: '<?php print $steamTradeURL ?>', content: BARTGAMING.get("div.addLink").show(), width: 600, place: true, class: 'kriz'}, 
					{submit: true, name: 'save', id: 'save', class: 'btn btn-primary', value: 'Save URL', close: false, escape: false}
				);
			} else
				BARTGAMING.get("div.addLink").remove();
			BARTGAMING.get("div.rewardItems").remove();
			BARTGAMING.get("div.stakedItems").remove();
		}
		BARTGAMING.get("div.backpackItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
		BARTGAMING.get("div.inventoryItemBoxHolder").html($("<img>", {"src":ITEMLOADER}));
		loadStakedItems();
	} else {
		$("div.addLink, #itemsHolder").remove();
		BARTGAMING.get("div.potentialReward").last().remove();
	}

	function loadStakedItems() {
		$.when($.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserStakes", 
            type:"POST", 
            data:{d:CURRENTGID}, 
            cache:true,
            dataType:"html"
        })).done(function(response){
			if(isNaN(response)) {
        		var stake = $.parseJSON(response);
        		$(".teams[teamID='"+stake.team+"']").click();
        		BARTGAMING.get("div.stakedItemBoxHolder").append(stake.items);
        		BARTGAMING.get("div.stakedItemBoxHolder").find("div.inventoryItems").addClass('staked').css({"opacity":0.8}).tooltip();
        		calculate();
        	}
        }).then(loadArmoryItems, loadStakedItems);
	}

	function loadArmoryItems() {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserInventory", 
            type:"POST", 
            data:{d:1}, 
            cache:true,
            dataType:"html"
        }).done(function(e){
        	BARTGAMING.get("div.inventoryItemBoxHolder").empty();
            var inventory = $.parseJSON(e);
            $.each(inventory, function(i,v) {
            	var price= $("<div></div>", {class:"itemPrice"}).append(v.price);
            	var span = $("<span></span>").append(v.rarity);
            	var type = $("<div></div>", {class:"itemRarity"}).css({"color":v.color}).append(span);
            	var item = $("<div></div>", {"id":v.data,"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
            	.css({
            		"background-image":"url("+v.icon+")",
            		"background-size":"100% 100%",
            		"background-repeat":"no-repeat"
            	})
            	.append(price)
            	.append(type)
            	.attr('itemfromsteam', 1)
            	.attr('data-placement', 'top')
            	.attr('data-original-title', v.name)
            	.tooltip()
            	.click(function(){
            		putItems($(this));
            	});
	            BARTGAMING.get("div.inventoryItemBoxHolder").append(item);
	        });
        }).always(loadReturnItems);
    }

    function loadReturnItems() {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserBackPack", 
            type:"POST", 
            data:{d:1},
            cache:true, 
            dataType:"html"
        }).done(function(e){
        	BARTGAMING.get("div.backpackItemBoxHolder").empty();
        	var inventory = $.parseJSON(e);
        	$.each(inventory, function(i,v) {
        		if(v.bettable) {
        			var price= $("<div></div>", {class:"itemPrice"}).append(v.price);
	            	var span = $("<span></span>").append(v.rarity);
	            	var type = $("<div></div>", {class:"itemRarity"}).css({"color":v.color}).append(span);
	            	var item = $("<div></div>", {id:v.data,"me":$.map(v, function(e){return e}).join(', '),class:"box"}).addClass("inventoryItems")
	            	.css({
	            		"background-image":"url("+v.icon+")",
	            		"background-size":"100% 100%",
	            		"background-repeat":"no-repeat"
	            	})
	            	.append(price)
	            	.append(type)
	            	.attr('itemfromsteam', 0)
	            	.attr('data-placement', 'top')
	            	.attr('data-original-title', v.name)
	            	.tooltip()
	            	.click(function(){
	            		putItems($(this));
	            	});
	        		BARTGAMING.get("div.backpackItemBoxHolder").append(item);
        		}        		
        	});
        	if(inventory.length) $("a[href='#returns']").click();
        });	
    }

    function loadRewardItems() {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserRewards", 
            type:"POST", 
            data:{d:CURRENTGID}, 
            cache:true,
            dataType:"html"
        }).done(function(response){
        	if(isNaN(response)) {
        		var stake = $.parseJSON(response);
        		BARTGAMING.get("div.rewardItemBoxHolder").append(stake.items);
        		BARTGAMING.get("div.rewardItemBoxHolder").find("div.inventoryItems").addClass('reward').css({"opacity":0.8}).tooltip();
        		BARTGAMING.get("div.rewardItems").show();
        	} else
        		BARTGAMING.get("div.rewardItems").hide();
        });
	}
 
    function calculate() {
    	var stakeAmount = 0;
    	var itemsPlaced = 0;
    	var teamAAmount = parseFloat(BARTGAMING.get(".odds1").attr("amount"));
    	var teamBAmount = parseFloat(BARTGAMING.get(".odds2").attr("amount"));
    
    	BARTGAMING.get("div.stakedItemBoxHolder").find("div.inventoryItems").each(function(){
    		stakeAmount += parseFloat($(this).find("div.itemPrice").html().replace("$",""));
    		itemsPlaced ++;
    	});

 		stakeAmount = Math.round(stakeAmount * 100) / 100;
 		if(stakeAmount == 0) {
 			BARTGAMING.get("#yourAValue").html("0 for 0");
	 		BARTGAMING.get("#yourBValue").html("0 for 0");
	 		BARTGAMING.get("div.stakedItems").find('h4').empty();
	 		BARTGAMING.get("div.stakedItems").hide();
	 	} else {	 		
	 		var teamPicked = $(".picked").length? " - " + $("<span></span>", {class:"userTeam"}).text($(".picked").find("h4").html()).get(0).outerHTML : "";
	 		var yourAValue = Math.round((teamBAmount*stakeAmount/teamAAmount) * 95) / 100;
	 		var yourBValue = Math.round((teamAAmount*stakeAmount/teamBAmount) * 95) / 100;
	 		BARTGAMING.get("#yourAValue").html(yourAValue + " for " + stakeAmount);
	 		BARTGAMING.get("#yourBValue").html(yourBValue + " for " + stakeAmount);
	 		BARTGAMING.get("div.stakedItems").find('h4').html("Your " + ((itemsPlaced>1)? "items" : "item") + " to bet" + teamPicked);
	 		BARTGAMING.get("div.stakedItems").show();
	 	}
    }

    function putItems(item) {
    	$('.tooltip').hide();
    	if(BARTGAMING.get("div.stakedItemBoxHolder").find("div.inventoryItems").length < STAKELIMIT) {
    		item.unbind("click").prependTo(BARTGAMING.get("div.stakedItemBoxHolder"));
	    	item.click(function(){
	    		$('.tooltip').hide();
	    		var item = $(this);
	    		if(item.attr("itemfromsteam")==1) {
	    			item.unbind("click").prependTo(BARTGAMING.get("div.inventoryItemBoxHolder"));
	    		} else {
	    			item.unbind("click").prependTo(BARTGAMING.get("div.backpackItemBoxHolder"));
	    		}
	    		item.click(function(){
					putItems($(this));
				});
	    		calculate();
	    	});
		 	calculate();
    	}
    }

    function checkTradeOffer(container) {
		$.ajax({
			url:BASEURL + "ajax.php?q=dota/checkTradeOffer",
			type:"POST",
			data:{d:container.attr("id")},
			cache:false,
			dataType:"html"
       	}).done(function(response) {
       		if(isNaN(response)) {
       			container.html(response);
       			checkTradeOffer(container);
	       	} else
	       		$(location).attr("href", window.location);
       	});
	}

    function setTime() {
		$.ajax({
            url:BASEURL + "ajax.php?q=game/getGameTime", 
            type:"POST", 
            data:{d:CURRENTGID}, 
            cache:true,
            dataType:"html"
        }).done(function(response){
        	BARTGAMING.get("span.stamp").html(response);
        }).always(setTimeout(setTime, UPDATETIME));
	}

    function setOdds() {
    	if(updateOdds) {
			$.ajax({
				url:BASEURL + "ajax.php?q=dota/getGameOdds",
				type:"POST",
				data:{d:CURRENTGID},
				cache:true,
				dataType:"html"
	       	}).done(function(e){
	       		var odds = $.parseJSON(e);
	       		BARTGAMING.get(".odds1").text(odds.odd1+"%").attr("amount", odds.val1);
	       		BARTGAMING.get(".odds2").text(odds.odd2+"%").attr("amount", odds.val2);
	       		BARTGAMING.get("#placedItems").html(odds.user+" people placed "+odds.item+" items.");
	       		setReward(odds.val1, odds.val2);
	       		setBets(odds.bets);
	       		calculate();
       			if(odds.user>1) {
       				BARTGAMING.get("#placedItems").show();
       				BARTGAMING.get("#stakedItems").removeClass('notop').show();
       			} else {
       				BARTGAMING.get("#placedItems").hide();
       				BARTGAMING.get("#stakedItems").addClass("notop").hide();
       			}   		
	    	}).always(setTimeout(setOdds, UPDATETIME));
    	}
	}

	function setBets(data) {
		var stakedItems = BARTGAMING.get("#stakedItems").find("div.content").empty();
		$.each(data, function(user,item){
			$("<div></div>",{class:"content box"}).css({"margin":10})
			.append($("<div></div>",{class:"header"}).html('<h4 class="nobottomborder">'+user+'</h4>'))
			.append($("<div></div>",{class:"content pad"}).html('<div class="placedItemBoxHolder">'+item+'</div>'))
			.appendTo(stakedItems);
		});
		stakedItems.find("div.placedItemBoxHolder div.inventoryItems").tooltip()
	}

	function setReward(teamAAmount, teamBAmount) {
		var teamAValue = teamBAmount / teamAAmount;
    	var teamBValue = teamAAmount / teamBAmount;
    	BARTGAMING.get(".teamAValue").html(((teamAValue==parseInt(teamAValue))? teamAValue : teamAValue.toFixed(1)) + " for 1");
    	BARTGAMING.get(".teamBValue").html(((teamBValue==parseInt(teamBValue))? teamBValue : teamBValue.toFixed(1)) + " for 1");
    }

    function setScores() {
    	if(updateScores) {
    		$.ajax({
				url:BASEURL + "ajax.php?q=game/get",
				type:"POST",
				data:{d:CURRENTGID},
				cache:true,
				dataType:"html"
	       	}).done(function(e){
	        	var d = $.parseJSON(e);
	        	BARTGAMING.get(".score1").text(d.score1);
	        	BARTGAMING.get(".score2").text(d.score2);
	        	if(d.status > 0) GameStatusChanged(parseInt(d.status),d.winner,d.team1.id,d.team2.id);
	       	}).always(setTimeout(setScores, UPDATETIME));
    	}
    }

    function GameStatusChanged(status, winner, teamA, teamB) {
    	$.ajax({
            url:BASEURL + "ajax.php?q=dota/getUserStakes", 
            type:"POST", 
            data:{d:CURRENTGID}, 
            cache:true,
            dataType:"html"
        }).done(function(response){
        	if(isNaN(response)) {
        		var stake = $.parseJSON(response);
        		if(updateOdds) {
        			BARTGAMING.get("#placeBet").remove();   
	        		BARTGAMING.get("#itemsHolder").remove();
	        		BARTGAMING.get("div.stakedItemBoxHolder").html(stake.items);
	        		BARTGAMING.get("div.stakedItemBoxHolder").find("div.inventoryItems").addClass('staked').css({"opacity":0.8}).tooltip();
	        		calculate();
	        		BARTGAMING.get("div.stakedItems").find('h4').html("Your bet to " + $("<span></span>", {class:"userTeam"}).text($(".teams[teamID='"+stake.team+"']").find("h4").html()).get(0).outerHTML);     		
	        		updateOdds = false;
        		}
        	}
        }).always(function(){
			var teams = BARTGAMING.get(".teams").unbind("click").removeClass("pointer");
			var check = $('<img></img>', {class:"winner"}).attr('src', BASEURL + 'img/check.png');
			var state = BARTGAMING.get("span.state")
				.removeClass("label label-warning label-important")
        		.addClass("label")
        		.hide();
			switch (status) {
				case 1:
					LIVESTREAM.show();
					state.html("ONGOING").addClass("label-warning").show();
				break;
				case 2:
				case 4:
					LIVESTREAM.remove();					
					state.html((status==2)? "POSTPONED" : "CANCELLED").addClass("label-important").show();	
					updateScores = false;				
				break;
				case 3:
					LIVESTREAM.remove();
					teams.find("img.winner").remove();
					if($(".picked").length && ($(".picked").attr("teamID")==winner) && updateReward) {						
						loadRewardItems();
						updateReward = false;
					}					
		        	switch (winner) {
						case teamA:
							$("div[teamID='"+teamA+"']").find("div.content").append(check);
						break;
						case teamB:
							$("div[teamID='"+teamB+"']").find("div.content").append(check);
						break;
						default:
							state.html("DRAW").addClass("label-important").show();
						break;
					}
				break;
			}
        });
    }
});
</script>