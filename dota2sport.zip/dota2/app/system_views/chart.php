<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>CHART</h2>
            <p>SYSTEM STATISTICS</p>
         </div>
         <div id="main-content">
            <div class="row-fluid grid-set">
               <div class="span12">
                  <div class="box dark">
                     <div class="header"><h4>Games</h4></div>
                     <div class="content pad">
                        <div id="gameFlot" class="flot"></div>
                     </div>
                  </div>
               </div>
               <div class="clear"></div>
            </div>
            <div class="row-fluid grid-set">
               <div class="span12">
                  <div class="box dark">
                     <div class="header"><h4>Users</h4></div>
                     <div class="content pad">
                        <div id="userFlot" class="flot"></div>
                     </div>
                  </div>
               </div>
               <div class="clear"></div>
            </div>
            <div class="row-fluid grid-set">
               <div class="span12">
                  <div class="box dark">
                     <div class="header"><h4>Bets</h4></div>
                     <div class="content pad">
                        <div id="betsFlot" class="flot"></div>
                     </div>
                  </div>
               </div>
               <div class="clear"></div>
            </div> 
         </div>
         <div class="clear"></div>
      </div>
   </div>
</div>
<?php 
generate_javascripts($JAVAS);
for ($i=1; $i <= 12 ; $i++) {
   $games[] = '['.$i.','.$STEAM->getGamesCount($YEAR, $i).']';
   $users[] = '['.$i.','.$STEAM->getUsersCount($YEAR, $i).']';
   $stake[] = '['.$i.','.$STEAM->getStakesCount($YEAR, $i).']';
}
?>
<script type="text/javascript">
   var games = [<?php print implode(", ", $games) ?>];
   var users = [<?php print implode(", ", $users) ?>];
   var stake = [<?php print implode(", ", $stake) ?>];
   var label = '<?php print $YEAR ?>';

   $.plot($("#gameFlot"), [
         {
            data: games,
            color: '#058DC7',
            lines: {show:true},
            points: { symbol: "circle", fillColor: "#058DC7", show: true }            
         }
      ], {
      grid: { backgroundColor: 'transparent', borderColor: '#d5d5d5', borderWidth: 1, hoverable: true },
      xaxis: {
         axisLabel: label,
         axisLabelUseCanvas: true,
         axisLabelFontSizePixels: 11,
         axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
         axisLabelPadding: 5
      }
   });

   $.plot($("#userFlot"), [
         {
            data: users,
            color: '#AA4643',
            lines: {show:true},
            points: { symbol: "circle", fillColor: "#AA4643", show: true }
         }
      ], {
      grid: { backgroundColor: 'transparent', borderColor: '#d5d5d5', borderWidth: 1, hoverable: true },
      xaxis: {
         axisLabel: label,
         axisLabelUseCanvas: true,
         axisLabelFontSizePixels: 11,
         axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
         axisLabelPadding: 5
      }
   });

   $.plot($("#betsFlot"), [
         {
            data: stake,
            color: '#378315',
            lines: {show:true},
            points: { symbol: "circle", fillColor: "#378315", show: true }
         }
      ], {
      grid: { backgroundColor: 'transparent', borderColor: '#d5d5d5', borderWidth: 1, hoverable: true },
      xaxis: {
         axisLabel: label,
         axisLabelUseCanvas: true,
         axisLabelFontSizePixels: 11,
         axisLabelFontFamily: 'Verdana, Arial, Helvetica, Tahoma, sans-serif',
         axisLabelPadding: 5
      }
   });  

   $("#gameFlot .xAxis > .tickLabel, #userFlot .xAxis > .tickLabel, #betsFlot .xAxis > .tickLabel").each(function(){
      var m = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];  
      $(this).text(m[$(this).text()-1]);      
   });     

   var previousPoint = null;
   $("#userFlot, #gameFlot, #betsFlot").bind("plothover", function (event, pos, item) {
      if (item) {
         if(previousPoint != item.dataIndex) {
            previousPoint = item.dataIndex;
            $("#tooltip").remove();
            var x = item.datapoint[0], y = item.datapoint[1], z = item.series.color;
            var m = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
            showTooltip(item.pageX, item.pageY, m[x-1] + " = " + y, z);
         }
      } else {
         $("#tooltip").remove();
         previousPoint = null;
      }
   });

   function showTooltip(x, y, contents, z) {
      $('<div id="tooltip">' + contents + '</div>').css({
         position: 'absolute',
         display: 'none',
         top: y + 5,
         left: x + 5,
         'z-index': '9999',
         'color': '#fff',
         'font-size': '11px',
         opacity: 0.8,
         'border-color': z,
      }).appendTo("body").fadeIn(200);
   }
</script>
