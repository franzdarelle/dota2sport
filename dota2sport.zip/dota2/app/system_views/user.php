<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side', ['data'=>$STEAM,'user'=>$USERS,'page'=>arg(3)]) ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>USER</h2>
            <p>BART GAMERS</p>
         </div>
         <div id="main-content">
            <div class="box dark">
               <div class="header"><h4>Users</h4></div>
               <div class="content" id="nopad">
                  <table class="table normal bt-dataTable dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th>STEAMID</th>
                           <th>PERSONA</th>
                           <th>STARTED</th>
                           <th class="fixed">ITEMS</th>
                           <th class="fixed">PRICE</th>
                           <th class="fixed">BETS</th>
                           <th class="fixed">WINS</th>
                           <th class="fixed">LOST</th>
                           <th class="fixed">WIN %</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php 
                        $USERS = $STEAM->getUsers();
                        if($USERS):
                           foreach ($USERS as $d):
                              $steam = $d['steam'];
                              $persona = stripslashes($d['persona']); 
                              $BETS = $STEAM->getUserStakes($steam);
                              $ITEMS =  $STEAM->getUserItems($steam);                                         
                              $wins = $lost = $bets = $items = $price = 0;
                              if($BETS) {
                                 foreach ($BETS as $bet) {
                                    if(($bet['game']['status']==3) AND $bet['game']['winner']) {
                                       if($bet['game']['winner']==$bet['team']) $wins++; else $lost++;
                                       $bets++;
                                    }
                                 }
                              } 
                              if($ITEMS) {
                                 foreach ($ITEMS as $item) {
                                    $price += $STEAM->getDota2($item['classid'], "price");
                                    $items ++;
                                 }
                              }                         
                     ?>
                        <tr class="gradeX">
                           <td><?php print $steam ?></td>
                           <td><?php print $persona ?></td>
                           <td class="dates"><?php print date("Y-m-d h:i A", strtotime($d['stamp'])) ?></td>
                           <td class="text-align-right<?php print $items? ' items' : '' ?>" steam="<?php print $steam ?>"><?php print $items ?></td>
                           <td class="text-align-right"><?php print '$' . number_format($price, 2) ?></td>
                           <td class="text-align-right"><?php print $bets ?></td>
                           <td class="text-align-right"><?php print $wins ?></td>
                           <td class="text-align-right"><?php print $lost ?></td>
                           <td class="text-align-right"><?php print $wins? number_format((($wins / $bets) * 100), 2) : 0 ?>%</td>
                        </tr>
                     <?php endforeach; endif ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="clear"></div>
      </div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $(".fixed").css({"width":45});
   $(".dates").css({"width":125});
   $(".items").addClass("pointer").click(function(){
      persona = $(this).siblings().next().html();
      $.ajax({
         url:BASEURL + "ajax.php?q=dota/getUserItems",
         type:"POST",
         data:{d:$(this).attr('steam')},
         dataType:"html"
      }).done(function(items){
         var content = $("<div></div>").html(items);
         content.find(".inventoryItems").each(function(){
            $(this).tooltip();
         });
         popup_box({title:persona, content:content, width:480, height:400});
      });
   });
});
</script>