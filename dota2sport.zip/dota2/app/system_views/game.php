<div class="container bg">
   <div class="row">
      <div class="span3">
         <?php print getViewsContents('side', ['data'=>$data,'user'=>$user,'page'=>arg(3)]) ?>
         <?php print getViewsContents('ticker', $data) ?>
      </div>
      <div class="span9">
         <div class="pagetitle">
            <h2>GAME</h2>
            <p>GAME MANAGEMENT</p>
         </div>
         <div id="main-content">
            <?php if(isset($_SESSION[$data->string])) { print messageBox($_SESSION[$data->string]); unset($_SESSION[$data->string]); } ?>
            <div class="box dark">
               <div class="header">
                  <h4>Games</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Game"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="game/get"><a href="#" data-original-title="Edit Game"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="game/del" hl="<?php echo $link; ?>"><a href="#" data-original-title="Delete Game"><i class="icon-remove"></i>Delete</a></li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="table normal bt-dataTable dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>   
                           <th>DATE</th>
                           <th>SPORT</th>
                           <th>EVENT</th>
                           <th>TEAM1</th>
                           <th>TEAM2</th>
                           <th>GAME</th>
                           <th>STATUS</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php 
                        $GAMES = $data->getAllGames();
                        if($GAMES):
                           foreach ($GAMES as $d): 
                              switch ($d['status']) {
                                 case 3:
                                    if($d['winner']) {
                                       if($d['winner']==$d['team1']['id']) $tool = $d['team1']['alias'];
                                       else {
                                          $tool = $d['team2']['alias'];
                                       }
                                    } else
                                       $tool = "Draw";
                                    $span = ['span'=>'label-success','text'=>'Success','tool'=>$tool];
                                 break;
                                 case 2:
                                 case 4:
                                    $span = ['span'=>'label-important','text'=> (($d['status']==2)? 'Postponed' : 'Cancelled')];
                                 break;
                                 case 1:
                                    $span = ['span'=>'label-warning','text'=>'Ongoing'];
                                 break;              
                                 default:
                                    $span = ['span'=>'label-waiting','text'=>'Waiting'];
                                 break;
                              }
                     ?>
                        <tr class="gradeX">
                           <td class="tal"><label class="checkbox inline"><input type="checkbox" class="checkbox-uniform" value="<?php print $d['id'] ?>"></label></td>
                           <td><?php print date("Y/m/d h:iA", strtotime($d['dates'])) ?></td>
                           <td><?php print stripslashes($d['sport']['name']) ?></td>
                           <td><?php print stripslashes($d['event']['name']) ?></td>
                           <td><span class="logo" path="<?php echo BASEURL ?>upl/team/<?php print $d['team1']['logo'] ?>"><?php print stripslashes($d['team1']['name']) ?></span></td>
                           <td><span class="logo" path="<?php echo BASEURL ?>upl/team/<?php print $d['team2']['logo'] ?>"><?php print stripslashes($d['team2']['name']) ?></span></td>
                           <td><span class="label label-info">Best of <?php print stripslashes($d['games']) ?></span></td>
                           <td class="view" game="<?php print $d['id'] ?>"><span class="label <?php echo $span['span'] ?>" data-original-title="<?php echo @$span['tool'] ?>"><?php echo $span['text'] ?></span></td>
                        </tr>
                     <?php endforeach; endif ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="clear"></div>
      </div>
   </div>
</div>
<?php 
   $randAdd = random_string(5);
   $randUps = random_string(5);
   $attrAdd = array(
      'name' => 'add_game',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randAdd
   );
   $attrUps = array(
      'name' => 'ups_game',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randUps
   );
   $addform = $form->startForm("game/add", "post", "add_game", $attrAdd).$form->endForm();
   $upsform = $form->startForm("game/ups", "post", "ups_game", $attrUps).$form->endForm(); 
?>
<div class="add">
   <div class="rowelement pop">
      <div class="span3"><strong>SPORT</strong></div>
      <div class="span3"><select class="input-large sidAdd <?php echo $randAdd ?>" name="sid"></select></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>EVENT</strong></div>
      <div class="span3"><select class="input-large eidAdd <?php echo $randAdd ?>" name="eid"></select></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TIME & DATE</strong></div>
      <div class="span3">
         <div class="input-append date" id="datepickerAdd" data-date="<?php echo date("d-m-Y") ?>" data-date-format="dd-mm-yyyy">
            <div class="control-group">
               <div class="controls">
                  <div class="input-append">
                     <input type="text" class="input-small textCenter <?php echo $randAdd ?>" name="date">
                     <span class="add-on margin-fix"><i class="icon-th"></i></span>
                  </div>
               </div>
            </div>
         </div>
         <div class="timepicker">
            <input class="input-mini timepicker-toggle textCenter <?php echo $randAdd ?>" data-toggle="timepicker" readonly="" type="text" name="time">
            <div class="timepicker-popover">
               <table class="timepicker-table table">
                  <tbody>
                     <tr>
                        <td class="hour">
                           <a class="next" href="#"><i class="icon-chevron-up"></i></a><br><input class="input-mini" readonly="" type="text"><br>
                           <a class="previous" href="#"><i class="icon-chevron-down"></i></a>
                        </td>
                        <td class="separator">:</td>
                        <td class="minute">
                           <a class="next" href="#"><i class="icon-chevron-up"></i></a><br><input class="input-mini" readonly="" type="text"><br>
                           <a class="previous" href="#"><i class="icon-chevron-down"></i></a>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TEAM1</strong></div>
      <div class="span3">
         <select class="input-large st1Add <?php echo $randAdd ?>" name="team1"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TEAM2</strong></div>
      <div class="span3">
         <select class="input-large st2Add <?php echo $randAdd ?>" name="team2"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>GAMES</strong></div>
      <div class="span3">
         <select class="input-large <?php echo $randAdd ?>" name="games"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>STREAM</strong></div>
      <div class="span3">
         <textarea class="input-large" name="stream"></textarea>
      </div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
   <input class="input-large <?php echo $randUps ?>" type="hidden" name="id"/>
   <div class="rowelement pop">
      <div class="span3"><strong>SPORT</strong></div>
      <div class="span3">
         <select class="input-large sidUps <?php echo $randUps ?>" name="sid"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>EVENT</strong></div>
      <div class="span3">
         <select class="input-large eidUps <?php echo $randUps ?>" name="eid"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TIME & DATE</strong></div>
      <div class="span3">
         <div class="input-append date" id="datepickerUps" data-date="<?php echo date("d-m-Y") ?>" data-date-format="dd-mm-yyyy">
            <div class="control-group">
               <div class="controls">
                  <div class="input-append">
                     <input type="text" class="input-small textCenter <?php echo $randUps ?>" name="date">
                     <span class="add-on margin-fix"><i class="icon-th"></i></span>
                  </div>
               </div>
            </div>
         </div>
         <div class="timepicker">
            <input class="input-mini timepicker-toggle textCenter <?php echo $randUps ?>" data-toggle="timepicker" readonly="" type="text" name="time">
            <div class="timepicker-popover">
               <table class="timepicker-table table">
                  <tbody>
                     <tr>
                        <td class="hour">
                           <a class="next" href="#"><i class="icon-chevron-up"></i></a><br><input class="input-mini" readonly="" type="text" name="hour"><br>
                           <a class="previous" href="#"><i class="icon-chevron-down"></i></a>
                        </td>
                        <td class="separator">:</td>
                        <td class="minute">
                           <a class="next" href="#"><i class="icon-chevron-up"></i></a><br><input class="input-mini" readonly="" type="text" name="mins"><br>
                           <a class="previous" href="#"><i class="icon-chevron-down"></i></a>
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TEAM1</strong></div>
      <div class="span3">
         <select class="input-large st1Ups <?php echo $randUps ?>" name="team1"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>TEAM2</strong></div>
      <div class="span3">
         <select class="input-large st2Ups <?php echo $randUps ?>" name="team2"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>GAMES</strong></div>
      <div class="span3">
         <select class="input-large gmsUps <?php echo $randUps ?>" name="games"></select>
      </div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>STREAM</strong></div>
      <div class="span3">
         <textarea class="input-large" name="stream"></textarea>
      </div>
      <div class="clear"></div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $("#datepickerAdd, #datepickerUps").datepicker();
   $("#ref").click(function(){Redirect('<?php echo $link ?>')});
   $("div.checker").css({"margin-left":0,"margin-right":0,"padding":0});
   $("div.timepicker").css({"float":"left","margin-right":10});
   $(".controls").css({"margin":0});
   $(".control-group").css({"margin":0});
   $(".dropdown-menu").css({"z-index":1001});
   $(".textCenter").css({"text-align":"center"});
   $('.pop').css({"padding":0});
   $(".add, .ups").css({"overflow":"hidden"});
   $(".label-success, .label-important, .label-warning, .label-waiting").attr('data-placement','right').tooltip();
   $("#add").add('<?php print $addform ?>', 'Add Game', $("div.add"), 300, true, 'bart', 
      function() {
         var sid = $(".sidAdd").change(function(){
            var sid = $(this).val();
            setOptions(".eidAdd", "game/evt", sid).always(function(){$(".eidAdd").chosenDestroy().outerWidth(223).chosen()});
            setOptions(".st1Add", "game/tms", sid).always(function(){$(".st1Add").chosenDestroy().outerWidth(223).chosen()});
            setOptions(".st2Add", "game/tms", sid).always(function(){$(".st2Add").chosenDestroy().outerWidth(223).chosen()});
            setHeights();
         }).val();
         setOptions(".eidAdd", "game/evt", sid).always(function(){$(".eidAdd").outerWidth(210).chosen()});
         setOptions(".st1Add", "game/tms", sid).always(function(){$(".st1Add").outerWidth(210).chosen()});
         setOptions(".st2Add", "game/tms", sid).always(function(){$(".st2Add").outerWidth(210).chosen()});
         setHeights();
      }
   , 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $("#ups").ups('<?php print $upsform ?>', 'Edit Game', $("div.ups"), 300, true, 'dogz', 
      function(obj) {
         $("div.ups").find('textarea').each(function(){$(this).html(obj[$(this).attr('name')])});
         $(".sidUps").change(function(){
            var sid = $(this).val();
            setOptions(".eidUps", "game/evt", sid).always(function(){$(".eidUps").chosenDestroy().outerWidth(223).chosen()});
            setOptions(".st1Ups", "game/tms", sid).always(function(){$(".st1Ups").chosenDestroy().outerWidth(223).chosen()});
            setOptions(".st2Ups", "game/tms", sid).always(function(){$(".st2Ups").chosenDestroy().outerWidth(223).chosen()});
            setHeights();
         });
         var sid = obj['sport']['id'];
         var evt = obj['event']['id'];
         var tm1 = obj['team1']['id'];
         var tm2 = obj['team2']['id'];
         setSelected($(".sidUps"), sid);
         setSelected($(".gmsUps"), obj['games']);
         $.when(
            $.ajax({url:BASEURL + "ajax.php?q=game/evt", type:"POST", data:{d:sid}, dataType:"html"}), 
            $.ajax({url:BASEURL + "ajax.php?q=game/tms", type:"POST", data:{d:sid}, dataType:"html"}),
            $.ajax({url:BASEURL + "ajax.php?q=game/tms", type:"POST", data:{d:sid}, dataType:"html"})
         ).done(function(events, teams1, teams2) {
               if(events[1]=="success") {
                  var select = $(".eidUps").empty().outerWidth(210);
                  $.each($.parseJSON(events[0]), function(index,value){select.append($("<option></option>").val(value['id']).append(value['name']))});
                  setSelected(select, evt).chosenDestroy().chosen();
               }
               if(teams1[1]=="success") {
                  var select = $(".st1Ups").empty().outerWidth(210);
                  $.each($.parseJSON(teams1[0]), function(index,value){select.append($("<option></option>").val(value['id']).append(value['name']))});
                  setSelected(select, tm1).chosenDestroy().chosen();
               }
               if(teams2[1]=="success") {
                  var select = $(".st2Ups").empty().outerWidth(210);
                  $.each($.parseJSON(teams2[0]), function(index,value){select.append($("<option></option>").val(value['id']).append(value['name']))});
                  setSelected(select, tm2).chosenDestroy().chosen();
               }
         }).then(setHeights());
      }
   , 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');    
   $("#all").all($('span.all'));
   $("#del").del();
   $(".logo").img();
   $(".view").addClass("pointer").click(function(){Redirect('<?php echo str_replace("game", "view", $link) ?>/' + $(this).attr("game"))});
   setOptions(".sidAdd", "game/spt", 1);
   setOptions(".sidUps", "game/spt", 1);
   setOptions("select[name=games]", "game/gms", 1);
   function setOptions(input, param, datum) {
      var select = $(input).empty();
      return $.ajax({url:BASEURL + "ajax.php?q=" + param, type:"POST", data:{d:datum}, dataType:"html"}).done(function(e){
         var obj = $.parseJSON(e);
         $.each(obj, function(index,value){select.append($("<option></option>").val(value['id']).append(value['name']))});
      });
   }
   function setSelected(obj,val){
      obj.find('option').each(function(){if($(this).attr('value')==val) $(this).attr('selected','selected')});
      return obj;
   }
   function setHeights(){setTimeout(function(){$(".chzn-container .chzn-results").css({"max-height":100})}, 500)} 
});

$.fn.chosenDestroy = function(){
   $(this).show().removeClass('chzn-done')
   $(this).next().remove()
   return $(this);
}
</script>
