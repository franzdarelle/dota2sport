<div class="container bg">
   <div class="row">
      <div class="span3"><?php print getViewsContents('side', ['data'=>$data,'user'=>$user,'page'=>arg(3)]) ?></div>
      <div class="span9">
         <div class="pagetitle">
            <h2>BOTS</h2>
            <p>BOTS MANAGEMENT</p>
         </div>
         <div id="main-content">
            <?php if(isset($_SESSION[$data->string])) { print messageBox($_SESSION[$data->string]); unset($_SESSION[$data->string]); } ?>
            <div class="box dark">
               <div class="header">
                  <h4>Bots</h4>
                  <div class="box-control pull-right">
                     <a class="btn dropdown-toggle" data-toggle="dropdown" href="#" data-original-title="Actions"><i class="icon-cog"></i></a>
                     <ul class="dropdown-menu">
                        <li id="add"><a href="#" data-original-title="Add Bot"><i class="icon-plus"></i>Add</a></li>
                        <li id="ups" ca="checkbox-uniform" ax="bot/get"><a href="#" data-original-title="Edit Bot"><i class="icon-edit"></i>Edit</a></li>
                        <li id="del" ca="checkbox-uniform" ax="bot/del" hl="<?php echo $link ?>"><a href="#" data-original-title="Delete Bot"><i class="icon-remove"></i>Delete</a></li>
                        <li class="act" ca="checkbox-uniform" ax="bot/act" hl="<?php echo $link ?>" at="activate"><a href="#" data-original-title="Activate Bot"><i class="icon-ok-circle"></i>Activate</a></li>
                        <li class="act" ca="checkbox-uniform" ax="bot/dea" hl="<?php echo $link ?>" at="deactivate"><a href="#" data-original-title="Deactivate Bot"><i class="icon-ban-circle"></i>Deactivate</a></li>
                        <li id="all" ca="checkbox-uniform"><a href="#" data-original-title="Check All"><i class="icon-list"></i><span class="all">Check All</span></a></li>
                        <li id="ref"><a href="#" data-original-title="Refresh"><i class="icon-refresh"></i>Refresh</a></li>
                     </ul>
                  </div>
               </div>
               <div class="content" id="nopad">
                  <table class="table normal bt-dataTable dataTable" border="0" cellpadding="0" cellspacing="0" width="100%" id="dataTable">
                     <thead>
                        <tr>
                           <th class="chk">&nbsp;</th>
                           <th>USERNAME</th>
                           <th>PASSWORD</th>
                           <th>PERSONA</th>
                           <th>APIKEY</th>
                           <th style="width:60px">STATUS</th>
                        </tr>
                     </thead>
                     <tbody>
                     <?php 
                        $BOTS = $data->getBots();
                        if($BOTS):
                           foreach ($BOTS as $b):
                     ?>
                        <tr class="gradeX">
                           <td class="tal"><label class="checkbox inline"><input type="checkbox" class="checkbox-uniform" value="<?php print $b['id'] ?>"></label></td>
                           <td><?php print $b['username'] ?></td>
                           <td><?php print $b['password'] ?></td>
                           <td><?php print $b['persona'] ?></td>
                           <td><?php print $b['apikey'] ?></td>
                           <td align="center"><?php if($b['status']): ?><span class="label label-success pointer"><i class="icon-ok-sign"></i>Trading</span><?php else: ?><span class="label pointer"><i class="icon-remove-sign"></i>Banned</span><?php endif ?></td>
                        </tr>
                     <?php endforeach; endif ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="clear"></div>
      </div>
   </div>
</div>
<?php 
   $randAdd = random_string(5);
   $randUps = random_string(5);
   $attrAdd = array(
      'name' => 'add_bot',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randAdd
   );
   $attrUps = array(
      'name' => 'ups_bot',
      'class' => 'form-horizontal system',
      'location' => $link,
      'filter' => $randUps
   );
   $addform = $form->startForm("bot/add", "post", "add_bot", $attrAdd).$form->endForm(); 
   $upsform = $form->startForm("bot/ups", "post", "ups_bot", $attrUps).$form->endForm(); 
?>
<div class="add">
   <div class="rowelement pop">
      <div class="span3"><strong>USERNAME</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="username"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>PASSWORD</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="password"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>PERSONA</strong></div>
      <div class="span3"><input class="input-large <?php echo $randAdd ?>" type="text" name="persona"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>APIKEY</strong></div>
      <div class="span3"><textarea class="input-large <?php echo $randAdd ?>" name="apikey"></textarea></div>
      <div class="clear"></div>
   </div>
</div>
<div class="ups">
   <input class="input-large <?php echo $randUps ?>" type="hidden" name="id"/>
   <div class="rowelement pop">
      <div class="span3"><strong>USERNAME</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="username"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>PASSWORD</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="password"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>PERSONA</strong></div>
      <div class="span3"><input class="input-large <?php echo $randUps ?>" type="text" name="persona"/></div>
      <div class="clear"></div>
   </div>
   <div class="rowelement pop">
      <div class="span3"><strong>APIKEY</strong></div>
      <div class="span3"><textarea class="input-large <?php echo $randUps ?>" name="apikey"></textarea></div>
      <div class="clear"></div>
   </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
   $("div.checker").css({"margin-left":0,"margin-right":0,"padding":0});
   $("#ref").click(function(){Redirect('<?php echo $link ?>')});
   $('.pop').css({"padding":0});
   $(".add, .ups").css({"overflow":"hidden"});
   $("#add").add('<?php print $addform ?>', 'Add Bot', $("div.add"), 300, true, 'bart', true, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $("#ups").ups('<?php print $upsform ?>', 'Edit Bot', $("div.ups"), 300, true, 'dogz', function(obj) {$("div.ups").find('textarea').each(function(){$(this).html(obj[$(this).attr('name')])})}, 'save', 'save', 'btn btn-primary', 'Save', 'Cancel');
   $("#all").all($('span.all'));
   $("#del").del();
   $('.act').act();
   $("span.label").click(function(){
      $(location).attr("href", "<?php print generateUrl(str_replace('bot','log', $link)) ?>/" + $(this).parents("td").siblings().first().find("input").val());
   });
});
</script>
