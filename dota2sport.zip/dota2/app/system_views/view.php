<div class="container bg">
	<div class="row">
		<div class="span3"><?php print getViewsContents('side', ['data'=>$data,'user'=>$user,'page'=>arg(3)]) ?></div>
		<div class="span9">
        	<div class="pagetitle">
            	<h2>MATCH</h2>
            	<p><?php print stripslashes(strtoupper($game['team1']['name']) . ' vs ' . strtoupper($game['team2']['name']) . ' &#183; ' . $game['event']['name']) ?></p>
         	</div>
         	<div id="main-content">         		
         		<div class="row-fluid grid-set">
         			<div class="span6">
						<div class="box dark">
							<div class="header">
								<h4><?php echo stripslashes($game['event']['name']) ?></h4>
								<div class="matchTime"></div>
							</div>
							<div class="content pad">
								<div class="span4 teams" teamid="<?php echo $game['team1']['id'] ?>">
									<div class="content pad center">
										<img src="<?php echo BASEURL . 'upl/team/' . $game['team1']['logo'] ?>" class="pix">
									</div>
									<div class="header center">
										<h4 class="nobottomborder"><?php echo stripslashes($game['team1']['alias']) ?></h4>
									</div>
								</div>
								<div class="span4">
									<div class="header center">
										<h4 class="nobottomborder">
											<span class="score1"><?php echo $game['score1'] ?></span>
											<span class="score2"><?php echo $game['score2'] ?></span>
											<span>vs</span>
										</h4>
									</div>
									<div class="content pad center">
										<span class="label label-info">Best of <?php echo $game['games'] ?></span>
									</div>
									<div class="header center">
										<h4 class="nobottomborder">
											<span class="odds1"></span>
											<span class="odds2"></span>
										</h4>
									</div>
								</div>
								<div class="span4 teams" teamid="<?php echo $game['team2']['id'] ?>">
									<div class="content pad center">
										<img src="<?php echo BASEURL . 'upl/team/' . $game['team2']['logo'] ?>" class="pix">
									</div>
									<div class="header center">
										<h4 class="nobottomborder"><?php echo stripslashes($game['team2']['alias']) ?></h4>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="span6 label" id="placedItems"></div>
					<div class="span6">
						<div class="box dark">
	            			<div class="tabbed tabs2 padding-reset">
	            				<div class="header">
	            					<ul>
	            						<li><a href="#status">Status</a></li>
	            						<li><a href="#scores">Scores</a></li>
	            						<li><a href="#winner">Winner</a></li>
	            						<li><a href="#reward">Reward</a></li>
	            					</ul>
	            				</div>
		            			<div class="content">		            			
		            				<div class="tabs2">
		            				 	<div id="status">		            				 		 
											<div>
												<select class="chzn-select input-large">
													<option value="0" <?php if($game['status']==0) print "SELECTED" ?>>WAITING</option>
													<option value="1" <?php if($game['status']==1) print "SELECTED" ?>>ONGOING</option>
													<option value="2" <?php if($game['status']==2) print "SELECTED" ?>>POSTPONED</option>
													<option value="3" <?php if($game['status']==3) print "SELECTED" ?>>GAME OVER</option>
													<option value="4" <?php if($game['status']==4) print "SELECTED" ?>>CANCELLED</option>
												</select>
											</div>
											<div>
												<button class="btn btn-primary" type="button" id="setgamestatus">Save</button>
											</div>
		            				 	</div>
		            				 	<div id="scores">		            			 
											<?php
												$scores = empty($game['scores'])? array() : explode(", ", $game['scores']);
												for ($i=1; $i <= $game['games']; $i++):
													if(isset($scores[$i-1])) {	
														$selected1 = ($game['team1']['id']==$scores[$i-1])? "SELECTED" : "";
														$selected2 = ($game['team2']['id']==$scores[$i-1])? "SELECTED" : "";
													} else
														$selected1 = $selected2 = "";
											?>
											<div>
												<select class="chzn-select input-large">
													<option value="">GAME <?php print $i ?></option>
													<option value="<?php print $game['team1']['id'] ?>" <?php print $selected1 ?>><?php print $game['team1']['alias'] ?></option>
													<option value="<?php print $game['team2']['id'] ?>" <?php print $selected2 ?>><?php print $game['team2']['alias'] ?></option>
							                    </select>
											</div>
											<?php endfor ?>
											<div>
												<button class="btn btn-primary" type="button" id="setgamescores">Save</button>
											</div>
		            				 	</div>
		            				 	<div id="winner">
		            				 		<?php									 
												$selected1 = ($game['team1']['id']==$game['winner'])? "SELECTED" : "";
												$selected2 = ($game['team2']['id']==$game['winner'])? "SELECTED" : "";
											?>
											<div>
												<select class="chzn-select input-large">
													<option value="0">DRAW</option>
													<option value="<?php print $game['team1']['id'] ?>" <?php print $selected1 ?>><?php print $game['team1']['alias'] ?></option>
													<option value="<?php print $game['team2']['id'] ?>" <?php print $selected2 ?>><?php print $game['team2']['alias'] ?></option>
												</select>
											</div>
											<div>
												<button class="btn btn-primary" type="button" id="setgamewinner">Save</button>
											</div>
		            				 	</div>
		            				 	<div id="reward">
		            				 		<div>
		            				 			<button class="btn btn-primary" type="button" id="computereward">Compute</button>
		            				 		</div>
		            				 	</div>
		            				 </div>
		            			</div>
	            			</div>
	            		</div>
					</div>
	            	<div class="clear"></div>
         		</div>
         		<div class="row-fluid grid-set" id="liveStreams"><?php print $game['stream'] ?></div>
         	</div>
        </div>
	</div>
</div>
<script type="text/javascript">
var GAMERS = new SelectorCache(), 
	GAMEID = <?php print $game['id'] ?>, 
	STREAM = GAMERS.get("#liveStreams").hide();

$(document).ready(function(){	

	GAMERS.get("#placedItems").hide();
	var rewardTab = GAMERS.get("a[href='#reward']").hide(), updateOdds = true;
	if((GAMERS.get("div#winner").find("select").val()>0) && GAMERS.get("div#status").find("select").val()!=3) rewardTab.show();

	setTime();
	setOdds();
	setScores();

	function setTime() {
		$.ajax({
            url:BASEURL + "ajax.php?q=game/getGameTime", 
            type:"POST", 
            data:{d:GAMEID}, 
            cache:true,
            dataType:"html"
        }).done(function(e){
        	GAMERS.get("div.matchTime").html(e);
        }).always(setTimeout(setTime, 30000));
	}

	function setOdds() {
		if(updateOdds) {
			$.ajax({
				url:BASEURL + "ajax.php?q=dota/getGameOdds",
				type:"POST",
				data:{d:GAMEID},
				cache:true,
				dataType:"html"
	       	}).done(function(e){
	       		var odds = $.parseJSON(e);
                        var vals = parseFloat(odds.val1) + parseFloat(odds.val2);
	       		GAMERS.get(".odds1").text(odds.odd1+"%").attr("amount", odds.val1);
	       		GAMERS.get(".odds2").text(odds.odd2+"%").attr("amount", odds.val2);
	       		GAMERS.get("#placedItems").html(odds.user+" people placed "+odds.item+" items ($"+vals.toFixed(2)+")");
	       		if(odds.user>1) {
       				GAMERS.get("#placedItems").css({"margin-bottom":10}).show();
       			} else {
       				GAMERS.get("#placedItems").css({"margin-bottom":0}).hide();
       			}   	
	    	}).always(setTimeout(setOdds, 10000));	
		}
	}

	function setScores() {
		$.ajax({
			url:BASEURL + "ajax.php?q=game/get",
			type:"POST",
			data:{d:GAMEID},
			cache:true,
			dataType:"html"
       	}).done(function(e){
        	var d = $.parseJSON(e);
        	var w = $('<img></img>', {class:"winner"}).attr('src', BASEURL + 'img/check.png');
        	GAMERS.get("span.score1").text(d.score1);
        	GAMERS.get("span.score2").text(d.score2);
        	$("div.highlightedTeam").removeClass("highlightedTeam");
        	$("img.winner").remove();
        	switch(parseInt(d.status)) {
        		case 0:
        			STREAM.hide();
        		break;
        		case 1:
        			STREAM.fadeIn();
        			updateOdds = false;
        		break;
        		case 2:
        			STREAM.hide();
    				updateOdds = false;
        		break;
    			case 4:
    				STREAM.remove();
    				updateOdds = false;
    			break;
    			case 3:
    				STREAM.remove();
    				updateOdds = false;
    				switch (d.winner) {
						case d.team1.id:
		        			GAMERS.get("div[teamid='"+d.team1.id+"']").addClass("highlightedTeam").find("div.content").append(w);		        			
						break;
						case d.team2.id:
							GAMERS.get("div[teamid='"+d.team2.id+"']").addClass("highlightedTeam").find("div.content").append(w);
						break;
						default:
							GAMERS.get("div.teams").addClass("highlightedTeam");
						break;
					}
    			break;
        	}
        });
    }

	$("#setgamestatus").click(function(){
		var status = GAMERS.get("div#status").find("select").val();		
		var odd1 = GAMERS.get(".odds1").text().replace("%",""); 
		var odd2 = GAMERS.get(".odds2").text().replace("%","");
		var val1 = GAMERS.get(".odds1").attr('amount');
		var val2 = GAMERS.get(".odds2").attr('amount');
		$.ajax({
			url:BASEURL + "ajax.php?q=game/setGameStatus",
			type:"POST",
			data:{gameid:GAMEID, status:status, odd1:odd1, odd2:odd2, val1:val1, val2:val2},
			cache:true,
			dataType:"html"
       	}).done(function(e){
       		popup_box({content:e});
       		if(status==0) rewardTab.fadeOut();
       	}).always(setScores);
	});

	$("#setgamescores").click(function(){
		var scores = new Array;
		GAMERS.get("div#scores select").each(function(){
			scores.push($(this).val());
		});
		$.ajax({
			url:BASEURL + "ajax.php?q=game/setGameScores",
			type:"POST",
			data:{gameid:GAMEID, scores:scores},
			cache:true,
			dataType:"html"
       	}).done(function(e){
       		popup_box({content:e});
       	}).always(setScores);
	});

	$("#setgamewinner").click(function(){
		var winner = GAMERS.get("div#winner").find("select").val();
		var status = GAMERS.get("div#status").find("select").val();
		$.ajax({
			url:BASEURL + "ajax.php?q=game/setGameWinner",
			type:"POST",
			data:{gameid:GAMEID, winner:winner, status:status},
			cache:true,
			dataType:"html"
       	}).done(function(e){
       		popup_box({content:e});
       		if(winner>0) rewardTab.fadeIn();
       		else rewardTab.fadeOut();
       	}).always(setScores);
	});

	$("#computereward").click(function(){
		$(this).unbind("click").removeClass("btn-primary");
		$.ajax({
			url:BASEURL + "ajax.php?q=dota/computeRewards",
			type:"POST",
			data:{d:GAMEID},
			cache:true,
			dataType:"html"
       	}).done(function(e){
       		popup_box({content:e});
       		rewardTab.fadeOut(1000, function(){
       			$("a[href='#status']").click();
       		});
       	});
	});
});
</script>