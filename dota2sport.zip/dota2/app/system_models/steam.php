<?php
class STEAM extends TABLE {

    private static $self;

    var $string = 'message';

	function __construct() {
		parent::__construct();
        $timezone = date("P");
        $this->PDO->query("SET SESSION time_zone = '{$timezone}'");
    }

    public static function getInstance() {
        if(is_null(self::$self)) self::$self = new self;
        return self::$self;
    }

    public function addSport($logo, $name, $sort, $status=1) {
        $this->setTable("sport");
    	$this->logo = $logo;
    	$this->name = $name;
    	$this->sort = $sort;
    	$this->status = $status;
    	return $this->create();
    }

    public function editSport($logo, $name, $sort, $id) {
        $this->setTable("sport");
        $this->id = $id;
        $this->logo = $logo;
        $this->name = $name;
        $this->sort = $sort;
        return $this->update();
    }

    public function editSportStatus($id, $status=1) {
        $this->setTable("sport");
    	$this->id = $id;
    	$this->status = $status;
    	return $this->update();
    }

    public function getSport($id) {
        $this->setTable("sport");
        $data = $this->select(array('*'), array(array('id','=', $id)));
        return $data[0];
    }

    public function getSports() {
        $this->setTable("sport");
        return $this->select(array('*'));
    }

    public function getSportIDs() {
        $this->setTable("sport");
        $sports = $this->select(array('id'));
        foreach ($sports as $s) $IDs[] = $s['id'];
        return $IDs;
    }

    public function getActiveSports() {
        $this->setTable("sport");
        $this->setOrder(array(array('sort')));
        return $this->select(array('*'), array(array('status','=',1)));
    }

    public function deleteSport($id) {
        $this->setTable("sport");
    	$this->id = $id;
    	return $this->delete();
    }

    public function validateSportID($id) {
    	$sportsIDs = $this->getSportIDs();
    	if(empty($id)) return $sportsIDs[0];
		else {
			$id = trim($id);
			if(is_numeric($id) AND in_array($id, $sportsIDs)) return $id;
			else {
				return $sportsIDs[0];
			}
		}
    }

    public function addEvent($sid, $name) {
        $this->setTable("event");
        $this->sid = $sid;
        $this->name = $name;
        return $this->create();
    }

    public function editEvent($sid, $name, $id) {
        $this->setTable("event");
        $this->id = $id;
        $this->sid = $sid;
        $this->name = $name;
        return $this->update();
    }

    public function getEvent($id) {
    	$this->setTable("event");
    	$event = $this->select(array('*'), array(array('id','=',$id)));
    	return $event[0];
    }

    public function getEvents() {
    	$this->setTable("event");
        $this->setOrder(array(array('sid'),array('name')));
    	return $this->select(array('*'));
    }

    public function getEventsBySid($sid) {
    	$this->setTable("event");
    	$events = $this->select(array('id','name'), array(array('sid','=',$sid)));
    	foreach ($events as $key => $value) {
    		$data[] = array('id' => $value['id'], 'name' => $value['name']);
    	}
    	return $data;
    }

    public function getEventIDs($sid) {
        $this->setTable("event");
        $events = $this->select(array('id'), array(array('sid','=',$sid)));
        foreach ($events as $e) $IDs[] = $e['id'];
        return $IDs;
    }

    public function deleteEvent($id) {
    	$this->setTable("event");
    	$this->id = $id;
    	return $this->delete();
    }

    public function validateEventID($eid, $sid) {
        $eventsIDs = $this->getEventIDs($sid);
        if(empty($eid)) return $eventsIDs[0];
        else {
            $eid = trim($eid);
            if(is_numeric($eid) AND in_array($eid, $eventsIDs)) return $eid;
            else {
                return $eventsIDs[0];
            }  
        }
    }

    public function getBots() {
        $this->setTable("bot");
        $this->setOrder(array(array('id')));
        return $this->select(array('*'));
    }

    public function getBot($id) {
        $this->setTable("bot");
        $bot = $this->select(array('*'), array(array('id', '=', $id)));
        return $bot[0];
    }

    public function getBotID($apikey) {
        $this->setTable("bot");
        $bot = $this->select(array('id'), array(array('apikey', '=', $apikey)));
        return $bot[0]['id'];
    }

    public function getBotPersona($id) {
        $this->setTable("bot");
        $bot = $this->select(array('persona'), array(array('id', '=', $id)));
        return $bot[0]['persona'];
    }

    public function getBotSteam($id) {
        $this->setTable("bot");
        $bot = $this->select(array('steam'), array(array('id', '=', $id)));
        return $bot[0]['steam'];
    }

    public function getBotApikey($id) {
        $this->setTable("bot");
        $bot = $this->select(array('apikey'), array(array('id', '=', $id)));
        return $bot[0]['apikey'];
    }

    public function addBot($username, $password, $persona, $apikey) {
        $this->setTable("bot");
        $this->username = $username;
        $this->password = $password;
        $this->persona = $persona;
        $this->apikey = $apikey;
        return $this->create();
    }

    public function editBot($username, $password, $persona, $apikey, $id) {
        $this->setTable("bot");
        $this->id = $id;
        $this->username = $username;
        $this->password = $password;
        $this->persona = $persona;
        $this->apikey = $apikey;
        return $this->update();
    }

    public function deleteBot($id) {
        $this->setTable("bot");
        $this->id = $id;
        return $this->delete();
    }

    public function setBotStatus($id, $status=1) {
        $this->setTable("bot");
        $this->id = $id;
        $this->status = $status;
        return $this->update();
    }

    public function setBotSteam($steam, $oauth, $username, $password) {
        return $this->PDO->query("UPDATE bot SET steam = '{$steam}', oauth = '{$oauth}' WHERE username = '{$username}' AND password = '{$password}'");
    }

    public function getActiveBots() {
        $this->setTable("bot");
        return $this->select(array('*'), array(array('status','=',1)));
    }

    public function getCookieFile() {
        $this->setTable("bot");
        $bot = $this->select(array('apikey'), array(array('status','=',1)));
        return implode(".", array($bot[0]['apikey'],'steam'));
    }

    public function addTeam($logo, $name, $alias, $description, $sid) {
    	$this->setTable("team");
    	$this->logo = $logo;
    	$this->name = $name;
    	$this->alias = $alias;
    	$this->description = $description;
    	$this->sid = $sid;
    	return $this->create();
    }

    public function editTeam($logo, $name, $alias, $description, $sid, $id) {
    	$this->setTable("team");
    	$this->id = $id;
    	$this->logo = $logo;
    	$this->name = $name;
    	$this->alias = $alias;
    	$this->description = $description;
    	$this->sid = $sid;
    	return $this->update();
    }

    public function getTeam($id) {
    	$this->setTable("team");
    	$team = $this->select(array('*'), array(array('id','=',$id)));
    	return $team[0];
    }

    public function getTeams() {
    	$this->setTable("team");
        $this->setOrder(array(array('sid'),array('name')));
    	return $this->select(array('*'));
    }

    public function getTeamsBySid($sid) {
    	$this->setTable("team");
        $this->setOrder(array(array('name')));
    	$teams = $this->select(array('id','name'), array(array('sid','=', $sid)));
    	foreach ($teams as $key => $value) {
    		$data[] = array('id' => $value['id'], 'name' => $value['name']);
    	}
    	return $data;
    }

    public function deleteTeam($id) {
        $this->setTable("team");
        $this->id = $id;
        return $this->delete();
    }

    public function addGame($sid, $eid, $team1, $team2, $games, $dates, $stream) {
    	$this->setTable("game");
    	$this->sid = $sid;
    	$this->eid = $eid;
    	$this->team1 = $team1;
    	$this->team2 = $team2;
    	$this->games = $games;
        $this->dates = $dates;
        $this->stream = $stream;
    	return $this->create();
    }

    public function editGame($sid, $eid, $team1, $team2, $games, $dates, $stream, $id) {
    	$this->setTable("game");
        $this->id = $id;
    	$this->sid = $sid;
        $this->eid = $eid;
        $this->team1 = $team1;
        $this->team2 = $team2;
        $this->games = $games;
        $this->dates = $dates;
        $this->stream = $stream;
    	return $this->update();
    }

    public function setGameScores($scores, $score1, $score2, $id) {
        $this->setTable("game");
        $this->id = $id;
        $this->scores = $scores;
        $this->score1 = $score1;
        $this->score2 = $score2;
        return $this->update();
    }

    public function setGameStatus($status, $id) {
        $this->setTable("game");
        $this->id = $id;
        $this->status = $status;
        return $this->update();
    }

    public function setGameOdds($odd1, $odd2, $id) {
        $this->setTable("game");
        $this->id = $id;
        $this->odd1 = $odd1;
        $this->odd2 = $odd2;
        return $this->update();
    }

    public function setGameVals($val1, $val2, $id) {
        $this->setTable("game");
        $this->id = $id;
        $this->val1 = $val1;
        $this->val2 = $val2;
        return $this->update();
    }

    public function setGameWinner($winner, $id) {
        $this->setTable("game");
        $this->id = $id;
        $this->winner = $winner;
        return $this->update();
    }

    public function isMatch($id) {
        $this->setTable("game");
        $game = $this->select(array('*'), array(array('id','=',$id)));
        return (empty($game))? false : true;
    }

    public function getTime($id) {
        $this->setTable("game");
        $time = $this->select(array(
            'dates',
            'TIMESTAMPDIFF(MINUTE , NOW(), dates) AS minute',
            'TIMESTAMPDIFF(HOUR , NOW(), dates) AS hour',
            'TIMESTAMPDIFF(DAY , NOW(), dates) AS day'
            ), array(array('id','=',$id)));
        return $time[0];
    }

    public function getGame($id) {
    	$this->setTable("game");
    	$game = $this->select(array('*'), array(array('id','=',$id)));
    	$data = array(
    		'id' => $game[0]['id'],
            'games' => $game[0]['games'],
            'dates' => $game[0]['dates'],
    		'team1' => $this->getTeam($game[0]['team1']),
    		'team2' => $this->getTeam($game[0]['team2']),
    		'event' => $this->getEvent($game[0]['eid']),
    		'sport' => $this->getSport($game[0]['sid']),
            'scores' => $game[0]['scores'],
            'score1' => $game[0]['score1'],
            'score2' => $game[0]['score2'],
            'status' => $game[0]['status'],
            'winner' => $game[0]['winner'],
            'stream' => $game[0]['stream'],
            'odd1' => $game[0]['odd1'],
            'odd2' => $game[0]['odd2'],
            'val1' => $game[0]['val1'],
            'val2' => $game[0]['val2']
    	);
    	return $data;
   	}

   	public function getGames($sid, $eid) {
   		$data = array();
   		$this->setTable("game");
    	$games = $this->select(array('*'), array(array('sid','=',$sid), array('eid','=',$eid)));
    	if($games) foreach($games as $game) $data[] = $this->getGame($game['id']);
   		return $data;
   	}

    public function getLatestGames($sid) {
        $data = array();
        $this->setTable("game");
        $this->setOrder(array(array('CASE WHEN lapse > 0 THEN 0 WHEN lapse < 0 THEN 1 END'), array('CASE WHEN lapse < 0 THEN lapse END','DESC'), array('lapse')));
        $games = $this->select(
            array('*','TIME_TO_SEC(TIMEDIFF(dates, NOW())) AS lapse'), 
            array(
                "sid IN({$sid})", 
                array('TIMESTAMPDIFF(DAY, dates, NOW())', '<', 5), 
                "CASE WHEN TIMESTAMPDIFF(DAY, dates, NOW()) > 0 THEN status<>3 ELSE TRUE END"
            )
        );        
        if($games) foreach($games as $game) $data[] = $this->getGame($game['id']);
        return $data;
    }

    public function getRecentGames() {
        $data = array();
        $this->setTable("game");
        $this->setOrder(array(array('dates','DESC')));
        $this->setLimit(5);
        $games = $this->select(array('*'), array(array('status', '=', 3)));
        if($games) foreach($games as $game) $data[] = $this->getGame($game['id']);
        return $data;
    }

   	public function getAllGames() {
   		$data = array();
   		$this->setTable("game");
        $this->setOrder(array(array('dates','DESC')));
    	$games = $this->select(array('*'));
    	if($games) foreach($games as $game) $data[] = $this->getGame($game['id']);
   		return $data;
   	}

    public function deleteGame($id) {
        $this->setTable("game");
        $this->id = $id;
        return $this->delete();
    }

    public function addTrade($steam, $botid, $teamid, $gameid, $tradeofferid, $tradeofferitems, $tradecode, $tradetype=0) {
        $this->setTable("trade");
        $this->steam = $steam;
        $this->botid = $botid;
        $this->teamid = $teamid;
        $this->gameid = $gameid;
        $this->tradeofferid = $tradeofferid;
        $this->tradeofferitems = $tradeofferitems;
        $this->tradecode = $tradecode;
        $this->tradetype = $tradetype;
        return $this->create();
    }

    public function getTrade($steam) {
        $this->setTable("trade");
        $data = $this->select(array('*'), array(array('steam', '=', $steam)));
        return $data[0];
    }

    public function deleteTrade($id) {
        $this->setTable("trade");
        $this->id = $id;
        return $this->delete();
    }

    public function cancelTrade($tradeofferid) {
        return $this->PDO->query("DELETE FROM trade WHERE tradeofferid = '{$tradeofferid}'");
    }

    public function setTeamStake($steam, $gameid, $team) {
        return $this->PDO->query("UPDATE stake SET team = {$team} WHERE steam = '{$steam}' AND gameid = {$gameid}");
    }

    public function addStake($steam, $team, $items, $itemsplaced, $gameid) {
        $this->setTable("stake");
        $this->steam = $steam;
        $this->team = $team;
        $this->items = $items;
        $this->itemsplaced = $itemsplaced;
        $this->gameid = $gameid;
        return $this->create();
    }

    public function setStake($team, $items, $itemsplaced, $id) {
        $this->setTable("stake");
        $this->id = $id;
        $this->team = $team;
        $this->items = $items;
        $this->itemsplaced = $itemsplaced;
        return $this->update(); 
    }

    public function setItemsReturned($itemsreturned, $id) {
        $this->setTable("stake");
        $this->id = $id;
        $this->itemsreturned = $itemsreturned;
        return $this->update();
    }

    public function deleteStake($id) {
        $this->setTable("stake");
        $this->id = $id;
        return $this->delete();
    }

    public function getStake($id) {
        $this->setTable("stake");
        $data = $this->select(array('*'), array(array('id','=', $id)));
        return $data[0];
    }

    public function getStakes() {
        $this->setTable("stake");
        return $this->select(
            array('*','stake.id as stakeID'), 
            array(array('game.id','=','stake.gameid', true)), 
            array('game')
        );
    }

    public function getUserStake($steam, $gameid) {
        $this->setTable("stake");
        $data = $this->select(
            array('stake.*'), 
            array(array('game.id','=','stake.gameid', true), array('stake.steam','=', $steam), array('stake.gameid','=', $gameid)), 
            array('game')
        );
        if($data) {
            $data[0]['game'] = $this->getGame($data[0]['gameid']);
            return $data[0];
        }
    }

    public function getUserStakes($steam) {
        $this->setTable("stake");
        $this->setOrder(array(array('id','DESC')));
        $data = $this->select(array('*'), array(array('steam', '=', $steam)));
        if($data) {
            foreach($data as $key => $val) {
                $data[$key]['game'] = $this->getGame($val['gameid']);
            }
        }
        return $data;
    }

    public function getGameStakes($gameid) {
        $this->setTable("stake");
        return $this->select(
            array('*','stake.id as stakeID'), 
            array(array('game.id','=','stake.gameid', true), array('stake.gameid','=', $gameid)), 
            array('game')
        );
    }

    public function addUserLinks($id, $links) {
        $this->setTable("user");
        $this->id = $id;
        $this->links = $links;
        return $this->update();
    }
    
    public function handleUser($steamID, $personaname) {
        if($this->authUser($steamID)) {
            $user = $this->getUser($steamID);
            $this->setPersona($personaname, $user['id']);
        } else
            $this->addUser($steamID, $personaname);
        return $this;
    } 

    public function authUser($steam) {
        $this->setTable("user");
        $auth = $this->select(array('*'), array(array('steam','=',$steam)));
        return (empty($auth))? false : true;
    }

    public function addUser($steam, $persona) {
        $this->setTable("user");
        $this->steam = $steam;
        $this->persona = $persona;
        return $this->create();
    }

    public function setPersona($persona, $id) {
        $this->setTable("user");
        $this->id = $id;
        $this->persona = $persona;
        return $this->update();
    }

    public function getUser($steam) {
        $this->setTable("user");
        $data = $this->select(array('*'), array(array('steam', '=', $steam)));
        return $data[0];
    }

    public function getUsers() {
        $this->setTable("user");
        return $this->select(array('*'));
    }

    public function getUserPersona($steam) {
        $this->setTable("user");
        $data = $this->select(array('persona'), array(array('steam', '=', $steam)));
        return $data[0]['persona'];
    }

    public function getUserItems($steam) {
        $this->setTable("item");
        $this->setOrder(array(array('dota2.price','DESC')));
        return $this->select(
            array('item.id as itemid','item.steam','item.stake','pack.*','dota2.price','dota2.valid'), 
            array(array('item.assetid','=','pack.assetid',true), array('pack.classid','=','dota2.classid',true), array('item.steam','=',$steam)), 
            array('pack','dota2')
        );
    }

    public function getUserItemsWhosePriceIs($steam, $price, $operator) {
        $this->setTable("item");
        $this->setOrder(array(array('dota2.price','DESC')));
        return $this->select(
            array('item.id as itemid','item.steam','item.stake','pack.*','dota2.price'), 
            array(array('item.assetid','=','pack.assetid',true), array('pack.classid','=','dota2.classid',true), "item.steam IN({$steam})", array('dota2.valid', '=', 1), array('dota2.price', $operator, $price)), 
            array('pack','dota2')
        );
    }

    public function getBotsTradedWith($steam) {
        $this->setTable("bot");
        return $this->select(array('*'), array("id IN(SELECT DISTINCT(botid) FROM pack, item WHERE pack.assetid = item.assetid AND steam = '{$steam}')"));
    }

    public function getUserItemsCountInBot($steam, $botid) {
        $this->setTable("item");
        $count = $this->select(
            array('COUNT(*) as items'), 
            array(array('item.assetid','=','pack.assetid',true), array('item.steam', '=', $steam), array('pack.botid', '=', $botid)),
            array('pack')
        );
        return $count[0]['items'];
    }

    public function getUserReturnItems($steam, $botid) {
        $this->setTable("item");
        return $this->select(
            array('item.*', 'pack.*', 'item.id as itemid', 'pack.id as packid'), 
            array(array('item.assetid','=','pack.assetid',true), array('item.steam', '=', $steam), array('pack.botid', '=', $botid), array('item.stake', '=', 0)),
            array('pack')
        );
    }

    public function getBotItemsCount($botid) {
        $this->setTable("item");
        $count = $this->select(
            array('COUNT(*) as items'), 
            array(array('item.assetid','=','pack.assetid',true), array('pack.botid', '=', $botid)),
            array('pack')
        );
        return $count[0]['items'];
    }

    public function getBotItems($botid) {
        $this->setTable("item");
        $this->setOrder(array(array('dota2.price','DESC')));
        return $this->select(
            array('pack.*','item.steam','item.stake','item.id as itemid','dota2.price','dota2.valid'), 
            array(array('item.assetid','=','pack.assetid',true), array('pack.classid','=','dota2.classid',true), array('pack.botid', '=', $botid)),
            array('pack','dota2')
        );
    }

    public function getBotsInvolved($itemid) {
        $this->setTable("bot");
        return $this->select(array('*'), array("id IN(SELECT DISTINCT(botid) FROM pack, item WHERE pack.assetid = item.assetid AND item.id IN({$itemid}))"));
    }

    public function getUsersCount($year, $month=false, $day=false) {
        $this->setTable("user");
        $where[] = array('YEAR(stamp)', '=', $year);
        if($month) $where[] = array('MONTH(stamp)', '=', $month);
        if($day) $where[] = array('DAY(stamp)', '=', $day);
        $data = $this->select(array('COUNT(*) as count'), $where); 
        return $data[0]['count'];
    }

    public function getGamesCount($year, $month=false, $day=false) {
        $this->setTable("game");
        $where[] = array('YEAR(dates)', '=', $year);
        if($month) $where[] = array('MONTH(dates)', '=', $month);
        if($day) $where[] = array('DAY(dates)', '=', $day);
        $data = $this->select(array('COUNT(*) as count'), $where); 
        return $data[0]['count'];
    }

    public function getStakesCount($year, $month=false, $day=false) {
        $this->setTable("stake");
        $where[] = array('YEAR(updated)', '=', $year);
        if($month) $where[] = array('MONTH(updated)', '=', $month);
        if($day) $where[] = array('DAY(updated)', '=', $day);
        $data = $this->select(array('COUNT(*) as count'), $where); 
        return $data[0]['count'];
    }

    public function setMenu($page, $http, $name) {
        if(is_array($name)) {
            return array(
                'class' => (in_array($page, $name))? 'current' : '',
                'links' => generateUrl($http.current($name))
            );
        } else
            return array(
                'class' => ($page==$name)? 'current' : '',
                'links' => generateUrl($http.$name)
            );
    }

    public function getItem($item) {
        return '<div data-original-title="'.$item->name.'" data-placement="top" style="background-image: url('.$item->icon.'); background-size: 100% 100%; background-repeat: no-repeat;" class="box inventoryItems" id="'.$item->data.'"><div class="itemPrice">'.$item->price.'</div><div style="color: '.$item->color.'" class="itemRarity"><span>'.$item->rarity.'</span></div></div>';
    }

    public function addItem($assetid, $steam, $stake=1) {
        $this->setTable("item");
        $this->assetid = $assetid;        
        $this->steam = $steam;
        $this->stake = $stake;
        return $this->create();
    }

    public function getItems($itemids) {
        $this->setTable("item");
        $this->setOrder(array(array('dota2.price','DESC')));
        return $this->select(
            array('pack.*','item.steam','item.stake','item.id as itemid','dota2.price','dota2.valid'),
            array(array('item.assetid','=','pack.assetid', true), array('pack.classid','=','dota2.classid', true), "item.id IN({$itemids})"), 
            array('pack','dota2')
        );
    }

    public function getItemsPrice($itemids) {
        $this->setTable("item");
        $data = $this->select(
            array('SUM(dota2.price) as value'), 
            array(array('item.assetid','=','pack.assetid', true), array('pack.classid','=','dota2.classid', true), "item.id IN({$itemids})"), 
            array('pack','dota2')
        );
        return $data[0]['value'];
    }

    public function setItemsStake($stake, $itemids) {
        return $this->PDO->query("UPDATE item SET stake = {$stake} WHERE id IN({$itemids})");
    }

    public function setItemsSteam($steam, $itemids) {
        return $this->PDO->query("UPDATE item SET steam = '{$steam}' WHERE id IN({$itemids})");
    }

    public function deleteItem($assetid) {
        return $this->PDO->query("DELETE FROM item, pack USING item INNER JOIN pack WHERE item.assetid = pack.assetid AND item.assetid = '{$assetid}'");
    }

    public function clearItems() {
        $this->setTable("item");
        $this->delete(true);
        return $this;
    }

    public function addPack($assetid, $classid, $amount, $name, $quality, $rarity, $type, $slot, $hero, $icon, $color, $itemset, $botid) {
        $this->setTable("pack");
        $this->assetid = $assetid;
        $this->classid = $classid;
        $this->amount = $amount;
        $this->name = $name;
        $this->quality = $quality;
        $this->rarity = $rarity;
        $this->type = $type;
        $this->slot = $slot;
        $this->hero = $hero;
        $this->icon = $icon;
        $this->color = $color;
        $this->itemset = $itemset;
        $this->botid = $botid;
        return $this->create(); 
    }

    public function getPack($id) {
        $this->setTable("item");
        $item = $this->select(
            array('pack.*'), 
            array(array('item.assetid','=','pack.assetid', true), array('item.id','=', $id)), 
            array('pack')
        );
        return $item[0];
    }

    public function getPacks() {
        $this->setTable("pack");
        $this->setOrder(array(array('dota2.price','DESC')));
        return $this->select(
            array('pack.*','dota2.price'), 
            array(array('pack.classid','=','dota2.classid', true)), 
            array('dota2')
        );
    }

    public function clearPack() {
        $this->setTable("pack");
        $this->delete(true);
        return $this;
    }

    public function addDota2($name, $classid) {
        $this->setTable("dota2");
        $this->name = $name;
        $this->classid = $classid;
        return $this->create();
    }

    public function getDota2($classid, $field=false) {
        $this->setTable("dota2");
        $item = $this->select(array('price','valid'), array(array('classid', '=', $classid)));
        return $item? ($field? $item[0][$field] : $item[0]) : false;
    }

    public function setPrice($price, $id) {
        $this->setTable("dota2");
        $this->id = $id;
        $this->price = $price;
        return $this->update();
    }

    public function setValid($valid, $id) {
        $this->setTable("dota2");
        $this->id = $id;
        $this->valid = $valid;
        return $this->update();
    }

    public function setStamp($stamp, $id) {
        $this->setTable("dota2");
        $this->id = $id;
        $this->stamp = $stamp;
        return $this->update();
    }

    public function getDota2s() {
        $this->setTable("dota2");
        $this->setOrder(array(array('id')));
        return $this->select(array('*'));
    }

    public function getDota2sNotUpdated($stamp) {
        $this->setTable("dota2");
        $this->setOrder(array(array('id')));
        $this->setLimit(5);
        return $this->select(array('*'), array("stamp = '' OR stamp < $stamp"));
    }

    public function getDota2ByName($name) {
        $this->setTable("dota2");
        $item = $this->select(array('*'), array(array('name', '=', $name)));
        return $item[0];
    }    

    public function clearDota2() {
        $this->setTable("dota2");
        $this->delete(true);
        return $this;
    }
}