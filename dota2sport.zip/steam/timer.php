<?php
class ACCESS {

    var $PDO, $dbHost, $dbUser, $dbPass, $dbName;

    function __construct() { 
    	$this->Halt()->Load();
    	$timezone = date("P");
        $this->PDO->query("SET SESSION time_zone = '{$timezone}'"); 
    }

    public function Load() {
        $this->dbHost = "localhost";
        $this->dbUser = "bartgamer";
        $this->dbPass = "bartgamer";
        $this->dbName = "dota2sport";
        try {
            $this->PDO = new PDO('mysql:host='.$this->dbHost.';dbname='.$this->dbName, $this->dbUser, $this->dbPass, array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            exit("Load(): " . $e->getMessage());
        }
    }

    public function Halt() {
        $this->PDO = null;
        return $this;
    }

    public function setOngoingGame($odd1, $odd2, $val1, $val2, $id) {
        $this->PDO->query("UPDATE game SET status = 1, odd1 = $odd1, odd2 = $odd2, val1 = $val1, val2 = $val2 WHERE id = $id");
    }

    public function getWaitingGames() {
        $object = $this->PDO->query("SELECT id, TIMESTAMPDIFF(MINUTE, NOW(), dates) AS minute, TIMESTAMPDIFF(HOUR, NOW(), dates) AS hour, TIMESTAMPDIFF(DAY, NOW(), dates) AS day FROM game WHERE DATE(dates) = CURDATE() AND status = 0");
        $record = false;
        if($object) {
            if($object->rowCount())
                $record = $object->fetchAll();
            else {
                $record = $object->fetch(PDO::FETCH_ASSOC);
            }
        }
        return $record;
    }

    public function getGameOdds($gameid) {
		$context  = stream_context_create(array('http' =>
		    array(
		        'method'  => 'POST',
		        'header'  => 'Content-type: application/x-www-form-urlencoded',
		        'content' => http_build_query(array('d'=>$gameid))
		    )
		));
		$content = json_decode(file_get_contents('http://dota2sport.com/dota2/ajax.php?q=dota/getGameOdds', false, $context));
		return $content;
    }
}

date_default_timezone_set('Asia/Manila');
$ACCESS = new ACCESS;
$wGames = $ACCESS->getWaitingGames();
if($wGames) {
	foreach ($wGames as $g) {
        $m = $g['minute'];
		$h = $g['hour'];
		$d = $g['day'];
		if($d<0) {} 
		else {
			if($h<0) {} 
			else {
				if($h==0) {
					if($m<=5) {	
						$gid = $g['id'];
						$odd = $ACCESS->getGameOdds($gid);
						$ACCESS->setOngoingGame($odd->odd1, $odd->odd2, $odd->val1, $odd->val2, $gid); 						 
					}
				}
			}
		}
	}
}