<?php
class ACCESS {

    var $PDO, $dbHost, $dbUser, $dbPass, $dbName;
    var $key = "56add578b98d8812048d7857";
    var $appid = 570;

    function __construct() { $this->Halt()->Load(); }

    public function Load() {
        $this->dbHost = "localhost";
        $this->dbUser = "bartgamer";
        $this->dbPass = "bartgamer";
        $this->dbName = "steamprices";
        try {
            $this->PDO = new PDO('mysql:host='.$this->dbHost.';dbname='.$this->dbName, $this->dbUser, $this->dbPass, array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            exit("Load(): " . $e->getMessage());
        }
    }

    public function Halt() {
        $this->PDO = null;
        return $this;
    }

    public function getItems() {        
        $object = $this->PDO->query("SELECT * FROM items");
        $record = false;
        if($object) {
            if($object->rowCount())
                $record = $object->fetchAll();
            else {
                $record = $object->fetch(PDO::FETCH_ASSOC);
            }
        }
        return $record;
    }

    public function updateItem($price, $valid, $stamp, $id) {
        $this->PDO->query("UPDATE items SET price = '{$price}', valid = '{$valid}', stamp = '{$stamp}' WHERE id = $id");
    }

    public function backpackTF() {
        $json = @file_get_contents("http://backpack.tf/api/IGetMarketPrices/v1/?" . http_build_query(array(
            "key" => $this->key,
            "appid" => $this->appid,
            "format" => "json"
        )));
        if($json) {
            $data = json_decode($json);             
            return $data->response->success? $data->response->items : $data;
        }
        return $json;
    }
}
 
date_default_timezone_set('Asia/Manila');
set_time_limit(0);
$ACCESS = new ACCESS;
$DBItem = $ACCESS->getItems();
$TFItem = $ACCESS->backpackTF();

if($DBItem AND $TFItem) {
    foreach ($DBItem as $item) {
        $name = $item['name'];
        if(isset($TFItem->$name)) {
            $stamp = $TFItem->$name->last_updated;                    
            $count = $TFItem->$name->quantity;                    
            $value = $TFItem->$name->value;
            $price = $value? ($value / 100) : $value; 
            $valid = (($price > 0) AND ($count > 9))? 1 : 0;
            $ACCESS->updateItem($price, $valid, $stamp, $item['id']);
        }
    }
}