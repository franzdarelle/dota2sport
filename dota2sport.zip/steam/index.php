<?php
class ACCESS {

    var $PDO, $dbHost, $dbUser, $dbPass, $dbName;

    function __construct() { $this->Halt()->Load(); }

    public function Load() {
        $this->dbHost = "localhost";
        $this->dbUser = "bartgamer";
        $this->dbPass = "bartgamer";
        $this->dbName = "steamprices";
        try {
            $this->PDO = new PDO('mysql:host='.$this->dbHost.';dbname='.$this->dbName, $this->dbUser, $this->dbPass, array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            exit("Load(): " . $e->getMessage());
        }
    }

    public function Halt() {
        $this->PDO = null;
        return $this;
    }

    public function escape($string) {
        $string = get_magic_quotes_gpc()? stripslashes($string) : $string;
        $string = addslashes($string);
        return $string;
    }

    public function update($price, $valid, $stamp, $id) {
        $this->PDO->query("UPDATE items SET price = '{$price}', valid = '{$valid}', stamp = '{$stamp}' WHERE id = $id");
    }

    public function search($stamp) {        
        $object = $this->PDO->query("SELECT * FROM items WHERE stamp = '' OR stamp < $stamp ORDER BY id LIMIT 5");
        $record = false;
        if($object) {
            if($object->rowCount())
                $record = $object->fetchAll();
            else {
                $record = $object->fetch(PDO::FETCH_ASSOC);
            }
        }
        return $record;
    }
}

function getItemPrice($market_hash_name) {
    $json = @file_get_contents("http://steamcommunity.com/market/priceoverview/?".http_build_query(array(
        'market_hash_name' => $market_hash_name,
        'currency' => 1,
        'country' => 'US',
        'appid' => 570
    )));
    if($json) {
        $data = json_decode($json);
        if(isset($data->success) AND isset($data->lowest_price) AND isset($data->volume) AND isset($data->median_price) AND $data->success) {            
            return array(
                'volume' => (int) $data->volume,
                'lowest_price' => str_replace("$", "", $data->lowest_price),
                'median_price' => str_replace("$", "", $data->median_price)
            );
        }
        return $data;
    }
    return $json;
}
 
date_default_timezone_set('Asia/Manila');
set_time_limit(0);
$DB = new ACCESS;

$stamp = strtotime(date("Y-m-d"));
$items = $DB->search($stamp);
if($items) {
    foreach ($items as $item) {
        $value = getItemPrice($item['name']);
        $price = (is_array($value) AND ($value['median_price'] > 0))? $value['median_price'] : 0; //must have value
        $valid = (is_array($value) AND $price AND ($value['volume'] > 10))? 1 : 0; //volume must be greater than 10 
        if(is_null($value) OR empty($value)) break;
        else {
            $DB->update($price, $valid, $stamp, $item['id']);
            sleep(10);
        }
    }
}